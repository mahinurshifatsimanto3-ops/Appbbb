<?php
declare(strict_types=1);
require_once __DIR__ . '/common/config.php';
require_user();

$user = current_user($conn);
if (!$user) {
    unset($_SESSION['user_id'], $_SESSION['user_name']);
    flash('error', 'Your session has ended. Please sign in again.');
    redirect('login.php');
}
$_SESSION['user_name'] = $user['real_name'];

$page_title = 'NIVAYA — Fine Jewellery & Accessories';
$active_nav = 'home';

$categories = product_categories($conn);

$category = trim((string) ($_GET['category'] ?? ''));
if ($category !== '' && !in_array($category, $categories, true)) {
    $category = '';
}
$q = trim((string) ($_GET['q'] ?? ''));
$q = mb_substr($q, 0, 80);

$featured = null;
$featuredResult = $conn->query('SELECT * FROM products ORDER BY created_at DESC, id DESC LIMIT 1');
if ($featuredResult) {
    $featured = $featuredResult->fetch_assoc() ?: null;
}

$where = [];
$params = [];
$types = '';
if ($category !== '') {
    $where[] = 'category = ?';
    $params[] = $category;
    $types .= 's';
}
if ($q !== '') {
    $where[] = '(name LIKE ? OR description LIKE ? OR category LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like);
    $types .= 'sss';
}

$sql = 'SELECT * FROM products';
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY created_at DESC, id DESC';

$stmt = $conn->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$productsResult = $stmt->get_result();
$products = $productsResult->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$totalProducts = (int) $conn->query('SELECT COUNT(*) AS c FROM products')->fetch_assoc()['c'];
$isFiltered = $category !== '' || $q !== '';
?>
<?php include __DIR__ . '/common/header.php'; ?>

<!-- Hero -->
<section class="grain relative animate-fade-up overflow-hidden rounded-[26px] border border-white/[0.08] bg-[#100e0b]">
    <div class="pointer-events-none absolute -left-24 top-0 h-[420px] w-[420px] rounded-full bg-amber-500/[0.07] blur-[110px]"></div>
    <div class="pointer-events-none absolute -right-20 bottom-0 h-[360px] w-[360px] rounded-full bg-amber-600/[0.05] blur-[100px]"></div>
    <div class="relative z-[2] grid lg:grid-cols-[1.02fr_.98fr]">
        <div class="flex flex-col justify-center px-6 py-9 sm:px-10 sm:py-12 lg:px-12 lg:py-14 xl:px-14">
            <div class="flex items-center gap-3">
                <span class="h-px w-7 bg-amber-400/60"></span>
                <p class="text-[9.5px] font-semibold uppercase tracking-[0.3em] text-amber-300/85">The signature edit · 2026</p>
            </div>
            <h1 class="mt-5 max-w-[520px] text-[34px] font-light leading-[1.1] tracking-[-0.035em] text-white sm:text-[43px] lg:text-[46px] xl:text-[52px]">
                Jewellery for the<br>moments you <span class="gold-text font-normal">keep.</span>
            </h1>
            <p class="mt-4 max-w-[420px] text-[12.5px] leading-[1.85] text-white/40 sm:text-[13px]">
                Handpicked rings, chains and keepsakes with an old-world soul — designed to be worn every day, and remembered for years.
            </p>

            <div class="mt-7 flex flex-wrap items-center gap-3">
                <a href="#collection" class="btn-gold group">
                    Shop the collection
                    <i class="fa-solid fa-arrow-right text-[10px] transition group-hover:translate-x-0.5"></i>
                </a>
                <?php if ($featured): ?>
                    <a href="product.php?id=<?= (int) $featured['id'] ?>" class="btn-outline">View bestseller</a>
                <?php endif; ?>
            </div>

            <div class="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3 border-t border-white/[0.07] pt-5">
                <div class="flex items-center gap-2.5">
                    <i class="fa-solid fa-gem text-[11px] text-amber-400/70"></i>
                    <span class="text-[10px] tracking-wide text-white/35">Premium gold-tone finishes</span>
                </div>
                <div class="flex items-center gap-2.5">
                    <i class="fa-solid fa-shield-halved text-[11px] text-amber-400/70"></i>
                    <span class="text-[10px] tracking-wide text-white/35">Insured delivery</span>
                </div>
                <div class="flex items-center gap-2.5">
                    <i class="fa-solid fa-wallet text-[11px] text-amber-400/70"></i>
                    <span class="text-[10px] tracking-wide text-white/35">Cash on delivery</span>
                </div>
            </div>
        </div>

        <div class="relative min-h-[300px] overflow-hidden sm:min-h-[380px] lg:min-h-[480px]">
            <?php if ($featured): ?>
                <a href="product.php?id=<?= (int) $featured['id'] ?>" class="group block h-full">
                    <img src="<?= e(upload_url($featured['image'])) ?>" alt="<?= e($featured['name']) ?>" class="absolute inset-0 h-full w-full object-cover transition duration-[1.2s] group-hover:scale-[1.03]" data-fallback="assets/img/placeholder.svg">
                    <div class="absolute inset-0 bg-gradient-to-t from-[#0b0a09] via-transparent to-transparent lg:bg-gradient-to-r lg:from-[#100e0b]/80 lg:via-transparent lg:to-transparent"></div>
                    <div class="absolute bottom-4 left-4 right-4 z-[3] rounded-2xl border border-white/10 bg-black/45 p-4 backdrop-blur-md sm:bottom-5 sm:left-5 sm:right-5">
                        <div class="flex items-end justify-between gap-3">
                            <div class="min-w-0">
                                <p class="text-[8.5px] font-semibold uppercase tracking-[0.22em] text-amber-300/80">Most loved</p>
                                <h2 class="mt-1 truncate text-[13.5px] font-medium text-white"><?= e($featured['name']) ?></h2>
                                <p class="mt-1 text-[10px] text-white/40"><?= e($featured['category']) ?></p>
                            </div>
                            <div class="shrink-0 text-right">
                                <p class="text-[14px] font-semibold text-amber-300"><?= e(money(product_price($featured))) ?></p>
                                <?php if ((float) $featured['original_price'] > product_price($featured)): ?>
                                    <p class="text-[9.5px] text-white/30 line-through"><?= e(money((float) $featured['original_price'])) ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </a>
            <?php else: ?>
                <img src="assets/img/placeholder.svg" alt="NIVAYA jewellery" class="absolute inset-0 h-full w-full object-cover opacity-70">
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Category chips + search -->
<section id="collection" class="mt-10 scroll-mt-24 sm:mt-12">
    <div class="flex flex-col gap-5">
        <div class="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
                <p class="eyebrow">Curated for you</p>
                <h2 class="mt-2 text-[23px] font-medium tracking-[-0.025em] text-white sm:text-[27px]">The collection</h2>
            </div>
            <div class="flex items-center gap-3">
                <span class="hidden text-[10.5px] text-white/25 sm:block"><?= count($products) ?> <?= count($products) === 1 ? 'piece' : 'pieces' ?></span>
                <form method="get" action="index.php#collection" class="relative">
                    <?php if ($category !== ''): ?><input type="hidden" name="category" value="<?= e($category) ?>"><?php endif; ?>
                    <input type="search" name="q" value="<?= e($q) ?>" placeholder="Search pieces…" maxlength="80" class="admin-input w-full py-2.5 pl-9 pr-3 text-[11.5px] sm:w-[220px]" aria-label="Search jewellery">
                    <i class="fa-solid fa-magnifying-glass pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-[10px] text-white/25"></i>
                </form>
            </div>
        </div>

        <div class="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:px-0">
            <a href="index.php<?= $q !== '' ? '?q=' . urlencode($q) : '' ?>#collection" class="chip <?= $category === '' ? 'is-active' : '' ?>">
                <?php if ($category === ''): ?><i class="fa-solid fa-check text-[8px]"></i><?php endif; ?>
                All pieces
            </a>
            <?php foreach ($categories as $cat): ?>
                <a href="index.php?category=<?= urlencode($cat) ?><?= $q !== '' ? '&q=' . urlencode($q) : '' ?>#collection" class="chip <?= $category === $cat ? 'is-active' : '' ?>">
                    <?= e($cat) ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>

    <?php if ($isFiltered): ?>
        <div class="mt-4 flex flex-wrap items-center gap-2 text-[10.5px] text-white/35">
            <span>Showing</span>
            <?php if ($category !== ''): ?><span class="rounded-full border border-amber-400/20 bg-amber-400/[0.06] px-2.5 py-1 text-amber-200/80"><?= e($category) ?></span><?php endif; ?>
            <?php if ($q !== ''): ?><span class="rounded-full border border-white/10 bg-white/[0.03] px-2.5 py-1">“<?= e($q) ?>”</span><?php endif; ?>
            <a href="index.php#collection" class="ml-1 text-amber-300/80 underline decoration-amber-400/25 underline-offset-4 hover:text-amber-200">Clear filters</a>
        </div>
    <?php endif; ?>

    <?php if (!$products): ?>
        <div class="mt-8 flex flex-col items-center rounded-3xl border border-dashed border-white/10 bg-white/[0.015] px-6 py-16 text-center">
            <span class="grid h-14 w-14 place-items-center rounded-full border border-amber-400/20 bg-amber-400/[0.05] text-amber-300/70"><i class="fa-solid fa-gem text-lg"></i></span>
            <h3 class="mt-5 text-[16px] font-medium text-white">No pieces found</h3>
            <p class="mt-2 max-w-[300px] text-[12px] leading-relaxed text-white/35">
                <?= $totalProducts === 0 ? 'The collection is being curated. Please check back soon.' : 'Try another search or browse the full collection.' ?>
            </p>
            <?php if ($isFiltered): ?><a href="index.php#collection" class="btn-outline mt-6">View all pieces</a><?php endif; ?>
        </div>
    <?php else: ?>
        <div class="mt-6 grid grid-cols-2 gap-3.5 sm:gap-5 lg:grid-cols-3">
            <?php foreach ($products as $index => $product): ?>
                <?php
                    $price = product_price($product);
                    $original = (float) $product['original_price'];
                    $off = discount_percent($product);
                    $isNew = strtotime((string) $product['created_at']) > strtotime('-14 days');
                ?>
                <a href="product.php?id=<?= (int) $product['id'] ?>" class="group flex animate-fade-up flex-col overflow-hidden rounded-2xl border border-white/[0.08] bg-[#12110f] shadow-card transition duration-500 hover:-translate-y-1 hover:border-amber-400/25 hover:shadow-glow" style="animation-delay: <?= min($index * 45, 220) ?>ms">
                    <div class="relative aspect-square overflow-hidden bg-[#171410]">
                        <img src="<?= e(upload_url($product['image'])) ?>" alt="<?= e($product['name']) ?>" loading="lazy" class="h-full w-full object-cover transition duration-[900ms] ease-out group-hover:scale-[1.06]" data-fallback="assets/img/placeholder.svg">
                        <div class="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/45 via-transparent to-transparent opacity-70"></div>

                        <div class="absolute left-2.5 top-2.5 flex flex-col items-start gap-1.5 sm:left-3 sm:top-3">
                            <?php if ($off > 0): ?>
                                <span class="rounded-full border border-amber-300/30 bg-[#1a150d]/90 px-2 py-1 text-[8.5px] font-bold tracking-[0.04em] text-amber-300 backdrop-blur"><?= $off ?>% OFF</span>
                            <?php endif; ?>
                            <?php if ($isNew): ?>
                                <span class="rounded-full border border-white/15 bg-black/50 px-2 py-1 text-[8px] font-medium uppercase tracking-[0.14em] text-white/70 backdrop-blur">New</span>
                            <?php endif; ?>
                        </div>

                        <span class="absolute bottom-2.5 right-2.5 grid h-7 w-7 place-items-center rounded-full border border-white/15 bg-black/40 text-white/70 backdrop-blur transition duration-300 group-hover:border-amber-300/50 group-hover:bg-amber-400 group-hover:text-black sm:h-8 sm:w-8">
                            <i class="fa-solid fa-arrow-right -rotate-45 text-[9px]"></i>
                        </span>
                    </div>

                    <div class="flex flex-1 flex-col p-3 sm:p-4">
                        <p class="text-[8.5px] font-medium uppercase tracking-[0.18em] text-amber-300/60"><?= e($product['category']) ?></p>
                        <h3 class="mt-1 text-[12.5px] font-medium leading-snug text-white transition group-hover:text-amber-100 sm:text-[14px]"><?= e($product['name']) ?></h3>
                        <p class="line-clamp-2 mt-1.5 text-[10px] leading-relaxed text-white/30 sm:text-[10.5px]"><?= e(truncate((string) $product['description'], 90)) ?></p>

                        <div class="mt-auto pt-3">
                            <div class="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
                                <span class="text-[13.5px] font-semibold tracking-tight text-amber-300 sm:text-[15px]"><?= e(money($price)) ?></span>
                                <?php if ($off > 0 && $original > $price): ?>
                                    <span class="text-[9.5px] text-white/25 line-through"><?= e(money($original)) ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="mt-2.5 flex items-center gap-1.5 border-t border-white/[0.06] pt-2.5 text-[9px] text-white/28">
                                <i class="fa-solid fa-phone text-[8px] text-amber-400/50"></i>
                                <span class="truncate"><?= e($product['contact_number']) ?></span>
                            </div>
                            <span class="mt-2.5 inline-flex items-center justify-center gap-1.5 rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-[9.5px] font-medium text-white/55 transition duration-300 group-hover:border-amber-400/40 group-hover:bg-amber-400/10 group-hover:text-amber-200">
                                View details <i class="fa-solid fa-arrow-right text-[8px] transition group-hover:translate-x-0.5"></i>
                            </span>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<!-- Service strip -->
<section class="mt-12 grid animate-fade-up grid-cols-1 gap-px overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.06] sm:grid-cols-3">
    <div class="flex items-center gap-3.5 bg-[#100e0b] px-5 py-4">
        <i class="fa-solid fa-box-open text-[15px] text-amber-400/70"></i>
        <div>
            <p class="text-[10.5px] font-medium text-white/70">Complimentary shipping</p>
            <p class="mt-0.5 text-[9px] text-white/25">Insured on orders above ৳2,999</p>
        </div>
    </div>
    <div class="flex items-center gap-3.5 bg-[#100e0b] px-5 py-4">
        <i class="fa-solid fa-gem text-[15px] text-amber-400/70"></i>
        <div>
            <p class="text-[10.5px] font-medium text-white/70">Hand-finished pieces</p>
            <p class="mt-0.5 text-[9px] text-white/25">Small-batch, skin-friendly finishes</p>
        </div>
    </div>
    <div class="flex items-center gap-3.5 bg-[#100e0b] px-5 py-4">
        <i class="fa-solid fa-headset text-[15px] text-amber-400/70"></i>
        <div>
            <p class="text-[10.5px] font-medium text-white/70">Personal styling help</p>
            <p class="mt-0.5 text-[9px] text-white/25">A real human, over call</p>
        </div>
    </div>
</section>

<?php include __DIR__ . '/common/bottom.php'; ?>
