<?php
declare(strict_types=1);
require_once __DIR__ . '/common/config.php';
require_admin();

$adminId = (int) $_SESSION['admin_id'];
$stmt = $conn->prepare('SELECT id, username, password1, password2 FROM admin WHERE id = ? LIMIT 1');
$stmt->bind_param('i', $adminId);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$admin) {
    unset($_SESSION['admin_id'], $_SESSION['admin_username']);
    flash('error', 'Your admin session is no longer valid. Please sign in again.');
    redirect('login.php');
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_csrf_check();
    $current1 = (string) ($_POST['current_password1'] ?? '');
    $current2 = (string) ($_POST['current_password2'] ?? '');
    $new1     = (string) ($_POST['new_password1'] ?? '');
    $new2     = (string) ($_POST['new_password2'] ?? '');

    $ok1 = password_verify($current1, (string) $admin['password1']);
    $ok2 = password_verify($current2, (string) $admin['password2']);
    if (!$ok1 || !$ok2) {
        $errors[] = 'Your current passwords are incorrect. Both must match to make changes.';
    }
    if (strlen($new1) < 6 || strlen($new2) < 6) {
        $errors[] = 'Each new password must be at least 6 characters long.';
    }
    if ($new1 !== '' && $new1 === $new2) {
        $errors[] = 'For security, the two new passwords must be different from each other.';
    }
    if ($new1 === $current1 && $new2 === $current2) {
        $errors[] = 'The new passwords must be different from the current ones.';
    }

    if (!$errors) {
        $hash1 = password_hash($new1, PASSWORD_BCRYPT);
        $hash2 = password_hash($new2, PASSWORD_BCRYPT);
        $stmt = $conn->prepare('UPDATE admin SET password1 = ?, password2 = ? WHERE id = ?');
        $stmt->bind_param('ssi', $hash1, $hash2, $adminId);
        $stmt->execute();
        $stmt->close();
        flash('success', 'Your admin passwords have been updated. Use them next time you sign in.');
        redirect('settings.php');
    }
}

$page_title = 'Settings';
$admin_title = 'Settings';
$admin_active = 'settings';
?>
<?php include __DIR__ . '/common/header.php'; ?>

<div class="mb-5">
    <p class="text-[8.5px] font-medium uppercase tracking-[0.2em] text-amber-300/50">Account security</p>
    <h2 class="mt-1.5 text-[20px] font-medium tracking-[-0.02em] text-white">Admin settings</h2>
    <p class="mt-1 text-[10.5px] text-white/30">Rotate the two passwords that protect the studio. Both are required at sign-in.</p>
</div>

<?php if ($errors): ?>
    <div class="alert-in mb-4 rounded-2xl border border-rose-400/20 bg-rose-400/[0.06] px-4 py-3.5" role="alert">
        <div class="flex items-start gap-3 text-[12px] text-rose-200">
            <i class="fa-solid fa-circle-exclamation mt-0.5 text-rose-400"></i>
            <ul class="list-disc space-y-1 pl-4 text-[11px] leading-relaxed text-rose-200/70">
                <?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?>
            </ul>
        </div>
    </div>
<?php endif; ?>

<div class="grid gap-4 lg:grid-cols-[.8fr_1.2fr]">
    <aside class="admin-card h-fit p-5">
        <div class="flex items-center gap-3">
            <span class="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-amber-300 to-amber-600 text-[15px] font-bold text-[#1a1408]"><?= e(strtoupper(substr((string) $admin['username'], 0, 1))) ?></span>
            <div>
                <p class="text-[13px] font-medium text-white"><?= e($admin['username']) ?></p>
                <p class="text-[9px] uppercase tracking-[0.14em] text-white/25">Administrator</p>
            </div>
        </div>
        <div class="mt-4 space-y-2.5 border-t border-white/[0.06] pt-4 text-[10px] leading-relaxed text-white/35">
            <p class="flex items-start gap-2"><i class="fa-solid fa-shield-halved mt-0.5 text-[10px] text-amber-400/50"></i>Two-password access keeps the studio safer than a single password.</p>
            <p class="flex items-start gap-2"><i class="fa-solid fa-key mt-0.5 text-[10px] text-amber-400/50"></i>Passwords are stored as bcrypt hashes — never in plain text.</p>
            <p class="flex items-start gap-2"><i class="fa-solid fa-triangle-exclamation mt-0.5 text-[10px] text-amber-400/50"></i>Change the default installer passwords before going live.</p>
        </div>
    </aside>

    <section class="admin-card">
        <div class="border-b border-white/[0.06] px-5 py-3.5">
            <h3 class="text-[12px] font-medium text-white">Change passwords</h3>
            <p class="mt-0.5 text-[9px] text-white/25">Confirm your current passwords, then set two new ones.</p>
        </div>
        <form method="post" action="settings.php" class="space-y-5 p-5" data-lock>
            <?= admin_csrf_field() ?>
            <div>
                <p class="admin-label !mb-2 text-white/45">Current passwords</p>
                <div class="grid gap-3 sm:grid-cols-2">
                    <?php foreach (['current_password1' => 'Current password 1', 'current_password2' => 'Current password 2'] as $field => $label): ?>
                        <div>
                            <label for="<?= $field ?>" class="admin-label"><?= e($label) ?></label>
                            <div class="relative">
                                <input id="<?= $field ?>" name="<?= $field ?>" type="password" autocomplete="current-password" required class="admin-input pr-10">
                                <button type="button" class="absolute inset-y-0 right-0 flex w-10 items-center justify-center text-white/25 transition hover:text-amber-300" data-reveal="<?= $field ?>" aria-label="Show <?= e($label) ?>"><i class="fa-regular fa-eye text-[11px]"></i></button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="border-t border-white/[0.06] pt-5">
                <p class="admin-label !mb-2 text-white/45">New passwords</p>
                <div class="grid gap-3 sm:grid-cols-2">
                    <?php foreach (['new_password1' => 'New password 1', 'new_password2' => 'New password 2'] as $field => $label): ?>
                        <div>
                            <label for="<?= $field ?>" class="admin-label"><?= e($label) ?></label>
                            <div class="relative">
                                <input id="<?= $field ?>" name="<?= $field ?>" type="password" autocomplete="new-password" minlength="6" required class="admin-input pr-10">
                                <button type="button" class="absolute inset-y-0 right-0 flex w-10 items-center justify-center text-white/25 transition hover:text-amber-300" data-reveal="<?= $field ?>" aria-label="Show <?= e($label) ?>"><i class="fa-regular fa-eye text-[11px]"></i></button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <p class="mt-2 text-[8.5px] text-white/20">At least 6 characters each, and the two must differ.</p>
            </div>
            <div class="flex flex-col gap-2 border-t border-white/[0.06] pt-5 sm:flex-row sm:items-center sm:justify-between">
                <p class="flex items-center gap-2 text-[9px] text-white/20"><i class="fa-solid fa-lock text-[8px] text-emerald-400/50"></i>You'll stay signed in on this device.</p>
                <button type="submit" class="btn-gold !py-2.5 !text-[11px] sm:w-auto"><i class="fa-solid fa-check text-[9px]"></i><span data-btn-label>Update passwords</span></button>
            </div>
        </form>
    </section>
</div>

<script>
document.querySelectorAll('[data-reveal]').forEach(function (btn) {
    btn.addEventListener('click', function () {
        var input = document.getElementById(btn.dataset.reveal);
        if (!input) return;
        var show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        var icon = btn.querySelector('i');
        if (icon) icon.className = show ? 'fa-regular fa-eye-slash text-[11px]' : 'fa-regular fa-eye text-[11px]';
    });
});
</script>

<?php include __DIR__ . '/common/bottom.php'; ?>
