<?php
declare(strict_types=1);
require_once __DIR__ . '/common/config.php';
require_admin();

$allowedStatuses = ['pending', 'confirmed', 'delivered', 'cancelled'];

/* Handle actions */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_csrf_check();
    $action = (string) ($_POST['action'] ?? '');
    $orderId = (int) ($_POST['order_id'] ?? 0);
    $returnStatus = (string) ($_POST['return_status'] ?? '');
    $returnQ = trim((string) ($_POST['return_q'] ?? ''));
    $returnPage = max(1, (int) ($_POST['return_page'] ?? 1));
    $return = array_filter([
        'status' => in_array($returnStatus, $allowedStatuses, true) ? $returnStatus : '',
        'q' => mb_substr($returnQ, 0, 80),
        'page' => $returnPage,
    ], static fn ($value) => $value !== '');
    $returnUrl = 'orders.php' . ($return ? '?' . http_build_query($return) : '');

    if ($orderId <= 0) {
        flash('error', 'Invalid order selected.');
        redirect($returnUrl);
    }

    if ($action === 'status') {
        $newStatus = (string) ($_POST['status'] ?? '');
        if (!in_array($newStatus, $allowedStatuses, true)) {
            flash('error', 'Invalid order status.');
        } else {
            $stmt = $conn->prepare('UPDATE orders SET status = ? WHERE id = ?');
            $stmt->bind_param('si', $newStatus, $orderId);
            $stmt->execute();
            $stmt->close();
            flash('success', 'Order #NV' . str_pad((string) $orderId, 5, '0', STR_PAD_LEFT) . ' updated to ' . status_meta($newStatus)['label'] . '.');
        }
    } elseif ($action === 'delete') {
        $stmt = $conn->prepare('DELETE FROM orders WHERE id = ?');
        $stmt->bind_param('i', $orderId);
        $stmt->execute();
        $stmt->close();
        flash('success', 'Order #NV' . str_pad((string) $orderId, 5, '0', STR_PAD_LEFT) . ' deleted.');
    } else {
        flash('error', 'Unsupported action.');
    }

    redirect($returnUrl);
}

$statusFilter = (string) ($_GET['status'] ?? '');
if (!in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = '';
}
$q = trim((string) ($_GET['q'] ?? ''));
$q = mb_substr($q, 0, 80);
$page = max(1, (int) ($_GET['page'] ?? 1));
$viewId = (int) ($_GET['view'] ?? 0);
$perPage = 10;

/* Status counts */
$statusCounts = ['pending' => 0, 'confirmed' => 0, 'delivered' => 0, 'cancelled' => 0];
$result = $conn->query('SELECT status, COUNT(*) AS total FROM orders GROUP BY status');
while ($result && ($row = $result->fetch_assoc())) {
    $statusCounts[$row['status']] = (int) $row['total'];
}
$allCount = array_sum($statusCounts);

$where = [];
$params = [];
$types = '';
if ($statusFilter !== '') {
    $where[] = 'o.status = ?';
    $params[] = $statusFilter;
    $types .= 's';
}
if ($q !== '') {
    $where[] = '(o.customer_name LIKE ? OR o.mobile LIKE ? OR p.name LIKE ? OR o.id = ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like, (int) $q);
    $types .= 'sssi';
}
$whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

$countSql = 'SELECT COUNT(*) AS total FROM orders o LEFT JOIN products p ON p.id = o.product_id' . $whereSql;
$stmt = $conn->prepare($countSql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$filteredTotal = (int) ($stmt->get_result()->fetch_assoc()['total'] ?? 0);
$stmt->close();

$pages = max(1, (int) ceil($filteredTotal / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;

$listSql = 'SELECT o.*, p.name AS product_name, p.image AS product_image, p.category, p.contact_number
            FROM orders o LEFT JOIN products p ON p.id = o.product_id
            ' . $whereSql . '
            ORDER BY o.created_at DESC, o.id DESC LIMIT ? OFFSET ?';
$stmt = $conn->prepare($listSql);
$listParams = array_merge($params, [$perPage, $offset]);
$stmt->bind_param($types . 'ii', ...$listParams);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$filterLabels = ['' => 'All', 'pending' => 'Pending', 'confirmed' => 'Confirmed', 'delivered' => 'Delivered', 'cancelled' => 'Cancelled'];
$queryBase = array_filter(['status' => $statusFilter, 'q' => $q], static fn ($value) => $value !== '');

$page_title = 'Orders';
$admin_title = 'Orders';
$admin_active = 'orders';
?>
<?php include __DIR__ . '/common/header.php'; ?>

<div class="mb-5 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
    <div>
        <p class="text-[8.5px] font-medium uppercase tracking-[0.2em] text-amber-300/50">Order desk</p>
        <h2 class="mt-1.5 text-[20px] font-medium tracking-[-0.02em] text-white">All orders</h2>
        <p class="mt-1 text-[10.5px] text-white/30"><?= number_format($filteredTotal) ?> <?= $filteredTotal === 1 ? 'order' : 'orders' ?><?= $q !== '' ? ' matching “' . e($q) . '”' : '' ?>. Click a row to expand it.</p>
    </div>
    <form method="get" action="orders.php" class="relative w-full sm:w-auto">
        <?php if ($statusFilter !== ''): ?><input type="hidden" name="status" value="<?= e($statusFilter) ?>"><?php endif; ?>
        <input type="search" name="q" value="<?= e($q) ?>" maxlength="80" placeholder="Search name, mobile, product…" class="admin-input w-full py-2.5 pl-9 pr-20 text-[11px] sm:w-[270px]" aria-label="Search orders">
        <i class="fa-solid fa-magnifying-glass pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-[10px] text-white/25"></i>
        <button type="submit" class="absolute right-1.5 top-1/2 -translate-y-1/2 rounded-lg bg-amber-400/[0.08] px-2.5 py-1.5 text-[9px] font-medium text-amber-300/80 transition hover:bg-amber-400/15">Search</button>
    </form>
</div>

<div class="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:px-0">
    <?php foreach ($filterLabels as $key => $label): ?>
        <?php
            $count = $key === '' ? $allCount : ($statusCounts[$key] ?? 0);
            $href = 'orders.php' . ($key !== '' ? '?status=' . $key : '') . ($q !== '' ? ($key !== '' ? '&' : '?') . 'q=' . urlencode($q) : '');
        ?>
        <a href="<?= e($href) ?>" class="chip <?= $statusFilter === $key ? 'is-active' : '' ?>">
            <?= e($label) ?>
            <span class="<?= $statusFilter === $key ? 'text-amber-300/60' : 'text-white/20' ?>"><?= $count ?></span>
        </a>
    <?php endforeach; ?>
    <?php if ($q !== ''): ?>
        <a href="orders.php<?= $statusFilter !== '' ? '?status=' . e($statusFilter) : '' ?>" class="chip border-rose-400/20 text-rose-300/60 hover:border-rose-400/30 hover:text-rose-300"><i class="fa-solid fa-xmark text-[8px]"></i>Clear search</a>
    <?php endif; ?>
</div>

<?php if (!$orders): ?>
    <div class="admin-card mt-5 flex flex-col items-center px-6 py-16 text-center">
        <span class="grid h-14 w-14 place-items-center rounded-full border border-amber-400/15 bg-amber-400/[0.04] text-amber-300/60"><i class="fa-solid fa-receipt text-base"></i></span>
        <h3 class="mt-4 text-[14px] font-medium text-white/80">No orders found</h3>
        <p class="mt-1.5 max-w-[300px] text-[10.5px] leading-relaxed text-white/25">
            <?= ($statusFilter !== '' || $q !== '') ? 'Try a different status filter or search term.' : 'New orders will appear here as soon as customers check out.' ?>
        </p>
        <?php if ($statusFilter !== '' || $q !== ''): ?><a href="orders.php" class="btn-dark mt-5">Clear filters</a><?php endif; ?>
    </div>
<?php else: ?>
    <div class="mt-5 space-y-2.5">
        <?php foreach ($orders as $order): ?>
            <?php
                $meta = status_meta((string) $order['status']);
                $orderTotal = (float) $order['unit_price'] * (int) $order['quantity'];
                $isOpen = $viewId === (int) $order['id'];
                $tel = preg_replace('/[^0-9+]/', '', (string) ($order['mobile'] ?? '')) ?? '';
            ?>
            <details id="order-<?= (int) $order['id'] ?>" class="group admin-card overflow-hidden transition open:border-amber-400/20 open:bg-[#13110e]" <?= $isOpen ? 'open' : '' ?>>
                <summary class="flex cursor-pointer list-none items-center gap-3 p-3.5 sm:gap-4 sm:p-4">
                    <div class="hidden shrink-0 sm:block">
                        <?php if ($order['product_image']): ?>
                            <img src="<?= e(upload_url($order['product_image'], '../')) ?>" alt="<?= e($order['product_name'] ?? '') ?>" class="h-12 w-12 rounded-xl object-cover" data-fallback="../assets/img/placeholder.svg">
                        <?php else: ?>
                            <span class="grid h-12 w-12 place-items-center rounded-xl border border-white/[0.06] bg-white/[0.02] text-white/20"><i class="fa-solid fa-gem"></i></span>
                        <?php endif; ?>
                    </div>

                    <div class="min-w-0 flex-1">
                        <div class="flex flex-wrap items-center gap-2">
                            <span class="text-[9px] font-semibold uppercase tracking-[0.14em] text-amber-300/80">#NV<?= str_pad((string) $order['id'], 5, '0', STR_PAD_LEFT) ?></span>
                            <span class="badge-soft <?= e($meta['class']) ?> sm:hidden"><?= e($meta['label']) ?></span>
                        </div>
                        <p class="mt-1 truncate text-[12px] font-medium text-white/80"><?= e($order['customer_name']) ?> <span class="font-normal text-white/25">· <?= e($order['mobile']) ?></span></p>
                        <p class="mt-0.5 truncate text-[10px] text-white/30"><?= e($order['product_name'] ?? 'Unavailable product') ?> <span class="text-white/15">· Qty <?= (int) $order['quantity'] ?></span></p>
                        <p class="mt-1 text-[8.5px] text-white/20 sm:hidden"><?= e(format_date($order['created_at'], 'j M Y, g:i A')) ?></p>
                    </div>

                    <div class="hidden w-[96px] shrink-0 md:block">
                        <span class="badge-soft <?= e($meta['class']) ?>"><?= e($meta['label']) ?></span>
                    </div>
                    <div class="hidden w-[82px] shrink-0 text-[9px] text-white/25 md:block">
                        <?= e(format_date($order['created_at'], 'j M Y')) ?>
                    </div>

                    <div class="flex shrink-0 items-center gap-2.5">
                        <div class="text-right">
                            <p class="text-[12.5px] font-semibold text-amber-300"><?= e(money($orderTotal)) ?></p>
                            <p class="mt-0.5 text-[8px] uppercase tracking-[0.1em] text-white/20">Details</p>
                        </div>
                        <span class="grid h-7 w-7 place-items-center rounded-full border border-white/[0.08] text-white/30 transition group-open:rotate-180 group-open:border-amber-400/20 group-open:text-amber-300"><i class="fa-solid fa-chevron-down text-[8px]"></i></span>
                    </div>
                </summary>

                <div class="border-t border-white/[0.06] p-4 sm:p-5">
                    <div class="grid gap-5 lg:grid-cols-[1.15fr_.85fr]">
                        <div>
                            <div class="grid gap-4 sm:grid-cols-2">
                                <div>
                                    <p class="text-[8px] font-semibold uppercase tracking-[0.16em] text-white/25">Customer</p>
                                    <p class="mt-1.5 text-[11.5px] font-medium text-white/75"><?= e($order['customer_name']) ?></p>
                                    <p class="mt-0.5 text-[10px] text-white/35"><?= e($order['mobile']) ?></p>
                                    <a href="tel:<?= e($tel) ?>" class="mt-2 inline-flex items-center gap-1.5 text-[9px] text-amber-300/70 transition hover:text-amber-200"><i class="fa-solid fa-phone text-[8px]"></i>Call customer</a>
                                </div>
                                <div>
                                    <p class="text-[8px] font-semibold uppercase tracking-[0.16em] text-white/25">Delivery address</p>
                                    <p class="mt-1.5 whitespace-pre-line text-[10.5px] leading-relaxed text-white/45"><?= e($order['delivery_address']) ?></p>
                                </div>
                            </div>

                            <?php if (!empty($order['order_note'])): ?>
                                <div class="mt-4 rounded-xl border border-amber-400/10 bg-amber-400/[0.03] px-3.5 py-3">
                                    <p class="text-[8px] font-semibold uppercase tracking-[0.16em] text-amber-300/50">Customer note</p>
                                    <p class="mt-1 whitespace-pre-line text-[10.5px] leading-relaxed text-white/45"><?= e($order['order_note']) ?></p>
                                </div>
                            <?php endif; ?>

                            <div class="mt-4 flex flex-wrap items-center gap-2 border-t border-white/[0.06] pt-4">
                                <a href="orders.php?view=<?= (int) $order['id'] ?>" class="btn-dark !py-2 !text-[9.5px]"><i class="fa-regular fa-eye text-[9px]"></i>Permalink</a>
                                <?php if (!empty($order['product_id'])): ?>
                                    <a href="../product.php?id=<?= (int) $order['product_id'] ?>" target="_blank" rel="noopener" class="btn-dark !py-2 !text-[9.5px]"><i class="fa-solid fa-gem text-[9px]"></i>View product</a>
                                <?php endif; ?>
                                <span class="ml-auto text-[8.5px] text-white/20">Placed <?= e(format_date($order['created_at'], 'j M Y, g:i A')) ?></span>
                            </div>
                        </div>

                        <div class="rounded-xl border border-white/[0.06] bg-white/[0.015] p-4">
                            <p class="text-[8px] font-semibold uppercase tracking-[0.16em] text-white/25">Order value</p>
                            <div class="mt-2 space-y-1.5 text-[10px] text-white/35">
                                <div class="flex justify-between"><span><?= e(money((float) $order['unit_price'])) ?> × <?= (int) $order['quantity'] ?></span><span class="text-white/55"><?= e(money($orderTotal)) ?></span></div>
                                <div class="flex justify-between"><span>Payment</span><span class="text-white/55">Cash on delivery</span></div>
                                <div class="flex justify-between border-t border-white/[0.06] pt-2 text-[12px]"><span class="text-white/45">Total</span><span class="font-semibold text-amber-300"><?= e(money($orderTotal)) ?></span></div>
                            </div>

                            <div class="mt-4 border-t border-white/[0.06] pt-4">
                                <label class="admin-label">Update status</label>
                                <form method="post" action="orders.php" class="flex gap-2">
                                    <?= admin_csrf_field() ?>
                                    <input type="hidden" name="action" value="status">
                                    <input type="hidden" name="order_id" value="<?= (int) $order['id'] ?>">
                                    <input type="hidden" name="return_status" value="<?= e($statusFilter) ?>">
                                    <input type="hidden" name="return_q" value="<?= e($q) ?>">
                                    <input type="hidden" name="return_page" value="<?= (int) $page ?>">
                                    <select name="status" class="admin-select min-w-0 flex-1 text-[10.5px]">
                                        <?php foreach (['pending', 'confirmed', 'delivered', 'cancelled'] as $statusOption): ?>
                                            <option value="<?= $statusOption ?>" <?= $order['status'] === $statusOption ? 'selected' : '' ?>><?= e(status_meta($statusOption)['label']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" class="rounded-lg bg-amber-400 px-3 py-2 text-[9.5px] font-semibold text-[#1a1408] transition hover:bg-amber-300">Update</button>
                                </form>
                            </div>

                            <form method="post" action="orders.php" class="mt-2.5" data-confirm="Delete order #NV<?= str_pad((string) $order['id'], 5, '0', STR_PAD_LEFT) ?>? This cannot be undone.">
                                <?= admin_csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="order_id" value="<?= (int) $order['id'] ?>">
                                <input type="hidden" name="return_status" value="<?= e($statusFilter) ?>">
                                <input type="hidden" name="return_q" value="<?= e($q) ?>">
                                <input type="hidden" name="return_page" value="<?= (int) $page ?>">
                                <button type="submit" class="flex w-full items-center justify-center gap-2 rounded-lg border border-rose-400/15 bg-rose-400/[0.03] px-3 py-2 text-[9.5px] text-rose-300/60 transition hover:border-rose-400/30 hover:text-rose-300"><i class="fa-regular fa-trash-can text-[9px]"></i>Delete order</button>
                            </form>
                        </div>
                    </div>
                </div>
            </details>
        <?php endforeach; ?>
    </div>

    <?php if ($pages > 1): ?>
        <div class="mt-6 flex items-center justify-between gap-3">
            <p class="text-[9px] text-white/25">Page <?= $page ?> of <?= $pages ?></p>
            <div class="flex items-center gap-1.5">
                <?php if ($page > 1): ?>
                    <?php $prevQuery = http_build_query(array_merge($queryBase, ['page' => $page - 1])); ?>
                    <a href="orders.php?<?= e($prevQuery) ?>" class="grid h-8 w-8 place-items-center rounded-lg border border-white/10 text-white/35 transition hover:border-amber-400/30 hover:text-amber-300"><i class="fa-solid fa-chevron-left text-[8px]"></i></a>
                <?php endif; ?>
                <?php for ($i = max(1, $page - 2); $i <= min($pages, $page + 2); $i++): ?>
                    <?php $pageQuery = http_build_query(array_merge($queryBase, ['page' => $i])); ?>
                    <a href="orders.php?<?= e($pageQuery) ?>" class="grid h-8 min-w-8 place-items-center rounded-lg border px-2 text-[10px] transition <?= $i === $page ? 'border-amber-400/40 bg-amber-400/[0.08] text-amber-300' : 'border-white/10 text-white/30 hover:border-white/20 hover:text-white/60' ?>"><?= $i ?></a>
                <?php endfor; ?>
                <?php if ($page < $pages): ?>
                    <?php $nextQuery = http_build_query(array_merge($queryBase, ['page' => $page + 1])); ?>
                    <a href="orders.php?<?= e($nextQuery) ?>" class="grid h-8 w-8 place-items-center rounded-lg border border-white/10 text-white/35 transition hover:border-amber-400/30 hover:text-amber-300"><i class="fa-solid fa-chevron-right text-[8px]"></i></a>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php if ($viewId > 0): ?>
<script>
(function () {
    var target = document.getElementById('order-<?= $viewId ?>');
    if (target) target.scrollIntoView({ behavior: 'smooth', block: 'center' });
})();
</script>
<?php endif; ?>

<?php include __DIR__ . '/common/bottom.php'; ?>
