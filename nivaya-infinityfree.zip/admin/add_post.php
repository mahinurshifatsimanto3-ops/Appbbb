<?php
declare(strict_types=1);
require_once __DIR__ . '/common/config.php';
require_admin();

$categories = product_categories($conn);
$errors = [];
$formValues = [
    'name' => '',
    'category' => '',
    'original_price' => '',
    'discount_percent' => '0',
    'description' => '',
    'contact_number' => '',
];
$existingImage = null;
$isEdit = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_csrf_check();

    $formValues['name']            = trim((string) ($_POST['name'] ?? ''));
    $formValues['category']        = trim((string) ($_POST['category'] ?? ''));
    $formValues['original_price']  = trim((string) ($_POST['original_price'] ?? ''));
    $formValues['discount_percent'] = trim((string) ($_POST['discount_percent'] ?? '0'));
    $formValues['description']     = trim((string) ($_POST['description'] ?? ''));
    $formValues['contact_number']  = trim((string) ($_POST['contact_number'] ?? ''));

    if (mb_strlen($formValues['name']) < 2 || mb_strlen($formValues['name']) > 150) {
        $errors[] = 'Product name must be between 2 and 150 characters.';
    }
    if (mb_strlen($formValues['category']) < 2 || mb_strlen($formValues['category']) > 100) {
        $errors[] = 'Category must be between 2 and 100 characters.';
    }
    if (!is_numeric($formValues['original_price']) || (float) $formValues['original_price'] <= 0 || (float) $formValues['original_price'] > 9999999) {
        $errors[] = 'Enter a valid original price greater than zero.';
    }
    if (!preg_match('/^\d{1,3}$/', $formValues['discount_percent']) || (int) $formValues['discount_percent'] > 100) {
        $errors[] = 'Discount must be a whole number between 0 and 100.';
    }
    if (mb_strlen($formValues['description']) < 10 || mb_strlen($formValues['description']) > 5000) {
        $errors[] = 'Description must be between 10 and 5,000 characters.';
    }
    if (!preg_match('/^[0-9+\-\s]{7,20}$/', $formValues['contact_number'])) {
        $errors[] = 'Enter a valid contact number (7–20 digits, + and spaces allowed).';
    }

    $imageName = null;
    if (!$errors) {
        [$imageName, $uploadError] = admin_upload_image($_FILES['image'] ?? []);
        if ($uploadError) {
            $errors[] = $uploadError;
        } elseif ($imageName === null) {
            $errors[] = 'Please upload a product image.';
        }
    }

    if (!$errors) {
        $name = $formValues['name'];
        $category = $formValues['category'];
        $originalPrice = round((float) $formValues['original_price'], 2);
        $discount = (int) $formValues['discount_percent'];
        $discountedPrice = round($originalPrice * (1 - $discount / 100));
        $description = $formValues['description'];
        $contact = $formValues['contact_number'];

        try {
            $stmt = $conn->prepare(
                'INSERT INTO products (name, category, original_price, discount_percent, discounted_price, description, contact_number, image)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->bind_param(
                'ssdidsss',
                $name,
                $category,
                $originalPrice,
                $discount,
                $discountedPrice,
                $description,
                $contact,
                $imageName
            );
            $stmt->execute();
            $stmt->close();

            flash('success', '“' . $name . '” is now live in the collection.');
            redirect('posts.php');
        } catch (Throwable $e) {
            error_log('Add product failed: ' . $e->getMessage());
            if ($imageName) {
                @unlink(UPLOADS_DIR . '/' . $imageName);
            }
            $errors[] = 'Could not save the product. Please try again.';
        }
    }
}

$page_title = 'Add product';
$admin_title = 'Add product';
$admin_active = 'add';
?>
<?php include __DIR__ . '/common/header.php'; ?>

<div class="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
    <div>
        <a href="posts.php" class="inline-flex items-center gap-1.5 text-[9px] text-white/25 transition hover:text-amber-300"><i class="fa-solid fa-arrow-left text-[8px]"></i>Back to products</a>
        <h2 class="mt-2 text-[20px] font-medium tracking-[-0.02em] text-white">Add a new piece</h2>
        <p class="mt-1 text-[10.5px] text-white/30">A great photograph and a thoughtful description do most of the selling.</p>
    </div>
    <span class="hidden items-center gap-1.5 rounded-full border border-white/[0.07] px-3 py-1.5 text-[8.5px] uppercase tracking-[0.14em] text-white/25 sm:inline-flex"><i class="fa-solid fa-gem text-[8px] text-amber-400/50"></i>New product</span>
</div>

<?php if ($errors): ?>
    <div class="alert-in mb-4 rounded-2xl border border-rose-400/20 bg-rose-400/[0.06] px-4 py-3.5" role="alert">
        <div class="flex items-start gap-3 text-[12px] text-rose-200">
            <i class="fa-solid fa-circle-exclamation mt-0.5 text-rose-400"></i>
            <div>
                <p class="font-medium">Please fix the following</p>
                <ul class="mt-1.5 list-disc space-y-1 pl-4 text-[11px] leading-relaxed text-rose-200/70">
                    <?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif; ?>

<form method="post" action="add_post.php" enctype="multipart/form-data" data-lock>
    <?= admin_csrf_field() ?>
    <?php include __DIR__ . '/common/product_form.php'; ?>
</form>

<?php include __DIR__ . '/common/bottom.php'; ?>
