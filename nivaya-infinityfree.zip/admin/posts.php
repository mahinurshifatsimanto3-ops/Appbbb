<?php
declare(strict_types=1);
require_once __DIR__ . '/common/config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_csrf_check();
    $action = (string) ($_POST['action'] ?? '');
    $productId = (int) ($_POST['product_id'] ?? 0);
    $returnQ = trim((string) ($_POST['return_q'] ?? ''));
    $returnQ = mb_substr($returnQ, 0, 80);
    $returnPage = max(1, (int) ($_POST['return_page'] ?? 1));
    $returnUrl = 'posts.php?' . http_build_query(array_filter(['q' => $returnQ, 'page' => $returnPage], static fn ($v) => $v !== ''));

    if ($productId <= 0) {
        flash('error', 'Invalid product selected.');
        redirect($returnUrl);
    }

    if ($action === 'delete') {
        $product = find_product($conn, $productId);
        if (!$product) {
            flash('error', 'That product no longer exists.');
            redirect($returnUrl);
        }
        $stmt = $conn->prepare('DELETE FROM products WHERE id = ?');
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        $stmt->close();

        /* Clean up generated uploads only — never remove the bundled editorial art. */
        $image = basename((string) $product['image']);
        if ($image !== '' && preg_match('/^[a-f0-9]{24}\.(jpg|png|webp)$/', $image) === 1) {
            $path = UPLOADS_DIR . '/' . $image;
            if (is_file($path)) {
                @unlink($path);
            }
        }

        flash('success', '“' . $product['name'] . '” has been removed from the catalogue.');
    } else {
        flash('error', 'Unsupported action.');
    }
    redirect($returnUrl);
}

$q = trim((string) ($_GET['q'] ?? ''));
$q = mb_substr($q, 0, 80);
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;

$where = '';
$params = [];
$types = '';
if ($q !== '') {
    $where = ' WHERE name LIKE ? OR category LIKE ?';
    $like = '%' . $q . '%';
    $params = [$like, $like];
    $types = 'ss';
}

$countSql = 'SELECT COUNT(*) AS total FROM products' . $where;
$stmt = $conn->prepare($countSql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$total = (int) ($stmt->get_result()->fetch_assoc()['total'] ?? 0);
$stmt->close();

$totalAll = (int) $conn->query('SELECT COUNT(*) AS c FROM products')->fetch_assoc()['c'];
$pages = max(1, (int) ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;

$sql = 'SELECT p.*, (SELECT COUNT(*) FROM product_views v WHERE v.product_id = p.id) AS views
        FROM products p' . $where . '
        ORDER BY p.created_at DESC, p.id DESC LIMIT ? OFFSET ?';
$stmt = $conn->prepare($sql);
$listParams = array_merge($params, [$perPage, $offset]);
$stmt->bind_param($types . 'ii', ...$listParams);
$stmt->execute();
$products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$page_title = 'Products';
$admin_title = 'Products';
$admin_active = 'products';
?>
<?php include __DIR__ . '/common/header.php'; ?>

<div class="mb-5 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
    <div>
        <p class="text-[8.5px] font-medium uppercase tracking-[0.2em] text-amber-300/50">Catalogue</p>
        <h2 class="mt-1.5 text-[20px] font-medium tracking-[-0.02em] text-white">Products</h2>
        <p class="mt-1 text-[10.5px] text-white/30"><?= number_format($totalAll) ?> <?= $totalAll === 1 ? 'piece' : 'pieces' ?> in the collection<?= $q !== '' ? ' · ' . number_format($total) . ' matching “' . e($q) . '”' : '' ?>.</p>
    </div>
    <div class="flex flex-col gap-2 sm:flex-row sm:items-center">
        <form method="get" action="posts.php" class="relative">
            <input type="search" name="q" value="<?= e($q) ?>" maxlength="80" placeholder="Search products…" class="admin-input w-full py-2.5 pl-9 pr-16 text-[11px] sm:w-[210px]" aria-label="Search products">
            <i class="fa-solid fa-magnifying-glass pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-[10px] text-white/25"></i>
            <button type="submit" class="absolute right-1.5 top-1/2 -translate-y-1/2 rounded-lg bg-amber-400/[0.08] px-2.5 py-1.5 text-[9px] font-medium text-amber-300/80 transition hover:bg-amber-400/15">Go</button>
        </form>
        <a href="add_post.php" class="btn-gold !py-2.5 !text-[11px]"><i class="fa-solid fa-plus text-[9px]"></i>Add product</a>
    </div>
</div>

<?php if ($q !== ''): ?>
    <div class="mb-4 flex items-center gap-2 text-[10px] text-white/30">
        <span>Search results for “<?= e($q) ?>”</span>
        <a href="posts.php" class="text-amber-300/70 underline decoration-amber-400/20 underline-offset-2 hover:text-amber-200">Clear</a>
    </div>
<?php endif; ?>

<?php if (!$products): ?>
    <div class="admin-card flex flex-col items-center px-6 py-16 text-center">
        <span class="grid h-14 w-14 place-items-center rounded-full border border-amber-400/15 bg-amber-400/[0.04] text-amber-300/60"><i class="fa-solid fa-gem text-base"></i></span>
        <h3 class="mt-4 text-[14px] font-medium text-white/80">No products found</h3>
        <p class="mt-1.5 max-w-[300px] text-[10.5px] leading-relaxed text-white/25"><?= $q !== '' ? 'Try a different search term, or add a new piece.' : 'Add your first piece to open the collection.' ?></p>
        <a href="add_post.php" class="btn-gold mt-5"><i class="fa-solid fa-plus text-[9px]"></i>Add product</a>
    </div>
<?php else: ?>
    <!-- Desktop table -->
    <div class="admin-card hidden overflow-hidden md:block">
        <div class="overflow-x-auto">
            <table class="w-full min-w-[760px] text-left">
                <thead class="table-head">
                    <tr>
                        <th class="px-4 py-3">Piece</th>
                        <th class="px-3 py-3">Category</th>
                        <th class="px-3 py-3">Price</th>
                        <th class="px-3 py-3">Discount</th>
                        <th class="px-3 py-3">Views</th>
                        <th class="px-4 py-3 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-white/[0.04]">
                    <?php foreach ($products as $product): ?>
                        <?php $off = discount_percent($product); ?>
                        <tr class="transition hover:bg-white/[0.015]">
                            <td class="px-4 py-3">
                                <div class="flex items-center gap-3">
                                    <img src="<?= e(upload_url($product['image'], '../')) ?>" alt="<?= e($product['name']) ?>" class="h-12 w-12 shrink-0 rounded-lg object-cover" data-fallback="../assets/img/placeholder.svg">
                                    <div class="min-w-0">
                                        <p class="max-w-[220px] truncate text-[11px] font-medium text-white/80"><?= e($product['name']) ?></p>
                                        <p class="mt-0.5 max-w-[220px] truncate text-[8.5px] text-white/25">Added <?= e(format_date($product['created_at'], 'j M Y')) ?> · NV-<?= str_pad((string) $product['id'], 4, '0', STR_PAD_LEFT) ?></p>
                                    </div>
                                </div>
                            </td>
                            <td class="px-3 py-3"><span class="rounded-full border border-white/[0.07] bg-white/[0.02] px-2.5 py-1 text-[8.5px] text-white/40"><?= e($product['category']) ?></span></td>
                            <td class="whitespace-nowrap px-3 py-3">
                                <p class="text-[11px] font-medium text-amber-300/90"><?= e(money(product_price($product))) ?></p>
                                <?php if ($off > 0): ?><p class="text-[8.5px] text-white/20 line-through"><?= e(money((float) $product['original_price'])) ?></p><?php endif; ?>
                            </td>
                            <td class="px-3 py-3">
                                <?php if ($off > 0): ?>
                                    <span class="rounded-full border border-emerald-400/15 bg-emerald-400/[0.05] px-2 py-0.5 text-[8.5px] font-medium text-emerald-300/80"><?= $off ?>% off</span>
                                <?php else: ?>
                                    <span class="text-[9px] text-white/20">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-3 py-3 text-[10px] text-white/40"><i class="fa-regular fa-eye mr-1.5 text-[8px] text-amber-400/40"></i><?= number_format((int) $product['views']) ?></td>
                            <td class="px-4 py-3">
                                <div class="flex items-center justify-end gap-1">
                                    <a href="../product.php?id=<?= (int) $product['id'] ?>" target="_blank" rel="noopener" class="grid h-7 w-7 place-items-center rounded-lg border border-white/[0.08] text-white/30 transition hover:border-white/20 hover:text-white/70" title="View product"><i class="fa-solid fa-arrow-up-right-from-square text-[8px]"></i></a>
                                    <a href="edit_post.php?id=<?= (int) $product['id'] ?>" class="grid h-7 w-7 place-items-center rounded-lg border border-white/[0.08] text-white/30 transition hover:border-amber-400/30 hover:text-amber-300" title="Edit product"><i class="fa-solid fa-pen text-[8px]"></i></a>
                                    <form method="post" action="posts.php" class="inline" data-confirm="Delete “<?= e($product['name']) ?>”? Related orders will keep their history. This cannot be undone.">
                                        <?= admin_csrf_field() ?>
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="product_id" value="<?= (int) $product['id'] ?>">
                                        <input type="hidden" name="return_q" value="<?= e($q) ?>">
                                        <input type="hidden" name="return_page" value="<?= (int) $page ?>">
                                        <button type="submit" class="grid h-7 w-7 place-items-center rounded-lg border border-white/[0.08] text-white/30 transition hover:border-rose-400/30 hover:text-rose-300" title="Delete product"><i class="fa-regular fa-trash-can text-[8px]"></i></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Mobile cards -->
    <div class="space-y-2.5 md:hidden">
        <?php foreach ($products as $product): ?>
            <?php $off = discount_percent($product); ?>
            <div class="admin-card p-3.5">
                <div class="flex gap-3.5">
                    <img src="<?= e(upload_url($product['image'], '../')) ?>" alt="<?= e($product['name']) ?>" class="h-[76px] w-[76px] shrink-0 rounded-xl object-cover" data-fallback="../assets/img/placeholder.svg">
                    <div class="min-w-0 flex-1">
                        <div class="flex items-start justify-between gap-2">
                            <p class="text-[11.5px] font-medium leading-snug text-white/80"><?= e($product['name']) ?></p>
                            <?php if ($off > 0): ?><span class="shrink-0 rounded-full border border-emerald-400/15 bg-emerald-400/[0.05] px-1.5 py-0.5 text-[7.5px] font-medium text-emerald-300/80"><?= $off ?>%</span><?php endif; ?>
                        </div>
                        <p class="mt-1 text-[9px] text-white/25"><?= e($product['category']) ?></p>
                        <div class="mt-1.5 flex items-baseline gap-2">
                            <span class="text-[12px] font-semibold text-amber-300"><?= e(money(product_price($product))) ?></span>
                            <?php if ($off > 0): ?><span class="text-[8.5px] text-white/20 line-through"><?= e(money((float) $product['original_price'])) ?></span><?php endif; ?>
                        </div>
                        <p class="mt-1 text-[8.5px] text-white/25"><i class="fa-regular fa-eye mr-1 text-[7px] text-amber-400/40"></i><?= number_format((int) $product['views']) ?> views</p>
                    </div>
                </div>
                <div class="mt-3 flex items-center gap-2 border-t border-white/[0.05] pt-3">
                    <a href="edit_post.php?id=<?= (int) $product['id'] ?>" class="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-white/[0.08] py-2 text-[9px] text-white/40 transition hover:border-amber-400/30 hover:text-amber-300"><i class="fa-solid fa-pen text-[8px]"></i>Edit</a>
                    <a href="../product.php?id=<?= (int) $product['id'] ?>" target="_blank" rel="noopener" class="grid h-8 w-8 place-items-center rounded-lg border border-white/[0.08] text-white/30"><i class="fa-solid fa-arrow-up-right-from-square text-[8px]"></i></a>
                    <form method="post" action="posts.php" data-confirm="Delete “<?= e($product['name']) ?>”? This cannot be undone.">
                        <?= admin_csrf_field() ?>
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="product_id" value="<?= (int) $product['id'] ?>">
                        <input type="hidden" name="return_q" value="<?= e($q) ?>">
                        <input type="hidden" name="return_page" value="<?= (int) $page ?>">
                        <button type="submit" class="grid h-8 w-8 place-items-center rounded-lg border border-white/[0.08] text-white/30 transition hover:border-rose-400/30 hover:text-rose-300"><i class="fa-regular fa-trash-can text-[8px]"></i></button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <?php if ($pages > 1): ?>
        <div class="mt-6 flex items-center justify-between gap-3">
            <p class="text-[9px] text-white/25">Page <?= $page ?> of <?= $pages ?></p>
            <div class="flex items-center gap-1.5">
                <?php for ($i = 1; $i <= $pages; $i++): ?>
                    <?php $pageQuery = http_build_query(array_filter(['q' => $q, 'page' => $i], static fn ($v) => $v !== '')); ?>
                    <a href="posts.php?<?= e($pageQuery) ?>" class="grid h-8 min-w-8 place-items-center rounded-lg border px-2 text-[10px] transition <?= $i === $page ? 'border-amber-400/40 bg-amber-400/[0.08] text-amber-300' : 'border-white/10 text-white/30 hover:border-white/20 hover:text-white/60' ?>"><?= $i ?></a>
                <?php endfor; ?>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php include __DIR__ . '/common/bottom.php'; ?>
