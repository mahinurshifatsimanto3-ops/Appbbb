<?php
declare(strict_types=1);
require_once __DIR__ . '/common/config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_csrf_check();
    $action = (string) ($_POST['action'] ?? '');
    $orderId = (int) ($_POST['order_id'] ?? 0);

    if ($orderId > 0 && $action === 'deliver') {
        $stmt = $conn->prepare("UPDATE orders SET status = 'delivered' WHERE id = ?");
        $stmt->bind_param('i', $orderId);
        $stmt->execute();
        $updated = $stmt->affected_rows;
        $stmt->close();
        flash($updated > 0 ? 'success' : 'error', $updated > 0 ? 'Order #NV' . str_pad((string) $orderId, 5, '0', STR_PAD_LEFT) . ' marked as delivered.' : 'Order could not be updated.');
    } elseif ($orderId > 0 && $action === 'delete') {
        $stmt = $conn->prepare('DELETE FROM orders WHERE id = ?');
        $stmt->bind_param('i', $orderId);
        $stmt->execute();
        $deleted = $stmt->affected_rows;
        $stmt->close();
        flash($deleted > 0 ? 'success' : 'error', $deleted > 0 ? 'Order deleted permanently.' : 'Order could not be deleted.');
    } else {
        flash('error', 'Invalid action.');
    }
    redirect('index.php');
}

$totalOrders   = (int) $conn->query('SELECT COUNT(*) AS c FROM orders')->fetch_assoc()['c'];
$totalProducts = (int) $conn->query('SELECT COUNT(*) AS c FROM products')->fetch_assoc()['c'];
$totalUsers    = (int) $conn->query('SELECT COUNT(*) AS c FROM users')->fetch_assoc()['c'];
$pendingCount  = (int) $conn->query("SELECT COUNT(*) AS c FROM orders WHERE status = 'pending'")->fetch_assoc()['c'];
$deliveredCount = (int) $conn->query("SELECT COUNT(*) AS c FROM orders WHERE status = 'delivered'")->fetch_assoc()['c'];

$recentOrders = [];
$result = $conn->query(
    'SELECT o.*, p.name AS product_name, p.image AS product_image
     FROM orders o LEFT JOIN products p ON p.id = o.product_id
     ORDER BY o.created_at DESC, o.id DESC LIMIT 10'
);
if ($result) {
    $recentOrders = $result->fetch_all(MYSQLI_ASSOC);
}

$mostViewed = [];
$result = $conn->query(
    'SELECT p.id, p.name, p.category, p.image, p.discount_percent, p.original_price, p.discounted_price,
            COUNT(v.id) AS views
     FROM products p LEFT JOIN product_views v ON v.product_id = p.id
     GROUP BY p.id
     ORDER BY views DESC, p.created_at DESC
     LIMIT 5'
);
if ($result) {
    $mostViewed = $result->fetch_all(MYSQLI_ASSOC);
}

$page_title = 'Dashboard';
$admin_title = 'Dashboard';
$admin_active = 'dashboard';
$hour = (int) date('G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');
?>
<?php include __DIR__ . '/common/header.php'; ?>

<!-- Greeting -->
<div class="relative mb-5 overflow-hidden rounded-2xl border border-white/[0.08] bg-[#12110f]">
    <div class="pointer-events-none absolute -right-20 -top-24 h-64 w-64 rounded-full bg-amber-500/[0.07] blur-3xl"></div>
    <div class="relative flex flex-col justify-between gap-4 p-5 sm:flex-row sm:items-center sm:p-6">
        <div>
            <div class="flex items-center gap-2 text-[8.5px] font-medium uppercase tracking-[0.2em] text-amber-300/60">
                <span class="h-1 w-1 rounded-full bg-amber-400"></span><?= e(date('l, j F Y')) ?>
            </div>
            <h2 class="mt-2 text-[21px] font-medium tracking-[-0.02em] text-white sm:text-[24px]"><?= e($greeting) ?>, <?= e($_SESSION['admin_username'] ?? 'admin') ?>.</h2>
            <p class="mt-1 text-[11px] text-white/35">
                <?php if ($pendingCount > 0): ?>
                    You have <span class="font-medium text-amber-300"><?= $pendingCount ?> pending <?= $pendingCount === 1 ? 'order' : 'orders' ?></span> waiting for confirmation.
                <?php else: ?>
                    Everything is up to date. No pending orders right now.
                <?php endif; ?>
            </p>
        </div>
        <a href="add_post.php" class="btn-gold self-start sm:self-auto"><i class="fa-solid fa-plus text-[10px]"></i>Add new product</a>
    </div>
</div>

<!-- Stats -->
<div class="grid gap-3.5 sm:grid-cols-3">
    <div class="relative overflow-hidden rounded-2xl border border-white/[0.07] bg-[#12110f] p-5">
        <div class="flex items-start justify-between">
            <span class="grid h-9 w-9 place-items-center rounded-xl border border-amber-400/15 bg-amber-400/[0.06] text-amber-300/80"><i class="fa-solid fa-receipt text-[13px]"></i></span>
            <?php if ($pendingCount > 0): ?>
                <span class="rounded-full border border-amber-400/20 bg-amber-400/[0.07] px-2 py-0.5 text-[8px] font-medium text-amber-300"><?= $pendingCount ?> pending</span>
            <?php else: ?>
                <span class="rounded-full border border-emerald-400/15 bg-emerald-400/[0.05] px-2 py-0.5 text-[8px] font-medium text-emerald-300/80">All clear</span>
            <?php endif; ?>
        </div>
        <p class="mt-4 text-[27px] font-semibold tracking-tight text-white"><?= number_format($totalOrders) ?></p>
        <p class="mt-0.5 text-[10px] uppercase tracking-[0.14em] text-white/25">Total orders</p>
        <div class="mt-4 flex items-center gap-2 border-t border-white/[0.05] pt-3 text-[9px] text-white/25">
            <i class="fa-solid fa-check text-[8px] text-emerald-400/50"></i><?= $deliveredCount ?> delivered till date
        </div>
    </div>

    <div class="relative overflow-hidden rounded-2xl border border-white/[0.07] bg-[#12110f] p-5">
        <div class="flex items-start justify-between">
            <span class="grid h-9 w-9 place-items-center rounded-xl border border-sky-400/15 bg-sky-400/[0.05] text-sky-300/80"><i class="fa-solid fa-gem text-[13px]"></i></span>
            <a href="posts.php" class="text-[9px] text-white/25 transition hover:text-amber-300">Manage <i class="fa-solid fa-arrow-right text-[7px]"></i></a>
        </div>
        <p class="mt-4 text-[27px] font-semibold tracking-tight text-white"><?= number_format($totalProducts) ?></p>
        <p class="mt-0.5 text-[10px] uppercase tracking-[0.14em] text-white/25">Products live</p>
        <div class="mt-4 flex items-center gap-2 border-t border-white/[0.05] pt-3 text-[9px] text-white/25">
            <i class="fa-solid fa-clock-rotate-left text-[8px] text-amber-400/50"></i>Updated from the studio
        </div>
    </div>

    <div class="relative overflow-hidden rounded-2xl border border-white/[0.07] bg-[#12110f] p-5">
        <div class="flex items-start justify-between">
            <span class="grid h-9 w-9 place-items-center rounded-xl border border-emerald-400/15 bg-emerald-400/[0.05] text-emerald-300/80"><i class="fa-solid fa-users text-[13px]"></i></span>
            <span class="rounded-full border border-white/[0.08] px-2 py-0.5 text-[8px] text-white/25">Registered</span>
        </div>
        <p class="mt-4 text-[27px] font-semibold tracking-tight text-white"><?= number_format($totalUsers) ?></p>
        <p class="mt-0.5 text-[10px] uppercase tracking-[0.14em] text-white/25">Customer accounts</p>
        <div class="mt-4 flex items-center gap-2 border-t border-white/[0.05] pt-3 text-[9px] text-white/25">
            <i class="fa-solid fa-user-plus text-[8px] text-emerald-400/50"></i>Growing the NIVAYA circle
        </div>
    </div>
</div>

<!-- Quick links -->
<div class="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-3">
    <a href="orders.php" class="flex items-center gap-2.5 rounded-xl border border-white/[0.07] bg-white/[0.015] px-3.5 py-3 text-[10.5px] text-white/45 transition hover:border-amber-400/20 hover:bg-white/[0.03] hover:text-white/80">
        <i class="fa-solid fa-list-check text-[11px] text-amber-400/60"></i>View all orders
    </a>
    <a href="posts.php" class="flex items-center gap-2.5 rounded-xl border border-white/[0.07] bg-white/[0.015] px-3.5 py-3 text-[10.5px] text-white/45 transition hover:border-amber-400/20 hover:bg-white/[0.03] hover:text-white/80">
        <i class="fa-solid fa-gem text-[11px] text-amber-400/60"></i>View all products
    </a>
    <a href="add_post.php" class="flex items-center gap-2.5 rounded-xl border border-white/[0.07] bg-white/[0.015] px-3.5 py-3 text-[10.5px] text-white/45 transition hover:border-amber-400/20 hover:bg-white/[0.03] hover:text-white/80">
        <i class="fa-solid fa-plus text-[11px] text-amber-400/60"></i>Add new product
    </a>
</div>

<div class="mt-5 grid gap-4 2xl:grid-cols-[1.55fr_1fr]">
    <!-- Recent orders -->
    <section class="admin-card overflow-hidden">
        <div class="flex items-center justify-between gap-3 border-b border-white/[0.06] px-4 py-3.5 sm:px-5">
            <div>
                <h3 class="text-[12px] font-medium text-white">Recent orders</h3>
                <p class="mt-0.5 text-[9px] text-white/25">The latest 10 orders across the store</p>
            </div>
            <a href="orders.php" class="hidden items-center gap-1.5 text-[9.5px] text-amber-300/70 transition hover:text-amber-200 sm:inline-flex">View all <i class="fa-solid fa-arrow-right text-[8px]"></i></a>
        </div>

        <?php if (!$recentOrders): ?>
            <div class="flex flex-col items-center px-6 py-14 text-center">
                <span class="grid h-12 w-12 place-items-center rounded-full border border-white/[0.08] bg-white/[0.02] text-white/20"><i class="fa-solid fa-receipt"></i></span>
                <p class="mt-3.5 text-[12px] font-medium text-white/60">No orders yet</p>
                <p class="mt-1 max-w-[240px] text-[10px] leading-relaxed text-white/25">New customer orders will appear here the moment they're placed.</p>
            </div>
        <?php else: ?>
            <!-- Desktop table -->
            <div class="hidden overflow-x-auto md:block">
                <table class="w-full min-w-[620px] text-left">
                    <thead class="table-head">
                        <tr>
                            <th class="px-4 py-2.5">Order</th>
                            <th class="px-3 py-2.5">Customer</th>
                            <th class="px-3 py-2.5">Product</th>
                            <th class="px-3 py-2.5">Status</th>
                            <th class="px-3 py-2.5">Date</th>
                            <th class="px-4 py-2.5 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-white/[0.04]">
                        <?php foreach ($recentOrders as $order): ?>
                            <?php $meta = status_meta((string) $order['status']); ?>
                            <tr class="transition hover:bg-white/[0.015]">
                                <td class="px-4 py-3">
                                    <a href="orders.php?view=<?= (int) $order['id'] ?>" class="text-[10px] font-medium text-amber-300/90 hover:text-amber-200">#NV<?= str_pad((string) $order['id'], 5, '0', STR_PAD_LEFT) ?></a>
                                </td>
                                <td class="px-3 py-3">
                                    <p class="max-w-[130px] truncate text-[10.5px] font-medium text-white/75"><?= e($order['customer_name']) ?></p>
                                    <p class="mt-0.5 text-[9px] text-white/25"><?= e($order['mobile']) ?></p>
                                </td>
                                <td class="px-3 py-3">
                                    <p class="max-w-[150px] truncate text-[10px] text-white/45"><?= e($order['product_name'] ?? 'Unavailable') ?></p>
                                </td>
                                <td class="px-3 py-3"><span class="badge-soft <?= e($meta['class']) ?>"><?= e($meta['label']) ?></span></td>
                                <td class="whitespace-nowrap px-3 py-3 text-[9.5px] text-white/30"><?= e(format_date($order['created_at'], 'j M Y')) ?></td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center justify-end gap-1">
                                        <a href="orders.php?view=<?= (int) $order['id'] ?>" class="grid h-7 w-7 place-items-center rounded-lg border border-white/[0.08] text-white/35 transition hover:border-amber-400/30 hover:text-amber-300" title="View details"><i class="fa-regular fa-eye text-[9px]"></i></a>
                                        <?php if (!in_array($order['status'], ['delivered', 'cancelled'], true)): ?>
                                            <form method="post" action="index.php" class="inline">
                                                <?= admin_csrf_field() ?>
                                                <input type="hidden" name="action" value="deliver">
                                                <input type="hidden" name="order_id" value="<?= (int) $order['id'] ?>">
                                                <button type="submit" class="grid h-7 w-7 place-items-center rounded-lg border border-white/[0.08] text-white/35 transition hover:border-emerald-400/30 hover:text-emerald-300" title="Mark as delivered"><i class="fa-solid fa-check text-[9px]"></i></button>
                                            </form>
                                        <?php endif; ?>
                                        <form method="post" action="index.php" class="inline" data-confirm="Delete order #NV<?= str_pad((string) $order['id'], 5, '0', STR_PAD_LEFT) ?>? This cannot be undone.">
                                            <?= admin_csrf_field() ?>
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="order_id" value="<?= (int) $order['id'] ?>">
                                            <button type="submit" class="grid h-7 w-7 place-items-center rounded-lg border border-white/[0.08] text-white/35 transition hover:border-rose-400/30 hover:text-rose-300" title="Delete order"><i class="fa-regular fa-trash-can text-[9px]"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Mobile cards -->
            <div class="divide-y divide-white/[0.04] md:hidden">
                <?php foreach ($recentOrders as $order): ?>
                    <?php $meta = status_meta((string) $order['status']); ?>
                    <div class="p-4">
                        <div class="flex items-center justify-between gap-2">
                            <a href="orders.php?view=<?= (int) $order['id'] ?>" class="text-[10px] font-medium text-amber-300/90">#NV<?= str_pad((string) $order['id'], 5, '0', STR_PAD_LEFT) ?></a>
                            <span class="badge-soft <?= e($meta['class']) ?>"><?= e($meta['label']) ?></span>
                        </div>
                        <p class="mt-2 text-[11.5px] font-medium text-white/75"><?= e($order['customer_name']) ?></p>
                        <p class="mt-0.5 text-[9.5px] text-white/30"><?= e($order['mobile']) ?> · <?= e($order['product_name'] ?? 'Unavailable') ?></p>
                        <div class="mt-3 flex items-center justify-between">
                            <span class="text-[9px] text-white/25"><?= e(format_date($order['created_at'], 'j M Y, g:i A')) ?></span>
                            <div class="flex items-center gap-1.5">
                                <?php if (!in_array($order['status'], ['delivered', 'cancelled'], true)): ?>
                                    <form method="post" action="index.php" class="inline">
                                        <?= admin_csrf_field() ?>
                                        <input type="hidden" name="action" value="deliver">
                                        <input type="hidden" name="order_id" value="<?= (int) $order['id'] ?>">
                                        <button type="submit" class="rounded-lg border border-emerald-400/20 px-2.5 py-1.5 text-[8.5px] text-emerald-300/80">Mark delivered</button>
                                    </form>
                                <?php endif; ?>
                                <form method="post" action="index.php" class="inline" data-confirm="Delete this order? This cannot be undone.">
                                    <?= admin_csrf_field() ?>
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="order_id" value="<?= (int) $order['id'] ?>">
                                    <button type="submit" class="rounded-lg border border-white/[0.08] px-2.5 py-1.5 text-[8.5px] text-white/35">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- Most viewed -->
    <section class="admin-card overflow-hidden">
        <div class="flex items-center justify-between gap-3 border-b border-white/[0.06] px-4 py-3.5 sm:px-5">
            <div>
                <h3 class="text-[12px] font-medium text-white">Most viewed</h3>
                <p class="mt-0.5 text-[9px] text-white/25">Top 5 pieces by page views</p>
            </div>
            <i class="fa-solid fa-fire-flame-curved text-[11px] text-amber-400/50"></i>
        </div>
        <?php if (!$mostViewed): ?>
            <div class="px-5 py-10 text-center text-[10.5px] text-white/25">No products yet.</div>
        <?php else: ?>
            <div class="divide-y divide-white/[0.04]">
                <?php foreach ($mostViewed as $rank => $item): ?>
                    <div class="flex items-center gap-3 px-4 py-3 sm:px-5">
                        <span class="w-4 shrink-0 text-center text-[9px] font-medium text-white/20"><?= str_pad((string) ($rank + 1), 2, '0', STR_PAD_LEFT) ?></span>
                        <img src="<?= e(upload_url($item['image'], '../')) ?>" alt="<?= e($item['name']) ?>" class="h-10 w-10 shrink-0 rounded-lg object-cover" data-fallback="../assets/img/placeholder.svg">
                        <div class="min-w-0 flex-1">
                            <p class="truncate text-[10.5px] font-medium text-white/70"><?= e($item['name']) ?></p>
                            <p class="mt-0.5 text-[8.5px] text-white/25"><?= e($item['category']) ?></p>
                        </div>
                        <span class="shrink-0 rounded-full border border-white/[0.07] bg-white/[0.02] px-2 py-0.5 text-[8.5px] text-white/35"><i class="fa-regular fa-eye mr-1 text-[7px] text-amber-400/50"></i><?= number_format((int) $item['views']) ?></span>
                        <a href="edit_post.php?id=<?= (int) $item['id'] ?>" class="grid h-7 w-7 shrink-0 place-items-center rounded-lg border border-white/[0.08] text-white/30 transition hover:border-amber-400/30 hover:text-amber-300" title="Edit product"><i class="fa-solid fa-pen text-[8px]"></i></a>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="border-t border-white/[0.05] px-4 py-3 text-center">
                <a href="posts.php" class="text-[9px] text-white/25 transition hover:text-amber-300">Manage the full catalogue <i class="fa-solid fa-arrow-right ml-1 text-[7px]"></i></a>
            </div>
        <?php endif; ?>
    </section>
</div>

<?php include __DIR__ . '/common/bottom.php'; ?>
