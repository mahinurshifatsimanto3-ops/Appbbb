<?php
/**
 * Shared add/edit product fields.
 * Expects: $formValues, $existingImage, $isEdit, $categories.
 */
$formValues = $formValues ?? [
    'name' => '',
    'category' => '',
    'original_price' => '',
    'discount_percent' => '0',
    'description' => '',
    'contact_number' => '',
];
$existingImage = $existingImage ?? null;
$isEdit = $isEdit ?? false;
$categories = $categories ?? [];
$previewSrc = $existingImage ? upload_url($existingImage, '../') : '../assets/img/placeholder.svg';
?>
<div class="grid gap-4 lg:grid-cols-[1.12fr_.88fr]">
    <div class="space-y-4">
        <section class="admin-card">
            <div class="border-b border-white/[0.06] px-5 py-3.5">
                <h3 class="text-[12px] font-medium text-white">Piece details</h3>
                <p class="mt-0.5 text-[9px] text-white/25">The story customers see on the storefront.</p>
            </div>
            <div class="space-y-4 p-5">
                <div>
                    <label for="name" class="admin-label">Product name <span class="text-rose-400/70">*</span></label>
                    <input id="name" name="name" type="text" maxlength="150" required value="<?= e($formValues['name']) ?>" placeholder="e.g. Diamond Eternity Necklace" class="admin-input">
                </div>
                <div>
                    <label for="category" class="admin-label">Category <span class="text-rose-400/70">*</span></label>
                    <input id="category" name="category" type="text" maxlength="100" required list="categoryOptions" value="<?= e($formValues['category']) ?>" placeholder="Rings, Necklaces, Earrings…" class="admin-input">
                    <datalist id="categoryOptions">
                        <?php foreach ($categories as $category): ?>
                            <option value="<?= e($category) ?>"></option>
                        <?php endforeach; ?>
                    </datalist>
                    <p class="mt-1.5 text-[8.5px] text-white/20">Pick an existing category or type a new one.</p>
                </div>
                <div>
                    <label for="description" class="admin-label">Description <span class="text-rose-400/70">*</span></label>
                    <textarea id="description" name="description" rows="7" minlength="10" maxlength="5000" required placeholder="Describe the design, finish, styling and what makes this piece special…" class="admin-input resize-y leading-relaxed"><?= e($formValues['description']) ?></textarea>
                    <p class="mt-1.5 text-[8.5px] text-white/20">10–5,000 characters. Line breaks are preserved on the product page.</p>
                </div>
                <div>
                    <label for="contact_number" class="admin-label">Contact number <span class="text-rose-400/70">*</span></label>
                    <div class="relative">
                        <span class="pointer-events-none absolute inset-y-0 left-0 flex w-10 items-center justify-center text-white/25"><i class="fa-solid fa-phone text-[10px]"></i></span>
                        <input id="contact_number" name="contact_number" type="tel" maxlength="20" required value="<?= e($formValues['contact_number']) ?>" placeholder="+91 98765 43210" class="admin-input pl-10">
                    </div>
                </div>
            </div>
        </section>
    </div>

    <div class="space-y-4">
        <section class="admin-card">
            <div class="border-b border-white/[0.06] px-5 py-3.5">
                <h3 class="text-[12px] font-medium text-white">Pricing</h3>
                <p class="mt-0.5 text-[9px] text-white/25">Selling price is calculated automatically.</p>
            </div>
            <div class="space-y-4 p-5">
                <div>
                    <label for="original_price" class="admin-label">Original price (<?= e(SITE_CURRENCY) ?>) <span class="text-rose-400/70">*</span></label>
                    <input id="original_price" name="original_price" type="number" min="1" max="9999999" step="0.01" required value="<?= e($formValues['original_price']) ?>" placeholder="2499" class="admin-input" data-calc-original>
                </div>
                <div>
                    <label for="discount_percent" class="admin-label">Discount (%)</label>
                    <input id="discount_percent" name="discount_percent" type="number" min="0" max="100" step="1" value="<?= e($formValues['discount_percent']) ?>" class="admin-input" data-calc-discount>
                    <div class="mt-2 flex flex-wrap gap-1.5">
                        <?php foreach ([0, 10, 15, 20, 25, 30] as $preset): ?>
                            <button type="button" class="rounded-md border border-white/[0.07] bg-white/[0.02] px-2 py-1 text-[8.5px] text-white/35 transition hover:border-amber-400/30 hover:text-amber-300" data-discount-preset="<?= $preset ?>"><?= $preset ?>%</button>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="rounded-xl border border-amber-400/15 bg-amber-400/[0.04] px-4 py-3">
                    <div class="flex items-center justify-between">
                        <p class="text-[9px] uppercase tracking-[0.14em] text-amber-300/60">Selling price</p>
                        <p class="text-[16px] font-semibold text-amber-300" data-calc-final><?= e(SITE_CURRENCY . number_format(max(0, (float) $formValues['original_price'] * (1 - (int) $formValues['discount_percent'] / 100)), 0, '.', ',')) ?></p>
                    </div>
                    <p class="mt-1 text-[8px] text-white/20">Rounded to the nearest taka when saved.</p>
                </div>
            </div>
        </section>

        <section class="admin-card">
            <div class="border-b border-white/[0.06] px-5 py-3.5">
                <h3 class="text-[12px] font-medium text-white">Product image</h3>
                <p class="mt-0.5 text-[9px] text-white/25">JPG, PNG or WebP · max 2 MB.</p>
            </div>
            <div class="p-5">
                <div class="relative overflow-hidden rounded-xl border border-white/[0.08] bg-[#0e0d0b]">
                    <img id="imagePreview" src="<?= e($previewSrc) ?>" alt="Product preview" class="aspect-[4/3] w-full object-cover" data-fallback="../assets/img/placeholder.svg">
                    <span class="absolute left-2.5 top-2.5 rounded-full border border-white/10 bg-black/50 px-2 py-0.5 text-[7.5px] uppercase tracking-[0.12em] text-white/45 backdrop-blur"><?= $isEdit ? 'Current image' : 'Preview' ?></span>
                </div>
                <label for="image" class="mt-3 flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-white/15 bg-white/[0.015] px-4 py-3.5 text-[10px] text-white/40 transition hover:border-amber-400/30 hover:bg-amber-400/[0.02] hover:text-amber-200">
                    <i class="fa-solid fa-cloud-arrow-up text-[12px] text-amber-400/60"></i>
                    <span>Choose an image</span>
                </label>
                <input id="image" name="image" type="file" accept="image/jpeg,image/png,image/webp" class="sr-only" data-preview="#imagePreview" <?= $isEdit ? '' : 'required' ?>>
                <p class="mt-2 text-center text-[8px] text-white/18"><?= $isEdit ? 'Leave empty to keep the current image.' : 'A square image works best.' ?> Max 2 MB.</p>
            </div>
        </section>

        <div class="admin-card p-4">
            <div class="flex flex-col gap-2 sm:flex-row">
                <button type="submit" class="btn-gold flex-1 !py-2.5 !text-[11px]"><i class="fa-solid fa-check text-[9px]"></i><span data-btn-label><?= $isEdit ? 'Save changes' : 'Publish product' ?></span></button>
                <a href="posts.php" class="btn-dark !py-2.5 text-center !text-[11px]">Cancel</a>
            </div>
            <p class="mt-2.5 text-center text-[8px] text-white/15"><?= $isEdit ? 'Changes go live on the storefront immediately.' : 'The piece will be visible to customers right away.' ?></p>
        </div>
    </div>
</div>

<script>
(function () {
    var original = document.querySelector('[data-calc-original]');
    var discount = document.querySelector('[data-calc-discount]');
    var finalEl = document.querySelector('[data-calc-final]');
    var currency = <?= json_encode(SITE_CURRENCY) ?>;
    if (!original || !discount || !finalEl) return;
    var update = function () {
        var base = parseFloat(original.value) || 0;
        var off = Math.max(0, Math.min(100, parseFloat(discount.value) || 0));
        var value = Math.round(base * (1 - off / 100));
        finalEl.textContent = currency + Math.max(0, value).toLocaleString('en-US');
    };
    original.addEventListener('input', update);
    discount.addEventListener('input', update);
    document.querySelectorAll('[data-discount-preset]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            discount.value = btn.dataset.discountPreset;
            update();
        });
    });
    update();
})();
</script>
