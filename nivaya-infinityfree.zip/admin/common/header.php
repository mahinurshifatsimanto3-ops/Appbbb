<?php
if (!function_exists('require_admin')) {
    require_once __DIR__ . '/config.php';
}
require_admin();

$admin_title  = $admin_title ?? 'Dashboard';
$admin_active = $admin_active ?? 'dashboard';
$admin_name   = (string) ($_SESSION['admin_username'] ?? 'admin');
$pendingOrders = 0;
try {
    $pendingRes = $conn->query("SELECT COUNT(*) AS c FROM orders WHERE status = 'pending'");
    if ($pendingRes) {
        $pendingOrders = (int) ($pendingRes->fetch_assoc()['c'] ?? 0);
    }
} catch (Throwable $e) {
    error_log('Admin pending count failed: ' . $e->getMessage());
}
$adminNav = [
    ['key' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'fa-chart-pie', 'href' => 'index.php'],
    ['key' => 'orders', 'label' => 'Orders', 'icon' => 'fa-receipt', 'href' => 'orders.php', 'badge' => $pendingOrders],
    ['key' => 'products', 'label' => 'Products', 'icon' => 'fa-gem', 'href' => 'posts.php'],
    ['key' => 'add', 'label' => 'Add product', 'icon' => 'fa-plus', 'href' => 'add_post.php'],
];
$flashes = [
    'success' => flash('success'),
    'error'   => flash('error'),
    'info'    => flash('info'),
];
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="theme-color" content="#0b0a09">
    <title><?= e($admin_title) ?> · NIVAYA Admin</title>
    <link rel="icon" href="../assets/img/favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="../assets/css/poppins.css">
    <link rel="stylesheet" href="../assets/css/fontawesome.css">
    <link rel="stylesheet" href="../assets/css/app.css">
    <meta name="robots" content="noindex,nofollow">
</head>
<body class="min-h-screen bg-[#0b0a09] antialiased">

<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('selectstart', e => e.preventDefault());
document.addEventListener('dragstart', e => e.preventDefault());
document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && ['I','J','C'].includes(e.key.toUpperCase())) e.preventDefault();
    if (e.key === 'F12') e.preventDefault();
});
document.addEventListener('touchstart', e => { if (e.touches.length > 1) e.preventDefault(); }, {passive:false});
</script>

<div class="min-h-screen lg:flex">
    <div id="adminOverlay" class="fixed inset-0 z-40 hidden bg-black/70 backdrop-blur-sm lg:hidden"></div>

    <aside id="adminSidebar" class="fixed inset-y-0 left-0 z-50 flex w-[272px] -translate-x-full flex-col border-r border-white/[0.06] bg-[#0e0d0b] transition-transform duration-300 lg:sticky lg:top-0 lg:h-screen lg:translate-x-0">
        <div class="flex items-center justify-between border-b border-white/[0.05] px-5 py-5">
            <a href="index.php" class="flex items-center gap-3">
                <span class="grid h-9 w-9 place-items-center rounded-xl border border-amber-400/25 bg-gradient-to-br from-amber-300/15 to-transparent text-amber-300">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M12 2.8 19 9l-7 12.2L5 9l7-6.2Z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>
                        <path d="M5 9h14M9.2 9 12 21.2 14.8 9" stroke="currentColor" stroke-width=".8" stroke-linejoin="round" opacity=".7"/>
                    </svg>
                </span>
                <span>
                    <span class="block text-[13.5px] font-semibold tracking-[0.3em] text-white">NIVAYA</span>
                    <span class="mt-1 block text-[8px] font-medium uppercase tracking-[0.22em] text-amber-300/50">Admin studio</span>
                </span>
            </a>
            <button type="button" data-sidebar-close class="grid h-8 w-8 place-items-center rounded-lg text-white/35 hover:bg-white/[0.04] hover:text-white lg:hidden" aria-label="Close menu">
                <i class="fa-solid fa-xmark text-sm"></i>
            </button>
        </div>

        <nav class="flex-1 overflow-y-auto px-3 py-5">
            <p class="px-3 pb-2 text-[8px] font-semibold uppercase tracking-[0.22em] text-white/20">Overview</p>
            <a href="index.php" class="admin-side-link <?= $admin_active === 'dashboard' ? 'is-active' : '' ?>">
                <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
                <span class="ml-auto h-1.5 w-1.5 rounded-full <?= $admin_active === 'dashboard' ? 'bg-amber-400' : 'bg-transparent' ?>"></span>
            </a>
            <a href="orders.php" class="admin-side-link <?= $admin_active === 'orders' ? 'is-active' : '' ?>">
                <i class="fa-solid fa-receipt"></i><span>Orders</span>
                <?php if ($pendingOrders > 0): ?>
                    <span class="ml-auto rounded-full bg-amber-400/15 px-2 py-0.5 text-[9px] font-semibold text-amber-300"><?= $pendingOrders ?></span>
                <?php endif; ?>
            </a>

            <p class="px-3 pb-2 pt-6 text-[8px] font-semibold uppercase tracking-[0.22em] text-white/20">Catalogue</p>
            <a href="posts.php" class="admin-side-link <?= $admin_active === 'products' ? 'is-active' : '' ?>">
                <i class="fa-solid fa-gem"></i><span>Products</span>
            </a>
            <a href="add_post.php" class="admin-side-link <?= in_array($admin_active, ['add', 'edit'], true) ? 'is-active' : '' ?>">
                <i class="fa-solid fa-plus"></i><span>Add product</span>
            </a>

            <p class="px-3 pb-2 pt-6 text-[8px] font-semibold uppercase tracking-[0.22em] text-white/20">Account</p>
            <a href="settings.php" class="admin-side-link <?= $admin_active === 'settings' ? 'is-active' : '' ?>">
                <i class="fa-solid fa-gear"></i><span>Settings</span>
            </a>

            <p class="px-3 pb-2 pt-6 text-[8px] font-semibold uppercase tracking-[0.22em] text-white/20">Storefront</p>
            <a href="../index.php" target="_blank" rel="noopener" class="admin-side-link">
                <i class="fa-solid fa-arrow-up-right-from-square"></i><span>View store</span>
                <span class="ml-auto text-[8px] uppercase tracking-[0.1em] text-white/20">New tab</span>
            </a>
            <a href="logout.php" class="admin-side-link hover:!text-rose-300">
                <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Sign out</span>
            </a>
        </nav>

        <div class="border-t border-white/[0.05] p-3">
            <div class="flex items-center gap-3 rounded-xl bg-white/[0.02] px-3 py-2.5">
                <span class="grid h-8 w-8 place-items-center rounded-full bg-gradient-to-br from-amber-300 to-amber-600 text-[10px] font-bold text-[#1a1408]"><?= e(strtoupper(substr($admin_name, 0, 1))) ?></span>
                <div class="min-w-0">
                    <p class="truncate text-[11px] font-medium text-white/70"><?= e($admin_name) ?></p>
                    <p class="text-[8px] uppercase tracking-[0.12em] text-white/20">Administrator</p>
                </div>
                <span class="ml-auto h-1.5 w-1.5 rounded-full bg-emerald-400/80" title="Online"></span>
            </div>
            <p class="mt-2 px-1 text-center text-[7.5px] uppercase tracking-[0.18em] text-white/12">NIVAYA · Admin v1.0</p>
        </div>
    </aside>

    <div class="flex min-h-screen min-w-0 flex-1 flex-col">
        <header class="sticky top-0 z-30 border-b border-white/[0.06] bg-[#0b0a09]/90 backdrop-blur-xl">
            <div class="flex h-[62px] items-center gap-3 px-4 sm:px-6 lg:px-8">
                <button type="button" data-sidebar-open class="grid h-9 w-9 place-items-center rounded-lg border border-white/10 text-white/50 transition hover:text-white lg:hidden" aria-label="Open menu">
                    <i class="fa-solid fa-bars-staggered text-[13px]"></i>
                </button>
                <div class="min-w-0 flex-1">
                    <p class="hidden text-[8px] font-medium uppercase tracking-[0.2em] text-white/20 sm:block">Admin / <?= e($admin_title) ?></p>
                    <h1 class="truncate text-[14px] font-medium text-white sm:mt-0.5"><?= e($admin_title) ?></h1>
                </div>
                <div class="flex items-center gap-2">
                    <a href="../index.php" target="_blank" rel="noopener" class="hidden h-9 items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-3.5 text-[10px] font-medium text-white/45 transition hover:border-amber-400/30 hover:text-amber-300 sm:inline-flex">
                        <i class="fa-solid fa-arrow-up-right-from-square text-[9px]"></i>Storefront
                    </a>
                    <span class="hidden h-5 w-px bg-white/10 sm:block"></span>
                    <div class="flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] p-1 pr-2.5">
                        <span class="grid h-7 w-7 place-items-center rounded-full bg-gradient-to-br from-amber-300 to-amber-600 text-[9px] font-bold text-[#1a1408]"><?= e(strtoupper(substr($admin_name, 0, 1))) ?></span>
                        <span class="hidden text-[10px] font-medium text-white/55 sm:block"><?= e($admin_name) ?></span>
                    </div>
                </div>
            </div>
        </header>

        <main class="mx-auto w-full max-w-[1180px] flex-1 px-4 py-5 sm:px-6 sm:py-7 lg:px-8">

        <?php if ($flashes['success']): ?>
            <div class="alert-in mb-5 flex items-start gap-3 rounded-2xl border border-emerald-400/20 bg-emerald-400/[0.07] px-4 py-3.5 text-[12.5px] text-emerald-200" role="status">
                <i class="fa-solid fa-circle-check mt-0.5 text-emerald-400"></i>
                <p class="flex-1 leading-relaxed"><?= e($flashes['success']) ?></p>
                <button type="button" data-dismiss class="text-emerald-300/50 hover:text-emerald-200" aria-label="Dismiss"><i class="fa-solid fa-xmark"></i></button>
            </div>
        <?php endif; ?>
        <?php if ($flashes['error']): ?>
            <div class="alert-in mb-5 flex items-start gap-3 rounded-2xl border border-rose-400/20 bg-rose-400/[0.07] px-4 py-3.5 text-[12.5px] text-rose-200" role="alert">
                <i class="fa-solid fa-circle-exclamation mt-0.5 text-rose-400"></i>
                <p class="flex-1 leading-relaxed"><?= e($flashes['error']) ?></p>
                <button type="button" data-dismiss class="text-rose-300/50 hover:text-rose-200" aria-label="Dismiss"><i class="fa-solid fa-xmark"></i></button>
            </div>
        <?php endif; ?>
        <?php if ($flashes['info']): ?>
            <div class="alert-in mb-5 flex items-start gap-3 rounded-2xl border border-sky-400/20 bg-sky-400/[0.07] px-4 py-3.5 text-[12.5px] text-sky-200" role="status">
                <i class="fa-solid fa-circle-info mt-0.5 text-sky-400"></i>
                <p class="flex-1 leading-relaxed"><?= e($flashes['info']) ?></p>
                <button type="button" data-dismiss class="text-sky-300/50 hover:text-sky-200" aria-label="Dismiss"><i class="fa-solid fa-xmark"></i></button>
            </div>
        <?php endif; ?>
