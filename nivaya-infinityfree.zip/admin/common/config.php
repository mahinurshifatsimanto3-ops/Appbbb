<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/common/config.php';

function is_admin_logged_in(): bool
{
    return !empty($_SESSION['admin_id']);
}

function require_admin(): void
{
    if (!is_admin_logged_in()) {
        flash('error', 'Please sign in to the admin panel.');
        redirect('login.php');
    }
    if (empty($_SESSION['admin_csrf'])) {
        $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
    }
}

function admin_csrf_field(): string
{
    if (empty($_SESSION['admin_csrf'])) {
        $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
    }
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['admin_csrf']) . '">';
}

function admin_csrf_check(): void
{
    $token = $_POST['csrf'] ?? '';
    if (!is_string($token) || $token === '' || !hash_equals((string) ($_SESSION['admin_csrf'] ?? ''), $token)) {
        http_response_code(419);
        exit('Session expired. Refresh the page and try again.');
    }
}

/**
 * Validate + store an uploaded product image.
 *
 * @return array{0: ?string, 1: ?string} [filename, error]
 */
function admin_upload_image(array $file): array
{
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return [null, null];
    }
    if ($file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE) {
        return [null, 'The image is larger than the 2 MB limit.'];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return [null, 'The image could not be uploaded. Please try again.'];
    }
    if (!is_uploaded_file($file['tmp_name'])) {
        return [null, 'Invalid image upload.'];
    }
    if ((int) $file['size'] <= 0 || (int) $file['size'] > 2 * 1024 * 1024) {
        return [null, 'Image must be smaller than 2 MB.'];
    }

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
    ];
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if (!is_string($mime) || !isset($allowed[$mime])) {
        return [null, 'Only JPG, PNG or WebP images are allowed.'];
    }
    if (@getimagesize($file['tmp_name']) === false) {
        return [null, 'That file does not look like a valid image.'];
    }

    if (!is_dir(UPLOADS_DIR)) {
        @mkdir(UPLOADS_DIR, 0755, true);
    }
    if (!is_dir(UPLOADS_DIR) || !is_writable(UPLOADS_DIR)) {
        return [null, 'The uploads folder is not writable. Check folder permissions.'];
    }

    $filename = bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], UPLOADS_DIR . '/' . $filename)) {
        return [null, 'Could not save the image. Please try again.'];
    }
    @chmod(UPLOADS_DIR . '/' . $filename, 0644);

    return [$filename, null];
}

function status_label(string $status): string
{
    return status_meta($status)['label'];
}
