        </main>

        <footer class="border-t border-white/[0.05] px-4 py-4 sm:px-6 lg:px-8">
            <div class="mx-auto flex max-w-[1180px] flex-col items-center justify-between gap-2 text-[9px] text-white/20 sm:flex-row">
                <p>© <?= date('Y') ?> NIVAYA · Admin studio</p>
                <p class="flex items-center gap-2"><span class="h-1 w-1 rounded-full bg-emerald-400/60"></span>System operational · <?= e(date('j M Y')) ?></p>
            </div>
        </footer>
    </div>
</div>

<script>
(function () {
    var sidebar = document.getElementById('adminSidebar');
    var overlay = document.getElementById('adminOverlay');
    var openBtn = document.querySelector('[data-sidebar-open]');
    var closeBtn = document.querySelector('[data-sidebar-close]');

    function openSidebar() {
        if (!sidebar || !overlay) return;
        sidebar.classList.remove('-translate-x-full');
        overlay.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }
    function closeSidebar() {
        if (!sidebar || !overlay) return;
        if (window.innerWidth < 1024) sidebar.classList.add('-translate-x-full');
        overlay.classList.add('hidden');
        document.body.style.overflow = '';
    }
    if (openBtn) openBtn.addEventListener('click', openSidebar);
    if (closeBtn) closeBtn.addEventListener('click', closeSidebar);
    if (overlay) overlay.addEventListener('click', closeSidebar);
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeSidebar();
    });
    window.addEventListener('resize', function () {
        if (window.innerWidth >= 1024 && overlay) {
            overlay.classList.add('hidden');
            document.body.style.overflow = '';
        }
    });
})();

document.querySelectorAll('[data-dismiss]').forEach(function (btn) {
    btn.addEventListener('click', function () {
        var alert = btn.closest('div[role="status"], div[role="alert"]');
        if (!alert) return;
        alert.style.transition = 'opacity .2s ease';
        alert.style.opacity = '0';
        setTimeout(function () { alert.remove(); }, 200);
    });
});

document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
        if (!window.confirm(form.dataset.confirm || 'Are you sure?')) {
            e.preventDefault();
            return;
        }
        var btn = form.querySelector('button[type="submit"]');
        if (btn) {
            setTimeout(function () {
                btn.disabled = true;
                btn.classList.add('opacity-50', 'pointer-events-none');
            }, 10);
        }
    });
});

document.querySelectorAll('form[data-lock]').forEach(function (form) {
    form.addEventListener('submit', function () {
        var btn = form.querySelector('button[type="submit"]');
        if (!btn) return;
        setTimeout(function () {
            btn.disabled = true;
            btn.classList.add('opacity-70');
            var label = btn.querySelector('[data-btn-label]');
            if (label) label.textContent = 'Please wait…';
        }, 10);
    });
});

document.querySelectorAll('input[type="file"][data-preview]').forEach(function (input) {
    input.addEventListener('change', function () {
        var target = document.querySelector(input.dataset.preview);
        if (!target || !input.files || !input.files[0]) return;
        var file = input.files[0];
        if (!/^image\/(jpeg|png|webp)$/.test(file.type)) return;
        var url = URL.createObjectURL(file);
        target.src = url;
        target.classList.remove('hidden');
    });
});
</script>
</body>
</html>
