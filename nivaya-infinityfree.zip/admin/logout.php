<?php
declare(strict_types=1);
require_once __DIR__ . '/common/config.php';

unset($_SESSION['admin_id'], $_SESSION['admin_username'], $_SESSION['admin_csrf']);
session_regenerate_id(true);
flash('success', 'You have been signed out of the admin studio.');
redirect('login.php');
