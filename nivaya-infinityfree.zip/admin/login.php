<?php
declare(strict_types=1);
require_once __DIR__ . '/common/config.php';

if (is_admin_logged_in()) {
    redirect('index.php');
}

$error = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_csrf_check();
    $username  = trim((string) ($_POST['username'] ?? ''));
    $password1 = (string) ($_POST['password1'] ?? '');
    $password2 = (string) ($_POST['password2'] ?? '');

    if ($username === '' || $password1 === '' || $password2 === '') {
        $error = 'Enter your username and both passwords.';
    } else {
        $stmt = $conn->prepare('SELECT id, username, password1, password2 FROM admin WHERE username = ? LIMIT 1');
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $admin = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        $valid = false;
        if ($admin) {
            $ok1 = password_verify($password1, (string) $admin['password1']);
            $ok2 = password_verify($password2, (string) $admin['password2']);
            $valid = $ok1 && $ok2;
        }

        if ($valid) {
            session_regenerate_id(true);
            $_SESSION['admin_id'] = (int) $admin['id'];
            $_SESSION['admin_username'] = (string) $admin['username'];
            $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
            redirect('index.php');
        }

        usleep(350000);
        $error = 'Invalid credentials. Please check both passwords and try again.';
    }
}

$flashError = flash('error');
$flashSuccess = flash('success');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="theme-color" content="#0b0a09">
    <title>Admin access · NIVAYA</title>
    <link rel="icon" href="../assets/img/favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="../assets/css/poppins.css">
    <link rel="stylesheet" href="../assets/css/fontawesome.css">
    <link rel="stylesheet" href="../assets/css/app.css">
    <meta name="robots" content="noindex,nofollow">
</head>
<body class="min-h-screen bg-[#0b0a09] antialiased">

<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('selectstart', e => e.preventDefault());
document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
    if (e.key === 'F12') e.preventDefault();
});
document.addEventListener('touchstart', e => { if (e.touches.length > 1) e.preventDefault(); }, {passive:false});
</script>

<div class="grid min-h-screen lg:grid-cols-[1.08fr_1fr]">
    <aside class="relative hidden overflow-hidden border-r border-white/[0.06] bg-[#0d0c0a] lg:flex lg:flex-col">
        <div class="pointer-events-none absolute -left-24 top-1/4 h-[520px] w-[520px] rounded-full bg-amber-500/[0.06] blur-[120px]"></div>
        <div class="relative z-10 flex items-center justify-between px-12 pt-10">
            <a href="../index.php" class="flex items-center gap-3">
                <span class="grid h-10 w-10 place-items-center rounded-xl border border-amber-400/25 bg-amber-400/[0.06] text-amber-300">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M12 2.8 19 9l-7 12.2L5 9l7-6.2Z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>
                        <path d="M5 9h14M9.2 9 12 21.2 14.8 9" stroke="currentColor" stroke-width=".8" stroke-linejoin="round" opacity=".7"/>
                    </svg>
                </span>
                <span class="text-[15px] font-semibold tracking-[0.34em] text-white">NIVAYA</span>
            </a>
            <span class="rounded-full border border-white/10 px-3 py-1 text-[8px] font-medium uppercase tracking-[0.2em] text-white/30">Staff only</span>
        </div>

        <div class="relative z-10 my-auto px-12 py-10 xl:px-16">
            <p class="eyebrow">Admin studio</p>
            <h1 class="mt-5 max-w-[430px] text-[38px] font-light leading-[1.14] tracking-[-0.03em] text-white xl:text-[46px]">
                Every order.<br>Every <span class="gold-text font-normal">detail.</span>
            </h1>
            <p class="mt-5 max-w-[380px] text-[12.5px] leading-relaxed text-white/35">
                A quieter, faster way to run the store — orders, products and the pieces your customers love.
            </p>

            <div class="relative mt-9 max-w-[460px] overflow-hidden rounded-[24px] border border-white/[0.08]">
                <img src="../assets/img/brand-hero.svg" alt="" class="aspect-[16/10] w-full object-cover opacity-90">
                <div class="absolute inset-0 bg-gradient-to-t from-[#0d0c0a] via-transparent to-transparent"></div>
                <div class="absolute inset-x-0 bottom-0 flex items-end justify-between p-5">
                    <div>
                        <p class="text-[8px] uppercase tracking-[0.2em] text-amber-300/70">Store pulse</p>
                        <p class="mt-1 text-[12.5px] font-medium text-white">Curated with intention</p>
                    </div>
                    <span class="flex items-center gap-1.5 rounded-full border border-emerald-400/20 bg-emerald-400/[0.08] px-2.5 py-1 text-[8px] font-medium uppercase tracking-[0.12em] text-emerald-300"><span class="h-1 w-1 rounded-full bg-emerald-400"></span>Online</span>
                </div>
            </div>

            <div class="mt-8 flex max-w-[460px] items-center gap-6 border-t border-white/[0.06] pt-5 text-[9px] uppercase tracking-[0.14em] text-white/22">
                <span><i class="fa-solid fa-lock mr-1.5 text-amber-400/50"></i>Two-password access</span>
                <span><i class="fa-solid fa-database mr-1.5 text-amber-400/50"></i>Live orders</span>
                <span><i class="fa-solid fa-gem mr-1.5 text-amber-400/50"></i>Catalogue</span>
            </div>
        </div>
    </aside>

    <section class="flex min-h-screen flex-col">
        <div class="flex items-center justify-between px-5 pt-7 sm:px-8 lg:hidden">
            <a href="../index.php" class="flex items-center gap-2.5">
                <span class="grid h-9 w-9 place-items-center rounded-xl border border-amber-400/25 bg-amber-400/[0.06] text-amber-300">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M12 2.8 19 9l-7 12.2L5 9l7-6.2Z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>
                        <path d="M5 9h14M9.2 9 12 21.2 14.8 9" stroke="currentColor" stroke-width=".8" stroke-linejoin="round" opacity=".7"/>
                    </svg>
                </span>
                <span class="text-[15px] font-semibold tracking-[0.3em] text-white">NIVAYA</span>
            </a>
            <span class="text-[8.5px] uppercase tracking-[0.18em] text-amber-300/50">Admin</span>
        </div>

        <div class="flex flex-1 items-center justify-center px-5 py-9 sm:px-8 lg:px-12">
            <div class="w-full max-w-[400px] animate-fade-up">
                <div class="mb-7">
                    <div class="mb-4 flex h-11 w-11 items-center justify-center rounded-2xl border border-amber-400/20 bg-gradient-to-br from-amber-400/15 to-transparent text-amber-300">
                        <i class="fa-solid fa-fingerprint text-[17px]"></i>
                    </div>
                    <p class="eyebrow">Restricted access</p>
                    <h2 class="mt-2.5 text-[26px] font-medium tracking-[-0.025em] text-white sm:text-[29px]">Admin sign in</h2>
                    <p class="mt-2 text-[11.5px] leading-relaxed text-white/35">Enter your username and both security passwords to enter the studio.</p>
                </div>

                <?php if ($flashError): ?>
                    <div class="alert-in mb-4 flex items-start gap-3 rounded-2xl border border-rose-400/20 bg-rose-400/[0.07] px-4 py-3.5 text-[12px] text-rose-200" role="alert">
                        <i class="fa-solid fa-circle-exclamation mt-0.5 text-rose-400"></i>
                        <p class="flex-1 leading-relaxed"><?= e($flashError) ?></p>
                    </div>
                <?php endif; ?>
                <?php if ($flashSuccess): ?>
                    <div class="alert-in mb-4 flex items-start gap-3 rounded-2xl border border-emerald-400/20 bg-emerald-400/[0.07] px-4 py-3.5 text-[12px] text-emerald-200" role="status">
                        <i class="fa-solid fa-circle-check mt-0.5 text-emerald-400"></i>
                        <p class="flex-1 leading-relaxed"><?= e($flashSuccess) ?></p>
                    </div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert-in mb-4 flex items-start gap-3 rounded-2xl border border-rose-400/20 bg-rose-400/[0.07] px-4 py-3.5 text-[12px] text-rose-200" role="alert">
                        <i class="fa-solid fa-circle-exclamation mt-0.5 text-rose-400"></i>
                        <p class="flex-1 leading-relaxed"><?= e($error) ?></p>
                    </div>
                <?php endif; ?>

                <form method="post" action="login.php" class="space-y-3.5" data-lock>
                    <?= admin_csrf_field() ?>
                    <div>
                        <label for="username" class="label-text">Username</label>
                        <div class="relative">
                            <span class="pointer-events-none absolute inset-y-0 left-0 flex w-11 items-center justify-center text-white/25"><i class="fa-regular fa-user text-[12px]"></i></span>
                            <input id="username" name="username" type="text" autocomplete="username" required value="<?= e($username) ?>" placeholder="admin" class="input-field pl-11">
                        </div>
                    </div>
                    <div>
                        <label for="password1" class="label-text">Password 1 <span class="normal-case tracking-normal text-white/15">· primary</span></label>
                        <div class="relative">
                            <span class="pointer-events-none absolute inset-y-0 left-0 flex w-11 items-center justify-center text-white/25"><i class="fa-solid fa-key text-[12px]"></i></span>
                            <input id="password1" name="password1" type="password" autocomplete="current-password" required placeholder="Primary password" class="input-field px-11">
                            <button type="button" class="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-white/25 transition hover:text-amber-300" data-reveal="password1" aria-label="Show password 1"><i class="fa-regular fa-eye text-[12px]"></i></button>
                        </div>
                    </div>
                    <div>
                        <label for="password2" class="label-text">Password 2 <span class="normal-case tracking-normal text-white/15">· secondary</span></label>
                        <div class="relative">
                            <span class="pointer-events-none absolute inset-y-0 left-0 flex w-11 items-center justify-center text-white/25"><i class="fa-solid fa-shield-halved text-[12px]"></i></span>
                            <input id="password2" name="password2" type="password" autocomplete="off" required placeholder="Secondary password" class="input-field px-11">
                            <button type="button" class="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-white/25 transition hover:text-amber-300" data-reveal="password2" aria-label="Show password 2"><i class="fa-regular fa-eye text-[12px]"></i></button>
                        </div>
                    </div>

                    <div class="flex items-start gap-2.5 rounded-xl border border-white/[0.06] bg-white/[0.015] px-3.5 py-3 text-[9.5px] leading-relaxed text-white/25">
                        <i class="fa-solid fa-lock mt-0.5 text-amber-400/40"></i>
                        <p>Both passwords must be correct. Access is logged and restricted to store staff.</p>
                    </div>

                    <button type="submit" class="btn-gold w-full py-3.5">
                        <span data-btn-label>Enter studio</span>
                        <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </button>
                </form>

                <div class="mt-7 flex items-center justify-between border-t border-white/[0.06] pt-5 text-[9.5px] text-white/20">
                    <a href="../login.php" class="flex items-center gap-1.5 transition hover:text-white/40"><i class="fa-solid fa-arrow-left text-[8px]"></i>Customer site</a>
                    <span>NIVAYA · Secure admin</span>
                </div>
                <p class="mt-3 text-center text-[8.5px] leading-relaxed text-white/12">Credentials were shown by install.php on first setup.</p>
            </div>
        </div>
    </section>
</div>

<script>
document.querySelectorAll('[data-reveal]').forEach(function (btn) {
    btn.addEventListener('click', function () {
        var input = document.getElementById(btn.dataset.reveal);
        if (!input) return;
        var show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        var icon = btn.querySelector('i');
        if (icon) icon.className = show ? 'fa-regular fa-eye-slash text-[12px]' : 'fa-regular fa-eye text-[12px]';
    });
});
document.querySelectorAll('form[data-lock]').forEach(function (form) {
    form.addEventListener('submit', function () {
        var btn = form.querySelector('button[type="submit"]');
        if (!btn) return;
        setTimeout(function () {
            btn.disabled = true;
            btn.classList.add('opacity-70');
            var label = btn.querySelector('[data-btn-label]');
            if (label) label.textContent = 'Verifying…';
        }, 10);
    });
});
</script>
</body>
</html>
