<?php
$nav = [
    'home'    => ['href' => 'index.php',         'icon' => 'fa-house',                'label' => 'Home'],
    'orders'  => ['href' => 'order_history.php', 'icon' => 'fa-box',                  'label' => 'Orders'],
    'profile' => ['href' => 'profile.php',       'icon' => 'fa-user',                 'label' => 'Profile'],
];
?>
</main>

<footer class="mx-auto w-full max-w-7xl px-4 pb-32 pt-6 sm:px-6 lg:px-8">
    <div class="border-t border-white/[0.06] pt-7">
        <div class="flex flex-col items-center justify-between gap-5 text-center sm:flex-row sm:text-left">
            <div class="flex items-center gap-3">
                <span class="grid h-9 w-9 place-items-center rounded-xl border border-amber-400/20 text-amber-300/80">
                    <i class="fa-solid fa-gem text-[12px]"></i>
                </span>
                <div>
                    <p class="text-[12px] font-semibold tracking-[0.3em] text-white/80">NIVAYA</p>
                    <p class="mt-1 text-[10px] uppercase tracking-[0.18em] text-white/25">Everyday luxury, thoughtfully priced</p>
                </div>
            </div>
            <p class="text-[10.5px] leading-relaxed text-white/25">© <?= date('Y') ?> NIVAYA · Handcrafted with care<br class="sm:hidden"> · Cash on delivery available</p>
        </div>
    </div>
</footer>

<nav class="fixed inset-x-0 bottom-0 z-40 border-t border-white/[0.07] bg-[#0c0b0a]/95 backdrop-blur-xl" aria-label="Bottom navigation">
    <div class="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-amber-400/30 to-transparent"></div>
    <div class="mx-auto flex max-w-lg items-stretch justify-around px-2 pb-[max(env(safe-area-inset-bottom),0.45rem)] pt-1.5">
        <?php foreach ($nav as $key => $item): ?>
            <?php $isActive = $active_nav === $key; ?>
            <a href="<?= e($item['href']) ?>" class="group relative flex min-w-[64px] flex-col items-center gap-1 rounded-xl px-3 py-1.5 text-[9.5px] font-medium tracking-[0.06em] transition <?= $isActive ? 'text-amber-300' : 'text-white/35 hover:text-white/70' ?>">
                <span class="grid h-7 w-10 place-items-center rounded-full transition <?= $isActive ? 'bg-amber-400/10' : 'group-hover:bg-white/[0.04]' ?>">
                    <i class="fa-solid <?= e($item['icon']) ?> text-[14px]"></i>
                </span>
                <span><?= e($item['label']) ?></span>
                <?php if ($isActive): ?><span class="absolute bottom-0 h-[2px] w-4 rounded-full bg-amber-400"></span><?php endif; ?>
            </a>
        <?php endforeach; ?>
        <a href="logout.php" class="group flex min-w-[64px] flex-col items-center gap-1 rounded-xl px-3 py-1.5 text-[9.5px] font-medium tracking-[0.06em] text-white/35 transition hover:text-rose-300">
            <span class="grid h-7 w-10 place-items-center rounded-full transition group-hover:bg-rose-400/10">
                <i class="fa-solid fa-arrow-right-from-bracket text-[14px]"></i>
            </span>
            <span>Logout</span>
        </a>
    </div>
</nav>

<script>
document.querySelectorAll('[data-dismiss]').forEach(function (btn) {
    btn.addEventListener('click', function () {
        var alert = btn.closest('div[role="status"], div[role="alert"]');
        if (!alert) return;
        alert.style.transition = 'opacity .25s ease, transform .25s ease';
        alert.style.opacity = '0';
        alert.style.transform = 'translateY(-6px)';
        setTimeout(function () { alert.remove(); }, 250);
    });
});

document.querySelectorAll('img[data-fallback]').forEach(function (img) {
    img.addEventListener('error', function () {
        if (img.dataset.failed) return;
        img.dataset.failed = '1';
        img.src = img.dataset.fallback || 'assets/img/placeholder.svg';
    });
});

document.querySelectorAll('form[data-lock]').forEach(function (form) {
    form.addEventListener('submit', function () {
        var btn = form.querySelector('button[type="submit"]');
        if (!btn) return;
        setTimeout(function () {
            btn.disabled = true;
            btn.classList.add('opacity-70', 'pointer-events-none');
            var label = btn.querySelector('[data-btn-label]');
            if (label) label.textContent = 'Please wait…';
        }, 10);
    });
});

/* Entrance motion uses pure CSS load animations (animate-fade-up) so content is
   never hidden behind a scroll observer — products stay visible even if JS is
   slow, disabled, or the page is printed. */
</script>
</body>
</html>
