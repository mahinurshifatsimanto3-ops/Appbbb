<?php
/**
 * NIVAYA — central configuration & shared helpers
 * Jewellery & Accessories Store
 */
declare(strict_types=1);

/* ------------------------------------------------------------------
 | Multibyte fallbacks (the app also runs on PHP builds without mbstring)
 * ------------------------------------------------------------------ */
if (!function_exists('mb_strlen')) {
    function mb_strlen(string $string, ?string $encoding = null): int
    {
        return strlen($string);
    }
}
if (!function_exists('mb_substr')) {
    function mb_substr(string $string, int $start, ?int $length = null, ?string $encoding = null): string
    {
        return $length === null ? substr($string, $start) : substr($string, $start, $length);
    }
}
if (!function_exists('mb_strtoupper')) {
    function mb_strtoupper(string $string, ?string $encoding = null): string
    {
        return strtoupper($string);
    }
}

/* ------------------------------------------------------------------
 | Errors & sessions
 * ------------------------------------------------------------------ */
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

if (session_status() === PHP_SESSION_NONE) {
    // Detect HTTPS even behind InfinityFree / CDN reverse proxies.
    $secure = (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || (($_SERVER['SERVER_PORT'] ?? '') === '443');
    ini_set('session.use_strict_mode', '1');   // reject uninitialized session ids
    ini_set('session.use_only_cookies', '1');  // never accept session ids via URL
    session_name('NIVAYA_SESSION');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

/* ------------------------------------------------------------------
 | Database credentials live in common/database.php (edit that file).
 | Site constants
 * ------------------------------------------------------------------ */
require_once __DIR__ . '/database.php';

define('SITE_NAME', 'NIVAYA');
define('SITE_TAGLINE', 'Jewellery & Accessories');
define('SITE_CURRENCY', '৳'); // Bangladeshi Taka (BDT)
define('NIVAYA_ROOT', dirname(__DIR__));
define('UPLOADS_DIR', NIVAYA_ROOT . '/uploads');

/* Basic hardening headers */
if (!headers_sent()) {
    header_remove('X-Powered-By'); // don't advertise the PHP version
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$conn = null;
if (!defined('NIVAYA_SKIP_DB')) {
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, (int) DB_PORT);
        $conn->set_charset('utf8mb4');
    } catch (Throwable $e) {
        error_log('NIVAYA DB connection failed: ' . $e->getMessage());
        http_response_code(503);
        $installHref = str_contains((string) ($_SERVER['SCRIPT_NAME'] ?? ''), '/admin/') ? '../install.php' : 'install.php';
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>NIVAYA · Setup required</title>
            <style>
                *{box-sizing:border-box}
                body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:#0b0a09;color:#fff;font-family:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;background-image:radial-gradient(circle at 20% 10%,rgba(245,158,11,.12),transparent 45%),radial-gradient(circle at 90% 90%,rgba(245,158,11,.08),transparent 40%)}
                .box{width:100%;max-width:520px;background:#12110f;border:1px solid #29251e;border-radius:24px;padding:40px 32px;box-shadow:0 30px 80px rgba(0,0,0,.55)}
                .mark{width:52px;height:52px;border-radius:16px;background:linear-gradient(145deg,#f7c873,#c58b26);display:grid;place-items:center;color:#17130a;font-size:22px;margin-bottom:22px}
                h1{font-size:22px;margin:0 0 10px;font-weight:600;letter-spacing:-.01em}
                p{color:#9d988f;font-size:14px;line-height:1.75;margin:0 0 22px}
                a{display:inline-flex;align-items:center;justify-content:center;width:100%;padding:14px 18px;border-radius:12px;background:#f59e0b;color:#111;text-decoration:none;font-weight:600;font-size:14px}
                code{background:#1c1a16;padding:2px 7px;border-radius:6px;color:#e5c07b;font-size:12px}
                .foot{margin-top:20px;font-size:12px;color:#6f6a61}
            </style>
        </head>
        <body>
            <div class="box">
                <div class="mark">◆</div>
                <h1>Database connection unavailable</h1>
                <p>NIVAYA could not connect to MySQL at <code><?= htmlspecialchars(DB_HOST) ?></code>. Check the credentials in <code>common/database.php</code>, make sure the database exists, then run the installer.</p>
                <a href="<?= htmlspecialchars($installHref) ?>">Open install.php</a>
                <div class="foot">On InfinityFree, create the database in the control panel first — PHP cannot create it for you.</div>
            </div>
        </body>
        </html>
        <?php
        exit;
    }
}

/* ------------------------------------------------------------------
 | Small helpers
 * ------------------------------------------------------------------ */
function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function money(float|int|string|null $amount, bool $decimals = false): string
{
    $amount = (float) $amount;
    return SITE_CURRENCY . number_format($amount, $decimals ? 2 : 0, '.', ',');
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    $token = $_POST['csrf'] ?? '';
    if (!is_string($token) || $token === '' || !hash_equals(csrf_token(), $token)) {
        http_response_code(419);
        exit('Session expired. Please go back, refresh the page and try again.');
    }
}

function flash(string $key, ?string $message = null): ?string
{
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return null;
    }
    $msg = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);
    return is_string($msg) ? $msg : null;
}

/** Store a flash message then redirect. */
function flash_redirect(string $url, string $key, string $message): void
{
    flash($key, $message);
    redirect($url);
}

function require_user(): void
{
    if (empty($_SESSION['user_id'])) {
        $target = $_SERVER['REQUEST_URI'] ?? 'index.php';
        $_SESSION['after_login'] = $target;
        flash('error', 'Please sign in to continue.');
        redirect('login.php');
    }
}

function current_user(mysqli $conn): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }
    $stmt = $conn->prepare('SELECT id, real_name, address, mobile, created_at FROM users WHERE id = ? LIMIT 1');
    $id = (int) $_SESSION['user_id'];
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

function product_price(array $product): float
{
    $discounted = (float) ($product['discounted_price'] ?? 0);
    if ($discounted > 0) {
        return $discounted;
    }
    return (float) ($product['original_price'] ?? 0);
}

function discount_percent(array $product): int
{
    return max(0, min(100, (int) ($product['discount_percent'] ?? 0)));
}

/** Resolve a product image filename to a URL (relative prefix supported for admin pages). */
function upload_url(?string $file, string $prefix = ''): string
{
    $file = trim((string) $file);
    if ($file === '') {
        return $prefix . 'assets/img/placeholder.svg';
    }
    if (preg_match('#^https?://#i', $file)) {
        return $file;
    }
    return $prefix . 'uploads/' . rawurlencode(basename($file));
}

function status_meta(string $status): array
{
    return match ($status) {
        'confirmed' => ['label' => 'Confirmed', 'class' => 'bg-sky-400/10 text-sky-300 border-sky-400/20', 'icon' => 'fa-circle-check'],
        'delivered' => ['label' => 'Delivered', 'class' => 'bg-emerald-400/10 text-emerald-300 border-emerald-400/20', 'icon' => 'fa-box-open'],
        'cancelled' => ['label' => 'Cancelled', 'class' => 'bg-rose-400/10 text-rose-300 border-rose-400/20', 'icon' => 'fa-circle-xmark'],
        default     => ['label' => 'Pending', 'class' => 'bg-amber-400/10 text-amber-300 border-amber-400/20', 'icon' => 'fa-clock'],
    };
}

function format_date(?string $datetime, string $format = 'j M Y'): string
{
    if (!$datetime) {
        return '—';
    }
    $ts = strtotime($datetime);
    return $ts ? date($format, $ts) : '—';
}

function initials(string $name): string
{
    $name = trim($name);
    if ($name === '') {
        return 'N';
    }
    $parts = preg_split('/\s+/', $name) ?: [];
    $first = mb_substr($parts[0] ?? 'N', 0, 1);
    $last = count($parts) > 1 ? mb_substr((string) end($parts), 0, 1) : '';
    return mb_strtoupper($first . $last);
}

function truncate(string $text, int $limit = 110): string
{
    $text = trim(strip_tags($text));
    if (mb_strlen($text) <= $limit) {
        return $text;
    }
    return rtrim(mb_substr($text, 0, $limit)) . '…';
}

/** All distinct product categories, cached per request. */
function product_categories(mysqli $conn): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $result = $conn->query("SELECT DISTINCT category FROM products WHERE category <> '' ORDER BY category ASC");
    $cache = [];
    while ($row = $result->fetch_assoc()) {
        $cache[] = $row['category'];
    }
    return $cache;
}

/** Fetch a single product by id (or null). */
function find_product(mysqli $conn, int $id): ?array
{
    $stmt = $conn->prepare('SELECT * FROM products WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}
