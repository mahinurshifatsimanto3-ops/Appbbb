<?php
if (!defined('DB_HOST')) {
    require_once __DIR__ . '/config.php';
}
$page_title  = $page_title ?? 'NIVAYA — Fine Jewellery & Accessories';
$active_nav  = $active_nav ?? 'home';
$body_class  = $body_class ?? '';
$flashes = [
    'success' => flash('success'),
    'error'   => flash('error'),
    'info'    => flash('info'),
];
$session_initial = initials((string) ($_SESSION['user_name'] ?? 'N'));
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="theme-color" content="#0b0a09">
    <meta name="description" content="NIVAYA — handpicked rings, necklaces, earrings and accessories. Timeless pieces, thoughtfully priced.">
    <title><?= e($page_title) ?></title>
    <link rel="icon" href="assets/img/favicon.svg" type="image/svg+xml">
    <link rel="preload" href="assets/webfonts/poppins-400.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="stylesheet" href="assets/css/poppins.css">
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <meta name="robots" content="noindex,nofollow">
</head>
<body class="min-h-screen bg-[#0b0a09] antialiased <?= e($body_class) ?>">

<!-- Global input hardening -->
<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('selectstart', e => e.preventDefault());
document.addEventListener('dragstart', e => e.preventDefault());
document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && ['I','J','C'].includes(e.key.toUpperCase())) e.preventDefault();
    if (e.key === 'F12') e.preventDefault();
});
document.addEventListener('touchstart', e => { if (e.touches.length > 1) e.preventDefault(); }, {passive:false});
</script>

<div class="border-b border-white/[0.05] bg-[#0e0d0b]">
    <div class="mx-auto flex h-8 max-w-7xl items-center justify-center gap-2 px-4 text-[9.5px] font-medium uppercase tracking-[0.22em] text-amber-100/50 sm:text-[10px]">
        <i class="fa-solid fa-gem text-[8px] text-amber-400/70"></i>
        <span>Complimentary insured shipping above ৳2,999</span>
        <span class="hidden text-amber-400/25 sm:inline">•</span>
        <span class="hidden sm:inline">Cash on delivery available</span>
    </div>
</div>

<header class="sticky top-0 z-40 border-b border-white/[0.06] bg-[#0b0a09]/85 backdrop-blur-xl">
    <div class="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-amber-400/50 to-transparent"></div>
    <div class="mx-auto flex h-[62px] max-w-7xl items-center justify-between gap-3 px-4 sm:px-6 lg:px-8">
        <a href="index.php" class="group flex items-center gap-3" aria-label="NIVAYA home">
            <span class="grid h-9 w-9 place-items-center rounded-xl border border-amber-400/25 bg-gradient-to-br from-amber-300/15 to-transparent text-amber-300 transition group-hover:border-amber-400/50">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="M12 2.8 19 9l-7 12.2L5 9l7-6.2Z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>
                    <path d="M5 9h14M9.2 9 12 21.2 14.8 9M9.2 9 12 2.8 14.8 9" stroke="currentColor" stroke-width="0.8" stroke-linejoin="round" opacity=".7"/>
                </svg>
            </span>
            <span class="flex flex-col leading-none">
                <span class="text-[15px] font-semibold tracking-[0.34em] text-white">NIVAYA</span>
                <span class="mt-1 hidden text-[8.5px] font-medium uppercase tracking-[0.28em] text-white/30 sm:block">Jewellery &amp; Accessories</span>
            </span>
        </a>

        <nav class="hidden items-center gap-1 md:flex" aria-label="Primary">
            <a href="index.php" class="nav-pill <?= $active_nav === 'home' ? 'is-active' : '' ?>">Home</a>
            <a href="index.php#collection" class="nav-pill">Collection</a>
            <a href="order_history.php" class="nav-pill <?= $active_nav === 'orders' ? 'is-active' : '' ?>">My Orders</a>
        </nav>

        <div class="flex items-center gap-2">
            <a href="order_history.php" class="grid h-9 w-9 place-items-center rounded-full border border-white/10 bg-white/[0.03] text-white/60 transition hover:border-amber-400/30 hover:text-amber-300" aria-label="My orders">
                <i class="fa-solid fa-box text-[13px]"></i>
            </a>
            <a href="profile.php" class="flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] p-1 pr-1 transition hover:border-amber-400/30 md:pr-3" aria-label="My profile">
                <span class="grid h-7 w-7 place-items-center rounded-full bg-gradient-to-br from-amber-300 to-amber-600 text-[10px] font-bold text-[#1a1408]"><?= e($session_initial) ?></span>
                <span class="hidden max-w-[92px] truncate text-[11px] font-medium text-white/70 md:block"><?= e($_SESSION['user_name'] ?? 'Profile') ?></span>
            </a>
        </div>
    </div>
</header>

<main id="main" class="mx-auto w-full max-w-7xl px-4 pb-12 pt-5 sm:px-6 sm:pt-7 lg:px-8">

<?php if ($flashes['success']): ?>
    <div class="alert-in mb-5 flex items-start gap-3 rounded-2xl border border-emerald-400/20 bg-emerald-400/[0.07] px-4 py-3.5 text-[13px] text-emerald-200" role="status">
        <i class="fa-solid fa-circle-check mt-0.5 text-emerald-400"></i>
        <p class="flex-1 leading-relaxed"><?= e($flashes['success']) ?></p>
        <button type="button" data-dismiss class="text-emerald-300/50 hover:text-emerald-200" aria-label="Dismiss"><i class="fa-solid fa-xmark"></i></button>
    </div>
<?php endif; ?>
<?php if ($flashes['error']): ?>
    <div class="alert-in mb-5 flex items-start gap-3 rounded-2xl border border-rose-400/20 bg-rose-400/[0.07] px-4 py-3.5 text-[13px] text-rose-200" role="alert">
        <i class="fa-solid fa-circle-exclamation mt-0.5 text-rose-400"></i>
        <p class="flex-1 leading-relaxed"><?= e($flashes['error']) ?></p>
        <button type="button" data-dismiss class="text-rose-300/50 hover:text-rose-200" aria-label="Dismiss"><i class="fa-solid fa-xmark"></i></button>
    </div>
<?php endif; ?>
<?php if ($flashes['info']): ?>
    <div class="alert-in mb-5 flex items-start gap-3 rounded-2xl border border-sky-400/20 bg-sky-400/[0.07] px-4 py-3.5 text-[13px] text-sky-200" role="status">
        <i class="fa-solid fa-circle-info mt-0.5 text-sky-400"></i>
        <p class="flex-1 leading-relaxed"><?= e($flashes['info']) ?></p>
        <button type="button" data-dismiss class="text-sky-300/50 hover:text-sky-200" aria-label="Dismiss"><i class="fa-solid fa-xmark"></i></button>
    </div>
<?php endif; ?>
