<?php
/**
 * NIVAYA — Database credentials  (THE ONLY FILE YOU NEED TO EDIT FOR YOUR HOST)
 * ---------------------------------------------------------------------------
 * INFINITYFREE CREDENTIALS (as provided):
 *   MySQL Host Name : sql203.infinityfree.com
 *   MySQL User Name : if0_43513417
 *   MySQL Password  : 5IiSjcF1uf
 *   MySQL Database  : if0_43513417_Meow
 *   MySQL Port      : 3306
 *
 * INFINITYFREE / iFastNet free hosting:
 *   1. Control Panel → "MySQL Databases" → create a database (this one may already exist).
 *   2. Copy the four values shown there into the constants below:
 *        DB_HOST  = MySQL Hostname   (looks like  sql123.infinityfree.com  — NOT "localhost")
 *        DB_USER  = MySQL Username   (looks like  if0_12345678)
 *        DB_PASS  = the password you set for that database user
 *        DB_NAME  = MySQL Database   (looks like  if0_12345678_nivaya)
 *   3. DB_PORT stays 3306.
 *
 * NOTE: On InfinityFree the database MUST be created from the control panel.
 *       PHP is not allowed to run CREATE DATABASE, so install.php only creates
 *       the tables inside the database you already created.
 *
 * Local development (XAMPP/LAMP): create common/db.local.php (see README) to
 * override these values without touching this file. db.local.php is never
 * included in the deployment ZIP.
 */

// Optional local override — only used if the file exists (excluded from the ZIP).
if (is_file(__DIR__ . '/db.local.php')) {
    require __DIR__ . '/db.local.php';
}

if (!defined('DB_HOST')) {
    define('DB_HOST', 'sql203.infinityfree.com'); // ← MySQL Host Name
}
if (!defined('DB_USER')) {
    define('DB_USER', 'if0_43513417');            // ← MySQL User Name
}
if (!defined('DB_PASS')) {
    define('DB_PASS', '5IiSjcF1uf');               // ← MySQL Password
}
if (!defined('DB_NAME')) {
    define('DB_NAME', 'if0_43513417_Meow');       // ← MySQL Database Name
}
if (!defined('DB_PORT')) {
    define('DB_PORT', 3306);
}
