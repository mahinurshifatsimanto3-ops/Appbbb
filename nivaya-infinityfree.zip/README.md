# NIVAYA — Jewellery & Accessories Store

A mobile-first online jewellery store built with **plain PHP + MySQL + Tailwind CSS + vanilla JavaScript** (no React/Vue/Laravel/jQuery/AJAX). Every action is a traditional PHP form submission with a page reload. Dark, gold-accented editorial design.

## Stack
- **PHP 8.1+** (mysqli, prepared statements everywhere)
- **MySQL / MariaDB**
- **Tailwind CSS** (pre-compiled to `assets/css/app.css` — no CDN needed)
- **Font Awesome 6** + **Poppins** (vendored locally in `assets/`)
- **Vanilla JS** for UI only (password toggles, quantity stepper, image preview, confirms)

The app is fully self-contained and works offline — all fonts, icons and CSS are local.

## Currency — Bangladeshi Taka (BDT)
- All prices are shown in the **Bangladeshi Taka** with the symbol **৳** (e.g. `৳2,999`).
- `common/config.php` defines `SITE_CURRENCY = '৳'` and the storefront/checkout JS uses
  `toLocaleString('en-US')` for Indian-digit grouping (৳2,999).
- Selling prices are rounded to the nearest taka after discount.

## Quick start (local — XAMPP / LAMP / MariaDB)
1. Copy the `nivaya/` folder into your web root (e.g. `htdocs/nivaya`).
2. Start **Apache** and **MySQL**.
3. Create a MySQL database (e.g. `nivaya_db`).
4. Put your local credentials in `common/db.local.php` (excluded from the deployment ZIP).
5. Visit **`http://localhost/nivaya/install.php`** once. It creates all tables and the default admin.
6. You'll be redirected to **`login.php`**. Register a customer account, or sign in.

### Default admin credentials
| Field | Value |
|---|---|
| Username | `admin` |
| Password 1 | `admin123` |
| Password 2 | `nivaya@2024` |

Admin panel: **`/admin/login.php`** — both passwords are required.
**Change them immediately** via *Admin → Settings*, and delete/rename `install.php` after setup.

## Structure
```
nivaya/
├─ common/            config.php · database.php · header.php · bottom.php · helpers
├─ admin/
│  ├─ common/         config.php · header.php · bottom.php · product_form.php
│  ├─ login.php       two-password admin sign-in
│  ├─ index.php       dashboard (stats, recent orders, most viewed)
│  ├─ orders.php      paginated orders, status filter, inline expand, status/delete actions
│  ├─ posts.php       paginated product list, search, edit/delete
│  ├─ add_post.php    create product (image upload)
│  ├─ edit_post.php   edit product (keeps image if none uploaded)
│  ├─ settings.php    rotate the two admin passwords
│  └─ logout.php
├─ login.php          customer login + register (single page, two modes)
├─ index.php          storefront home (hero, category chips, search, product grid)
├─ product.php        product detail + similar pieces + view tracking
├─ order.php          checkout + order confirmation receipt
├─ order_history.php  customer orders with status filters
├─ profile.php        customer details + address edit
├─ logout.php
├─ install.php        one-time installer (no CREATE DATABASE, no demo seeding, blocks re-install)
├─ database/          nivaya.sql — clean SQL export (schema + default admin)
├─ uploads/           product images (PHP execution denied via .htaccess, index.html guard)
└─ assets/            css/ · webfonts/ · img/  (compiled Tailwind, FA, Poppins, SVG art)
```

## Database
`users`, `admin`, `products`, `orders`, `product_views` (InnoDB, utf8mb4, foreign keys).
`orders` also stores `quantity` and a `unit_price` snapshot so order history stays
accurate even if a product's price changes or the product is deleted.

- **Local:** database `nivaya_db` (via `common/db.local.php` override).
- **Production (InfinityFree):** database e.g. `if0_XXXXXXXX_nivaya` (via `common/database.php`).

## Security
- Passwords hashed with `password_hash()` (bcrypt); verified with `password_verify()`.
- Every query uses prepared statements; all output escaped with `htmlspecialchars()`.
- Separate customer (`$_SESSION['user_id']`) and admin (`$_SESSION['admin_id']`) sessions.
- CSRF tokens on every form (separate tokens for storefront and admin).
- Image uploads validated by MIME (JPG/PNG/WebP), max 2 MB, renamed to a random hex name.
- `uploads/`, `common/`, `admin/common/` deny direct access / PHP execution via `.htaccess`.
- JS disables right-click, text selection and zoom shortcuts globally (per spec).
- Session hardening: strict mode, cookies-only session ids, secure cookie flags.

## Rebuilding the CSS (optional, only if you edit Tailwind classes)
```bash
npx tailwindcss@3.4.17 -i assets/css/tailwind.src.css -o assets/css/app.css --minify
```
`tailwind.config.js` and `assets/css/tailwind.src.css` are the sources; `app.css` is the
compiled output the pages actually load.

## Deployment — InfinityFree
1. Read **`DEPLOYMENT.md`** in this folder for the full step-by-step guide.
2. Create the MySQL database in the InfinityFree control panel (PHP cannot CREATE DATABASE there).
3. Upload the site into `htdocs/` (the ZIP is pre-configured for that layout).
4. Import `database/nivaya.sql` via phpMyAdmin.
5. Set the credentials in `common/database.php` (InfinityFree values).
6. Delete/rename `install.php`, then sign in at `/admin/login.php`.
