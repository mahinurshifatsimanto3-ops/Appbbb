<?php
declare(strict_types=1);
require_once __DIR__ . '/common/config.php';
require_user();

$productId = (int) ($_GET['id'] ?? 0);
$product = $productId > 0 ? find_product($conn, $productId) : null;

if (!$product) {
    http_response_code(404);
    $page_title = 'Piece not found · NIVAYA';
    $active_nav = 'home';
    include __DIR__ . '/common/header.php';
    ?>
    <div class="flex flex-col items-center py-20 text-center">
        <span class="grid h-16 w-16 place-items-center rounded-full border border-amber-400/20 bg-amber-400/[0.05] text-amber-300/70"><i class="fa-solid fa-gem text-xl"></i></span>
        <h1 class="mt-6 text-[24px] font-medium text-white">This piece has moved on</h1>
        <p class="mt-2 max-w-[340px] text-[12.5px] leading-relaxed text-white/35">The jewellery you're looking for is no longer available, but the rest of the collection is waiting.</p>
        <a href="index.php#collection" class="btn-gold mt-7">Browse the collection</a>
    </div>
    <?php
    include __DIR__ . '/common/bottom.php';
    exit;
}

/* Log this view */
$stmt = $conn->prepare('INSERT INTO product_views (product_id) VALUES (?)');
$stmt->bind_param('i', $productId);
$stmt->execute();
$stmt->close();

$stmt = $conn->prepare('SELECT COUNT(*) AS total FROM product_views WHERE product_id = ?');
$stmt->bind_param('i', $productId);
$stmt->execute();
$viewCount = (int) ($stmt->get_result()->fetch_assoc()['total'] ?? 0);
$stmt->close();

/* Similar pieces: same category first, then top up with other recent pieces so
   the row never looks empty when a category only has one or two items. */
$stmt = $conn->prepare('SELECT * FROM products WHERE category = ? AND id <> ? ORDER BY created_at DESC LIMIT 4');
$stmt->bind_param('si', $product['category'], $productId);
$stmt->execute();
$similar = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if (count($similar) < 4) {
    $excludeIds = array_merge([$productId], array_column($similar, 'id'));
    $placeholders = implode(',', array_fill(0, count($excludeIds), '?'));
    $types = str_repeat('i', count($excludeIds));
    $need = 4 - count($similar);
    $stmt = $conn->prepare("SELECT * FROM products WHERE id NOT IN ($placeholders) ORDER BY created_at DESC LIMIT ?");
    $types .= 'i';
    $excludeIds[] = $need;
    $stmt->bind_param($types, ...$excludeIds);
    $stmt->execute();
    $similar = array_merge($similar, $stmt->get_result()->fetch_all(MYSQLI_ASSOC));
    $stmt->close();
}

$price = product_price($product);
$original = (float) $product['original_price'];
$off = discount_percent($product);
$saving = max(0, $original - $price);
$tel = preg_replace('/[^0-9+]/', '', (string) $product['contact_number']) ?? '';

$page_title = $product['name'] . ' · NIVAYA';
$active_nav = 'home';
?>
<?php include __DIR__ . '/common/header.php'; ?>

<nav class="mb-5 flex flex-wrap items-center gap-2 text-[10px] text-white/25" aria-label="Breadcrumb">
    <a href="index.php" class="transition hover:text-amber-300/80">Home</a>
    <i class="fa-solid fa-chevron-right text-[7px] text-white/15"></i>
    <a href="index.php?category=<?= urlencode((string) $product['category']) ?>#collection" class="transition hover:text-amber-300/80"><?= e($product['category']) ?></a>
    <i class="fa-solid fa-chevron-right text-[7px] text-white/15"></i>
    <span class="max-w-[190px] truncate text-white/45"><?= e($product['name']) ?></span>
</nav>

<section class="grid gap-7 lg:grid-cols-2 lg:gap-12">
    <!-- Image -->
    <div class="animate-fade-up lg:sticky lg:top-[86px] lg:self-start">
        <div class="group relative overflow-hidden rounded-[24px] border border-white/[0.08] bg-[#12110f]">
            <div class="aspect-square overflow-hidden">
                <img src="<?= e(upload_url($product['image'])) ?>" alt="<?= e($product['name']) ?>" class="h-full w-full object-cover transition duration-[1.2s] group-hover:scale-[1.025]" data-fallback="assets/img/placeholder.svg">
            </div>
            <div class="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/35 via-transparent to-transparent"></div>
            <?php if ($off > 0): ?>
                <span class="absolute left-4 top-4 rounded-full border border-amber-300/30 bg-[#17130c]/90 px-3 py-1.5 text-[10px] font-bold tracking-wide text-amber-300 backdrop-blur"><?= $off ?>% OFF</span>
            <?php endif; ?>
            <div class="absolute bottom-4 left-4 right-4 flex items-center justify-between text-[9px] uppercase tracking-[0.16em] text-white/60">
                <span class="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-black/40 px-2.5 py-1.5 backdrop-blur"><i class="fa-solid fa-gem text-[8px] text-amber-300/70"></i>Signature piece</span>
                <span class="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-black/40 px-2.5 py-1.5 backdrop-blur"><i class="fa-regular fa-eye text-[8px] text-amber-300/70"></i><?= number_format($viewCount) ?> views</span>
            </div>
        </div>
        <div class="mt-3 grid grid-cols-3 gap-2.5">
            <div class="flex flex-col items-center gap-1 rounded-xl border border-white/[0.06] bg-white/[0.015] px-2 py-2.5 text-center">
                <i class="fa-solid fa-shield-halved text-[11px] text-amber-400/60"></i>
                <span class="text-[8.5px] text-white/30">Insured delivery</span>
            </div>
            <div class="flex flex-col items-center gap-1 rounded-xl border border-white/[0.06] bg-white/[0.015] px-2 py-2.5 text-center">
                <i class="fa-solid fa-rotate-left text-[11px] text-amber-400/60"></i>
                <span class="text-[8.5px] text-white/30">7-day exchange</span>
            </div>
            <div class="flex flex-col items-center gap-1 rounded-xl border border-white/[0.06] bg-white/[0.015] px-2 py-2.5 text-center">
                <i class="fa-solid fa-wallet text-[11px] text-amber-400/60"></i>
                <span class="text-[8.5px] text-white/30">Cash on delivery</span>
            </div>
        </div>
    </div>

    <!-- Details -->
    <div class="flex animate-fade-up flex-col">
        <div class="flex items-center gap-3">
            <span class="rounded-full border border-amber-400/20 bg-amber-400/[0.06] px-3 py-1 text-[9px] font-medium uppercase tracking-[0.18em] text-amber-300/80"><?= e($product['category']) ?></span>
            <?php if ($viewCount > 20): ?><span class="text-[9.5px] text-white/25"><i class="fa-solid fa-fire-flame-curved mr-1 text-amber-400/50"></i>Trending piece</span><?php endif; ?>
        </div>

        <h1 class="mt-4 text-[27px] font-normal leading-[1.2] tracking-[-0.03em] text-white sm:text-[34px]"><?= e($product['name']) ?></h1>

        <div class="mt-4 flex flex-wrap items-baseline gap-x-3 gap-y-1">
            <span class="text-[25px] font-semibold tracking-tight text-amber-300 sm:text-[29px]"><?= e(money($price)) ?></span>
            <?php if ($off > 0 && $original > $price): ?>
                <span class="text-[13px] text-white/25 line-through"><?= e(money($original)) ?></span>
                <span class="rounded-md border border-emerald-400/20 bg-emerald-400/[0.07] px-2 py-0.5 text-[9.5px] font-medium text-emerald-300/90">You save <?= e(money($saving)) ?></span>
            <?php endif; ?>
        </div>
        <p class="mt-1 text-[9.5px] text-white/20">Inclusive of all taxes · Shipping calculated at confirmation</p>

        <div class="my-6 h-px bg-gradient-to-r from-amber-400/25 via-white/[0.06] to-transparent"></div>

        <p class="whitespace-pre-line text-[12.5px] leading-[1.95] text-white/45"><?= e($product['description']) ?></p>

        <div class="mt-6 rounded-2xl border border-white/[0.07] bg-white/[0.02] p-4">
            <div class="flex items-center justify-between gap-3">
                <div class="flex items-center gap-3">
                    <span class="grid h-10 w-10 place-items-center rounded-full border border-amber-400/20 bg-amber-400/[0.06] text-amber-300/80"><i class="fa-solid fa-phone text-[13px]"></i></span>
                    <div>
                        <p class="text-[9px] uppercase tracking-[0.16em] text-white/30">Prefer to order on call?</p>
                        <a href="tel:<?= e($tel) ?>" class="mt-0.5 block text-[13px] font-medium text-white transition hover:text-amber-300"><?= e($product['contact_number']) ?></a>
                    </div>
                </div>
                <a href="tel:<?= e($tel) ?>" class="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-white/10 text-white/50 transition hover:border-amber-400/40 hover:text-amber-300" aria-label="Call about this piece"><i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i></a>
            </div>
        </div>

        <div class="mt-5 flex flex-col gap-2.5 sm:flex-row">
            <a href="order.php?id=<?= (int) $product['id'] ?>" class="btn-gold flex-1 py-3.5 text-[13px]">
                Order now
                <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
            <a href="tel:<?= e($tel) ?>" class="btn-outline flex-1 py-3.5">
                <i class="fa-solid fa-phone text-[11px]"></i>
                Call to enquire
            </a>
        </div>

        <div class="mt-6 grid grid-cols-2 gap-x-5 gap-y-3 text-[10px] text-white/30">
            <div class="flex items-center gap-2"><i class="fa-solid fa-box text-[10px] text-amber-400/50"></i>Gift-ready packaging</div>
            <div class="flex items-center gap-2"><i class="fa-solid fa-hand-sparkles text-[10px] text-amber-400/50"></i>Skin-friendly finish</div>
            <div class="flex items-center gap-2"><i class="fa-solid fa-truck-fast text-[10px] text-amber-400/50"></i>Ships in 2–4 days</div>
            <div class="flex items-center gap-2"><i class="fa-solid fa-location-dot text-[10px] text-amber-400/50"></i>Nationwide delivery</div>
        </div>

        <div class="mt-6 flex items-center gap-3 border-t border-white/[0.06] pt-4 text-[9px] uppercase tracking-[0.16em] text-white/22">
            <span>Ref. NV-<?= str_pad((string) $product['id'], 4, '0', STR_PAD_LEFT) ?></span>
            <span class="h-2.5 w-px bg-white/10"></span>
            <span><?= e($product['category']) ?></span>
        </div>
    </div>
</section>

<?php if ($similar): ?>
    <section class="mt-14 animate-fade-up border-t border-white/[0.06] pt-8">
        <div class="flex items-end justify-between gap-4">
            <div>
                <p class="eyebrow">Complete the edit</p>
                <h2 class="mt-2 text-[20px] font-medium tracking-[-0.02em] text-white sm:text-[23px]">Similar pieces</h2>
            </div>
            <a href="index.php?category=<?= urlencode((string) $product['category']) ?>#collection" class="hidden items-center gap-2 text-[10.5px] text-white/35 transition hover:text-amber-300 sm:inline-flex">
                View category <i class="fa-solid fa-arrow-right text-[9px]"></i>
            </a>
        </div>

        <div class="mt-5 grid grid-cols-2 gap-3.5 sm:gap-4 lg:grid-cols-4">
            <?php foreach ($similar as $item): ?>
                <a href="product.php?id=<?= (int) $item['id'] ?>" class="group overflow-hidden rounded-xl border border-white/[0.07] bg-[#12110f] transition duration-300 hover:-translate-y-0.5 hover:border-amber-400/20">
                    <div class="relative aspect-square overflow-hidden">
                        <img src="<?= e(upload_url($item['image'])) ?>" alt="<?= e($item['name']) ?>" loading="lazy" class="h-full w-full object-cover transition duration-700 group-hover:scale-105" data-fallback="assets/img/placeholder.svg">
                        <?php if (discount_percent($item) > 0): ?>
                            <span class="absolute left-2 top-2 rounded-full bg-black/55 px-1.5 py-0.5 text-[7.5px] font-semibold text-amber-300 backdrop-blur"><?= discount_percent($item) ?>% OFF</span>
                        <?php endif; ?>
                    </div>
                    <div class="p-2.5">
                        <p class="truncate text-[11px] font-medium text-white/80 group-hover:text-amber-100"><?= e($item['name']) ?></p>
                        <p class="mt-1 text-[11.5px] font-semibold text-amber-300"><?= e(money(product_price($item))) ?></p>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </section>
<?php endif; ?>

<?php include __DIR__ . '/common/bottom.php'; ?>
