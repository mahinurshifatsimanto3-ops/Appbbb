<?php
declare(strict_types=1);
require_once __DIR__ . '/common/config.php';
require_user();

$user = current_user($conn);
if (!$user) {
    unset($_SESSION['user_id'], $_SESSION['user_name']);
    redirect('login.php');
}
$_SESSION['user_name'] = $user['real_name'];

$page_title = 'My Orders · NIVAYA';
$active_nav = 'orders';

$allowedStatuses = ['pending', 'confirmed', 'delivered', 'cancelled'];
$statusFilter = (string) ($_GET['status'] ?? '');
if (!in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = '';
}
$viewId = (int) ($_GET['view'] ?? 0);
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 8;
$userId = (int) $user['id'];

/* Counts by status */
$stmt = $conn->prepare('SELECT status, COUNT(*) AS total FROM orders WHERE user_id = ? GROUP BY status');
$stmt->bind_param('i', $userId);
$stmt->execute();
$statusCounts = [];
$totalOrders = 0;
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $statusCounts[$row['status']] = (int) $row['total'];
    $totalOrders += (int) $row['total'];
}
$stmt->close();
$inProgress = ($statusCounts['pending'] ?? 0) + ($statusCounts['confirmed'] ?? 0);
$deliveredCount = $statusCounts['delivered'] ?? 0;

/* Filtered count */
$where = 'WHERE o.user_id = ?';
$params = [$userId];
$types = 'i';
if ($statusFilter !== '') {
    $where .= ' AND o.status = ?';
    $params[] = $statusFilter;
    $types .= 's';
}
$countSql = 'SELECT COUNT(*) AS total FROM orders o ' . $where;
$stmt = $conn->prepare($countSql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$filteredTotal = (int) ($stmt->get_result()->fetch_assoc()['total'] ?? 0);
$stmt->close();

$pages = max(1, (int) ceil($filteredTotal / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;

$listSql = 'SELECT o.*, p.name AS product_name, p.image AS product_image, p.contact_number, p.category
            FROM orders o LEFT JOIN products p ON p.id = o.product_id
            ' . $where . '
            ORDER BY o.created_at DESC, o.id DESC
            LIMIT ? OFFSET ?';
$stmt = $conn->prepare($listSql);
$listTypes = $types . 'ii';
$listParams = array_merge($params, [$perPage, $offset]);
$stmt->bind_param($listTypes, ...$listParams);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$filterLabels = ['' => 'All orders', 'pending' => 'Pending', 'confirmed' => 'Confirmed', 'delivered' => 'Delivered', 'cancelled' => 'Cancelled'];
?>
<?php include __DIR__ . '/common/header.php'; ?>

<div class="mb-6">
    <p class="eyebrow">Order desk</p>
    <div class="mt-2 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
        <div>
            <h1 class="text-[27px] font-normal tracking-[-0.03em] text-white sm:text-[32px]">Your orders</h1>
            <p class="mt-1.5 text-[11.5px] text-white/35">Every piece you've chosen, and where it is right now.</p>
        </div>
        <a href="index.php#collection" class="btn-outline self-start sm:self-auto"><i class="fa-solid fa-plus text-[10px]"></i>Browse more pieces</a>
    </div>
</div>

<div class="grid grid-cols-3 gap-2.5 sm:gap-4">
    <div class="rounded-2xl border border-white/[0.07] bg-[#12110f] p-3.5 sm:p-4">
        <div class="flex items-center justify-between">
            <p class="text-[8.5px] uppercase tracking-[0.16em] text-white/25">All orders</p>
            <i class="fa-solid fa-box text-[11px] text-amber-400/50"></i>
        </div>
        <p class="mt-2 text-[20px] font-semibold text-white sm:text-[24px]"><?= $totalOrders ?></p>
    </div>
    <div class="rounded-2xl border border-white/[0.07] bg-[#12110f] p-3.5 sm:p-4">
        <div class="flex items-center justify-between">
            <p class="text-[8.5px] uppercase tracking-[0.16em] text-white/25">In progress</p>
            <i class="fa-solid fa-clock text-[11px] text-amber-400/50"></i>
        </div>
        <p class="mt-2 text-[20px] font-semibold text-amber-300 sm:text-[24px]"><?= $inProgress ?></p>
    </div>
    <div class="rounded-2xl border border-white/[0.07] bg-[#12110f] p-3.5 sm:p-4">
        <div class="flex items-center justify-between">
            <p class="text-[8.5px] uppercase tracking-[0.16em] text-white/25">Delivered</p>
            <i class="fa-solid fa-circle-check text-[11px] text-amber-400/50"></i>
        </div>
        <p class="mt-2 text-[20px] font-semibold text-emerald-300 sm:text-[24px]"><?= $deliveredCount ?></p>
    </div>
</div>

<div class="no-scrollbar mt-6 -mx-4 flex gap-2 overflow-x-auto px-4 sm:mx-0 sm:flex-wrap sm:px-0">
    <?php foreach ($filterLabels as $key => $label): ?>
        <?php $count = $key === '' ? $totalOrders : ($statusCounts[$key] ?? 0); ?>
        <a href="order_history.php<?= $key !== '' ? '?status=' . $key : '' ?>" class="chip <?= $statusFilter === $key ? 'is-active' : '' ?>">
            <?= e($label) ?>
            <span class="<?= $statusFilter === $key ? 'text-amber-300/60' : 'text-white/20' ?>"><?= $count ?></span>
        </a>
    <?php endforeach; ?>
</div>

<?php if (!$orders): ?>
    <div class="mt-6 flex flex-col items-center rounded-3xl border border-dashed border-white/10 bg-white/[0.015] px-6 py-16 text-center">
        <span class="grid h-14 w-14 place-items-center rounded-full border border-amber-400/20 bg-amber-400/[0.05] text-amber-300/70"><i class="fa-solid fa-bag-shopping text-base"></i></span>
        <h2 class="mt-5 text-[17px] font-medium text-white"><?= $statusFilter !== '' ? 'No ' . e(strtolower($filterLabels[$statusFilter])) . ' orders' : 'Your jewellery box is waiting' ?></h2>
        <p class="mt-2 max-w-[320px] text-[12px] leading-relaxed text-white/35"><?= $statusFilter !== '' ? 'Try a different filter to see your other orders.' : 'When you place your first order, you can follow its journey right here.' ?></p>
        <?php if ($statusFilter !== ''): ?>
            <a href="order_history.php" class="btn-outline mt-6">View all orders</a>
        <?php else: ?>
            <a href="index.php#collection" class="btn-gold mt-6">Discover the collection</a>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="mt-5 space-y-3">
        <?php foreach ($orders as $order): ?>
            <?php
                $meta = status_meta((string) $order['status']);
                $orderTotal = (float) $order['unit_price'] * (int) $order['quantity'];
                $isOpen = $viewId === (int) $order['id'];
                $tel = preg_replace('/[^0-9+]/', '', (string) ($order['contact_number'] ?? '')) ?? '';
            ?>
            <details class="group overflow-hidden rounded-2xl border border-white/[0.07] bg-[#12110f] transition open:border-amber-400/20 open:bg-[#14120e]" <?= $isOpen ? 'open' : '' ?>>
                <summary class="flex cursor-pointer list-none items-center gap-3 p-3.5 sm:gap-4 sm:p-4">
                    <?php if ($order['product_image']): ?>
                        <img src="<?= e(upload_url($order['product_image'])) ?>" alt="<?= e($order['product_name'] ?? '') ?>" class="h-14 w-14 shrink-0 rounded-xl object-cover sm:h-16 sm:w-16" data-fallback="assets/img/placeholder.svg">
                    <?php else: ?>
                        <span class="grid h-14 w-14 shrink-0 place-items-center rounded-xl border border-white/[0.06] bg-white/[0.02] text-white/20 sm:h-16 sm:w-16"><i class="fa-solid fa-gem"></i></span>
                    <?php endif; ?>

                    <div class="min-w-0 flex-1">
                        <div class="flex flex-wrap items-center gap-2">
                            <span class="text-[8.5px] font-medium uppercase tracking-[0.14em] text-white/25">#NV<?= str_pad((string) $order['id'], 5, '0', STR_PAD_LEFT) ?></span>
                            <span class="badge-soft <?= e($meta['class']) ?>"><i class="fa-solid <?= e($meta['icon']) ?> text-[7px]"></i><?= e($meta['label']) ?></span>
                        </div>
                        <p class="mt-1 truncate text-[12.5px] font-medium text-white/85 sm:text-[13.5px]"><?= e($order['product_name'] ?? 'Piece no longer available') ?></p>
                        <p class="mt-1 text-[9.5px] text-white/25"><?= e(format_date($order['created_at'], 'j M Y')) ?> · Qty <?= (int) $order['quantity'] ?></p>
                    </div>

                    <div class="flex shrink-0 items-center gap-2.5 sm:gap-4">
                        <div class="text-right">
                            <p class="text-[13px] font-semibold text-amber-300 sm:text-[14px]"><?= e(money($orderTotal)) ?></p>
                            <p class="mt-0.5 text-[8px] uppercase tracking-[0.12em] text-white/20">Details</p>
                        </div>
                        <span class="grid h-7 w-7 place-items-center rounded-full border border-white/[0.08] text-white/30 transition group-open:rotate-180 group-open:border-amber-400/20 group-open:text-amber-300"><i class="fa-solid fa-chevron-down text-[8px]"></i></span>
                    </div>
                </summary>

                <div class="border-t border-white/[0.06] px-4 py-4 sm:px-5">
                    <div class="grid gap-5 sm:grid-cols-2">
                        <div>
                            <p class="text-[8.5px] font-semibold uppercase tracking-[0.16em] text-white/25">Delivery address</p>
                            <p class="mt-1.5 whitespace-pre-line text-[11px] leading-relaxed text-white/45"><?= e($order['delivery_address']) ?></p>
                            <?php if (!empty($order['order_note'])): ?>
                                <p class="mt-3 text-[8.5px] font-semibold uppercase tracking-[0.16em] text-white/25">Your note</p>
                                <p class="mt-1 whitespace-pre-line text-[10.5px] leading-relaxed text-white/35"><?= e($order['order_note']) ?></p>
                            <?php endif; ?>
                        </div>
                        <div>
                            <p class="text-[8.5px] font-semibold uppercase tracking-[0.16em] text-white/25">Payment summary</p>
                            <div class="mt-2 space-y-1.5 text-[10.5px] text-white/35">
                                <div class="flex justify-between"><span>Unit price</span><span class="text-white/55"><?= e(money((float) $order['unit_price'])) ?></span></div>
                                <div class="flex justify-between"><span>Quantity</span><span class="text-white/55"><?= (int) $order['quantity'] ?></span></div>
                                <div class="flex justify-between"><span>Shipping</span><span class="text-emerald-300/70">Free</span></div>
                                <div class="mt-1 flex justify-between border-t border-white/[0.06] pt-2 text-[11.5px]"><span class="text-white/50">Total</span><span class="font-semibold text-amber-300"><?= e(money($orderTotal)) ?></span></div>
                            </div>
                            <p class="mt-2.5 inline-flex items-center gap-1.5 rounded-full border border-white/[0.07] bg-white/[0.02] px-2.5 py-1 text-[8.5px] text-white/30"><i class="fa-solid fa-wallet text-[7px] text-amber-400/50"></i>Cash on delivery</p>
                        </div>
                    </div>

                    <div class="mt-4 flex flex-wrap items-center gap-2 border-t border-white/[0.06] pt-4">
                        <?php if (!empty($order['product_id'])): ?>
                            <a href="product.php?id=<?= (int) $order['product_id'] ?>" class="btn-dark"><i class="fa-solid fa-gem text-[9px]"></i>View piece</a>
                        <?php endif; ?>
                        <?php if ($tel !== ''): ?>
                            <a href="tel:<?= e($tel) ?>" class="btn-dark"><i class="fa-solid fa-phone text-[9px]"></i>Contact store</a>
                        <?php endif; ?>
                        <span class="ml-auto flex items-center gap-1.5 text-[9px] text-white/20"><i class="fa-solid fa-location-dot text-[8px]"></i>Delivering to <?= e($order['mobile']) ?></span>
                    </div>
                </div>
            </details>
        <?php endforeach; ?>
    </div>

    <?php if ($pages > 1): ?>
        <div class="mt-6 flex items-center justify-center gap-2">
            <?php if ($page > 1): ?>
                <a href="order_history.php?page=<?= $page - 1 ?><?= $statusFilter !== '' ? '&status=' . urlencode($statusFilter) : '' ?>" class="grid h-9 w-9 place-items-center rounded-full border border-white/10 text-white/40 transition hover:border-amber-400/30 hover:text-amber-300"><i class="fa-solid fa-chevron-left text-[9px]"></i></a>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $pages; $i++): ?>
                <a href="order_history.php?page=<?= $i ?><?= $statusFilter !== '' ? '&status=' . urlencode($statusFilter) : '' ?>" class="grid h-9 min-w-9 place-items-center rounded-full border px-3 text-[11px] transition <?= $i === $page ? 'border-amber-400/40 bg-amber-400/10 text-amber-300' : 'border-white/10 text-white/35 hover:border-white/20 hover:text-white/70' ?>"><?= $i ?></a>
            <?php endfor; ?>
            <?php if ($page < $pages): ?>
                <a href="order_history.php?page=<?= $page + 1 ?><?= $statusFilter !== '' ? '&status=' . urlencode($statusFilter) : '' ?>" class="grid h-9 w-9 place-items-center rounded-full border border-white/10 text-white/40 transition hover:border-amber-400/30 hover:text-amber-300"><i class="fa-solid fa-chevron-right text-[9px]"></i></a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php include __DIR__ . '/common/bottom.php'; ?>
