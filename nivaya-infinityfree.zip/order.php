<?php
declare(strict_types=1);
require_once __DIR__ . '/common/config.php';
require_user();

$user = current_user($conn);
if (!$user) {
    unset($_SESSION['user_id'], $_SESSION['user_name']);
    flash('error', 'Please sign in to place your order.');
    redirect('login.php');
}
$_SESSION['user_name'] = $user['real_name'];

$productId = (int) ($_GET['id'] ?? 0);
$product = $productId > 0 ? find_product($conn, $productId) : null;

$page_title = 'Checkout · NIVAYA';
$active_nav = 'orders';

/* Already placed? Show the confirmation receipt (PRG-safe). */
$placedId = (int) ($_GET['placed'] ?? 0);
if ($placedId > 0) {
    $stmt = $conn->prepare(
        'SELECT o.*, p.name AS product_name, p.image AS product_image, p.contact_number
         FROM orders o LEFT JOIN products p ON p.id = o.product_id
         WHERE o.id = ? AND o.user_id = ? LIMIT 1'
    );
    $stmt->bind_param('ii', $placedId, $_SESSION['user_id']);
    $stmt->execute();
    $placedOrder = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($placedOrder) {
        $placedTotal = (float) $placedOrder['unit_price'] * (int) $placedOrder['quantity'];
        include __DIR__ . '/common/header.php';
        ?>
        <div class="mx-auto max-w-2xl py-4 sm:py-8">
            <div class="animate-fade-up overflow-hidden rounded-[26px] border border-white/[0.08] bg-[#12110f]">
                <div class="relative border-b border-white/[0.06] px-6 py-9 text-center sm:px-10">
                    <div class="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(245,158,11,.10),transparent_65%)]"></div>
                    <div class="relative">
                        <span class="mx-auto grid h-16 w-16 place-items-center rounded-full border border-emerald-400/25 bg-emerald-400/[0.08] text-emerald-300">
                            <i class="fa-solid fa-check text-xl"></i>
                        </span>
                        <p class="eyebrow mt-5">Order confirmed</p>
                        <h1 class="mt-2.5 text-[24px] font-medium tracking-[-0.025em] text-white sm:text-[28px]">Thank you, <?= e(explode(' ', trim((string) $user['real_name']))[0]) ?>.</h1>
                        <p class="mx-auto mt-3 max-w-[380px] text-[12.5px] leading-relaxed text-white/40">Your order has been placed! Our team will contact you shortly to confirm the details.</p>
                        <span class="mt-4 inline-flex items-center gap-2 rounded-full border border-amber-400/25 bg-amber-400/[0.07] px-3.5 py-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-amber-300">
                            <i class="fa-solid fa-hashtag text-[9px]"></i>Order #NV<?= str_pad((string) $placedOrder['id'], 5, '0', STR_PAD_LEFT) ?>
                        </span>
                    </div>
                </div>

                <div class="p-6 sm:p-8">
                    <div class="flex gap-4">
                        <img src="<?= e(upload_url($placedOrder['product_image'])) ?>" alt="<?= e($placedOrder['product_name'] ?? 'Ordered piece') ?>" class="h-20 w-20 shrink-0 rounded-xl object-cover" data-fallback="assets/img/placeholder.svg">
                        <div class="min-w-0 flex-1">
                            <p class="text-[9px] uppercase tracking-[0.16em] text-white/25">Ordered piece</p>
                            <h2 class="mt-1 truncate text-[14px] font-medium text-white"><?= e($placedOrder['product_name'] ?? 'Piece no longer available') ?></h2>
                            <p class="mt-1 text-[11px] text-white/35">Qty <?= (int) $placedOrder['quantity'] ?> · <?= e(money((float) $placedOrder['unit_price'])) ?> each</p>
                        </div>
                        <p class="shrink-0 text-[14px] font-semibold text-amber-300"><?= e(money($placedTotal)) ?></p>
                    </div>

                    <div class="mt-6 grid gap-4 rounded-xl border border-white/[0.06] bg-white/[0.015] px-4 py-4 text-[11px] sm:grid-cols-2">
                        <div>
                            <p class="text-[8.5px] uppercase tracking-[0.16em] text-white/25">Delivering to</p>
                            <p class="mt-1 leading-relaxed text-white/55"><?= nl2br(e((string) $placedOrder['delivery_address'])) ?></p>
                        </div>
                        <div>
                            <p class="text-[8.5px] uppercase tracking-[0.16em] text-white/25">Contact</p>
                            <p class="mt-1 text-white/55"><?= e($placedOrder['customer_name']) ?></p>
                            <p class="mt-0.5 text-white/40"><?= e($placedOrder['mobile']) ?></p>
                            <span class="mt-2 inline-flex items-center gap-1.5 rounded-full border border-amber-400/20 bg-amber-400/[0.06] px-2.5 py-1 text-[8.5px] font-medium uppercase tracking-[0.12em] text-amber-300/90"><i class="fa-solid fa-clock text-[7px]"></i>Awaiting confirmation</span>
                        </div>
                    </div>

                    <div class="mt-6 flex flex-col gap-2.5 sm:flex-row">
                        <a href="order_history.php" class="btn-gold flex-1 py-3.5"><i class="fa-solid fa-box text-[11px]"></i>Track my order</a>
                        <a href="index.php#collection" class="btn-outline flex-1 py-3.5">Continue shopping</a>
                    </div>
                    <p class="mt-4 text-center text-[9.5px] leading-relaxed text-white/20">Keep this order number handy. We'll call you on <?= e($placedOrder['mobile']) ?> to confirm payment and delivery.</p>
                </div>
            </div>
        </div>
        <?php
        include __DIR__ . '/common/bottom.php';
        exit;
    }
}

if (!$product) {
    http_response_code(404);
    include __DIR__ . '/common/header.php';
    ?>
    <div class="flex flex-col items-center py-20 text-center">
        <span class="grid h-16 w-16 place-items-center rounded-full border border-amber-400/20 bg-amber-400/[0.05] text-amber-300/70"><i class="fa-solid fa-gem text-xl"></i></span>
        <h1 class="mt-6 text-[24px] font-medium text-white">This piece is unavailable</h1>
        <p class="mt-2 max-w-[340px] text-[12.5px] leading-relaxed text-white/35">It may have just been sold out. Explore the collection for something equally lovely.</p>
        <a href="index.php#collection" class="btn-gold mt-7">Browse the collection</a>
    </div>
    <?php
    include __DIR__ . '/common/bottom.php';
    exit;
}

$errors = [];
$deliveryAddress = trim((string) $user['address']);
$orderNote = '';
$quantity = 1;
$price = product_price($product);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $deliveryAddress = trim((string) ($_POST['delivery_address'] ?? ''));
    $orderNote = trim((string) ($_POST['order_note'] ?? ''));
    $quantity = (int) ($_POST['quantity'] ?? 1);

    if (mb_strlen($deliveryAddress) < 10 || mb_strlen($deliveryAddress) > 500) {
        $errors[] = 'Please enter a complete delivery address (10–500 characters).';
    }
    if ($quantity < 1 || $quantity > 10) {
        $errors[] = 'Please choose a quantity between 1 and 10.';
    }
    if (mb_strlen($orderNote) > 500) {
        $errors[] = 'Order notes can be up to 500 characters.';
    }

    if (!$errors) {
        $stmt = $conn->prepare(
            'INSERT INTO orders (user_id, product_id, customer_name, mobile, delivery_address, order_note, quantity, unit_price, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $userId = (int) $user['id'];
        $customerName = (string) $user['real_name'];
        $mobile = (string) $user['mobile'];
        $status = 'pending';
        $unitPrice = $price;
        $stmt->bind_param(
            'iissssids',
            $userId,
            $productId,
            $customerName,
            $mobile,
            $deliveryAddress,
            $orderNote,
            $quantity,
            $unitPrice,
            $status
        );
        $stmt->execute();
        $newOrderId = (int) $conn->insert_id;
        $stmt->close();

        redirect('order.php?id=' . $productId . '&placed=' . $newOrderId);
    }
}

$total = $price * $quantity;
$page_quantity = max(1, min(10, $quantity));
?>
<?php include __DIR__ . '/common/header.php'; ?>

<div class="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
    <div>
        <a href="product.php?id=<?= (int) $product['id'] ?>" class="inline-flex items-center gap-2 text-[10px] text-white/30 transition hover:text-amber-300">
            <i class="fa-solid fa-arrow-left text-[9px]"></i> Back to piece
        </a>
        <h1 class="mt-2.5 text-[25px] font-normal tracking-[-0.03em] text-white sm:text-[29px]">Secure checkout</h1>
    </div>
    <div class="flex items-center gap-3 text-[8.5px] uppercase tracking-[0.16em] text-white/25">
        <span class="flex items-center gap-1.5 text-amber-300/70"><i class="fa-solid fa-circle-check text-[9px]"></i>Details</span>
        <span class="h-px w-6 bg-white/10"></span>
        <span class="flex items-center gap-1.5"><i class="fa-regular fa-circle text-[9px]"></i>Confirmation</span>
    </div>
</div>

<?php if ($errors): ?>
    <div class="alert-in mb-5 rounded-2xl border border-rose-400/20 bg-rose-400/[0.06] px-4 py-3.5" role="alert">
        <div class="flex items-start gap-3 text-[12.5px] text-rose-200">
            <i class="fa-solid fa-circle-exclamation mt-0.5 text-rose-400"></i>
            <ul class="list-disc space-y-1 pl-4 leading-relaxed text-rose-200/75">
                <?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?>
            </ul>
        </div>
    </div>
<?php endif; ?>

<div class="grid gap-5 lg:grid-cols-[1.08fr_.92fr] lg:gap-7">
    <!-- Summary (first on mobile) -->
    <aside class="order-first lg:order-last lg:sticky lg:top-[86px] lg:self-start">
        <div class="overflow-hidden rounded-2xl border border-white/[0.08] bg-[#12110f]">
            <div class="border-b border-white/[0.06] px-5 py-3.5">
                <p class="text-[9.5px] font-semibold uppercase tracking-[0.2em] text-white/35">Order summary</p>
            </div>
            <div class="p-5">
                <div class="flex gap-4">
                    <a href="product.php?id=<?= (int) $product['id'] ?>" class="shrink-0">
                        <img src="<?= e(upload_url($product['image'])) ?>" alt="<?= e($product['name']) ?>" class="h-[74px] w-[74px] rounded-xl object-cover" data-fallback="assets/img/placeholder.svg">
                    </a>
                    <div class="min-w-0 flex-1">
                        <p class="text-[8.5px] uppercase tracking-[0.16em] text-amber-300/60"><?= e($product['category']) ?></p>
                        <p class="mt-1 truncate text-[13px] font-medium text-white"><?= e($product['name']) ?></p>
                        <p class="mt-1 text-[10.5px] text-white/30"><?= e(money($price)) ?> each</p>
                    </div>
                </div>

                <div class="mt-5 space-y-2.5 border-t border-white/[0.06] pt-4 text-[11px]">
                    <div class="flex items-center justify-between text-white/35"><span>Subtotal</span><span class="text-white/70" data-summary-subtotal><?= e(money($total)) ?></span></div>
                    <div class="flex items-center justify-between text-white/35"><span>Insured shipping</span><span class="text-emerald-300/80">Complimentary</span></div>
                    <div class="flex items-center justify-between text-white/35"><span>Gift packaging</span><span class="text-emerald-300/80">Included</span></div>
                </div>

                <div class="mt-4 flex items-baseline justify-between border-t border-white/[0.08] pt-4">
                    <div>
                        <p class="text-[10px] uppercase tracking-[0.16em] text-white/35">Total payable</p>
                        <p class="mt-0.5 text-[8.5px] text-white/20">Cash on delivery</p>
                    </div>
                    <p class="text-[20px] font-semibold text-amber-300" data-summary-total><?= e(money($total)) ?></p>
                </div>

                <div class="mt-5 flex items-start gap-2.5 rounded-xl border border-white/[0.06] bg-white/[0.015] px-3 py-2.5 text-[9.5px] leading-relaxed text-white/30">
                    <i class="fa-solid fa-shield-halved mt-0.5 text-amber-400/50"></i>
                    <p>No payment now. Our team will call to confirm your order and delivery before dispatch.</p>
                </div>
            </div>
        </div>
    </aside>

    <!-- Details form -->
    <section class="rounded-2xl border border-white/[0.08] bg-[#12110f]">
        <form method="post" action="order.php?id=<?= (int) $product['id'] ?>" data-lock>
            <?= csrf_field() ?>
            <div class="border-b border-white/[0.06] px-5 py-3.5">
                <p class="text-[9.5px] font-semibold uppercase tracking-[0.2em] text-white/35">Delivery details</p>
            </div>

            <div class="space-y-5 p-5">
                <div class="grid gap-4 sm:grid-cols-2">
                    <div>
                        <label class="label-text">Full name</label>
                        <div class="relative">
                            <input type="text" value="<?= e($user['real_name']) ?>" readonly class="input-field cursor-default bg-white/[0.02] pr-10 text-white/60">
                            <i class="fa-solid fa-lock pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-[9px] text-white/20"></i>
                        </div>
                    </div>
                    <div>
                        <label class="label-text">Mobile number</label>
                        <div class="relative">
                            <input type="tel" value="<?= e($user['mobile']) ?>" readonly class="input-field cursor-default bg-white/[0.02] pr-10 text-white/60">
                            <i class="fa-solid fa-lock pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-[9px] text-white/20"></i>
                        </div>
                    </div>
                </div>
                <p class="-mt-2 text-[9.5px] text-white/20">Need to change these? <a href="profile.php" class="text-amber-300/70 underline decoration-amber-400/20 underline-offset-2">Update your profile</a>.</p>

                <div>
                    <label for="delivery_address" class="label-text">Delivery address</label>
                    <textarea id="delivery_address" name="delivery_address" rows="3" maxlength="500" required class="input-field resize-none leading-relaxed" placeholder="House / street / area / city / PIN code"><?= e($deliveryAddress) ?></textarea>
                    <p class="mt-1.5 text-[9px] text-white/20">Please include a landmark and PIN code for a smooth delivery.</p>
                </div>

                <div class="grid gap-4 sm:grid-cols-[120px_1fr] sm:items-start">
                    <div>
                        <label class="label-text">Quantity</label>
                        <div class="flex items-center gap-0 rounded-xl border border-white/10 bg-[#14120f] p-1">
                            <button type="button" data-qty-down class="grid h-8 w-8 place-items-center rounded-lg text-white/40 transition hover:bg-white/[0.05] hover:text-white" aria-label="Decrease quantity"><i class="fa-solid fa-minus text-[9px]"></i></button>
                            <input id="quantity" name="quantity" type="number" min="1" max="10" value="<?= $page_quantity ?>" class="w-full border-0 bg-transparent p-0 text-center text-[12px] text-white outline-none focus:ring-0" data-qty-input aria-label="Quantity">
                            <button type="button" data-qty-up class="grid h-8 w-8 place-items-center rounded-lg text-white/40 transition hover:bg-white/[0.05] hover:text-white" aria-label="Increase quantity"><i class="fa-solid fa-plus text-[9px]"></i></button>
                        </div>
                    </div>
                    <div>
                        <label for="order_note" class="label-text">Order note <span class="normal-case tracking-normal text-white/15">(optional)</span></label>
                        <textarea id="order_note" name="order_note" rows="2" maxlength="500" class="input-field resize-none leading-relaxed" placeholder="Gift message, preferred delivery time…"><?= e($orderNote) ?></textarea>
                    </div>
                </div>

                <div class="hidden items-center justify-between rounded-xl border border-white/[0.06] bg-white/[0.015] px-4 py-3 text-[11px] sm:flex">
                    <span class="text-white/30">Order total</span>
                    <span class="font-semibold text-amber-300" data-form-total><?= e(money($total)) ?></span>
                </div>

                <button type="submit" class="btn-gold w-full py-3.5 text-[13px]">
                    <span data-btn-label>Confirm order</span>
                    <i class="fa-solid fa-arrow-right text-[10px]"></i>
                </button>
                <p class="text-center text-[9px] leading-relaxed text-white/20">By confirming, you agree to be contacted on your mobile number about this order. Payment is collected on delivery.</p>
            </div>
        </form>
    </section>
</div>

<script>
(function () {
    var input = document.querySelector('[data-qty-input]');
    if (!input) return;
    var unit = <?= json_encode($price) ?>;
    var currency = <?= json_encode(SITE_CURRENCY) ?>;
    var down = document.querySelector('[data-qty-down]');
    var up = document.querySelector('[data-qty-up]');
    var fmt = function (n) { return currency + Number(n).toLocaleString('en-US', { maximumFractionDigits: 0 }); };
    var refresh = function () {
        var qty = Math.max(1, Math.min(10, parseInt(input.value, 10) || 1));
        input.value = qty;
        var total = Math.round(unit * qty);
        document.querySelectorAll('[data-summary-subtotal], [data-summary-total], [data-form-total]').forEach(function (el) {
            el.textContent = fmt(total);
        });
    };
    if (down) down.addEventListener('click', function () { input.value = Math.max(1, (parseInt(input.value, 10) || 1) - 1); refresh(); });
    if (up) up.addEventListener('click', function () { input.value = Math.min(10, (parseInt(input.value, 10) || 1) + 1); refresh(); });
    input.addEventListener('change', refresh);
    refresh();
})();
</script>

<?php include __DIR__ . '/common/bottom.php'; ?>
