# NIVAYA — InfinityFree Deployment Guide

Complete, step-by-step instructions to get the NIVAYA jewellery store live on
**InfinityFree** (free hosting, PHP 8.x + MySQL).

---

## 0. What was prepared for InfinityFree

| Item | Status |
|---|---|
| DB host `sql203.infinityfree.com` in `common/database.php` | ✅ Set (provided credentials) |
| DB user / password / name | ✅ Set (provided credentials) |
| DB port `3306` + `mysqli` connect | ✅ Done in `common/config.php` |
| No `CREATE DATABASE` in installer | ✅ Removed (not allowed on InfinityFree) |
| No demo seeding in installer | ✅ Removed |
| Session hardening (strict mode, cookies-only, secure flags) | ✅ Done |
| `X-Powered-By` removal | ✅ Done |
| `.htaccess` without `Options` / `php_value` / `php_flag` | ✅ Done |
| `DirectoryIndex index.php` + caching headers | ✅ Done |
| BDT currency (`৳`) everywhere | ✅ Done |
| Admin two-password + settings rotate | ✅ Done |

## 1. Create the MySQL database (InfinityFree control panel)

1. Log in to your **InfinityFree account** → **Control Panel**.
2. Open **“MySQL Databases”** (sometimes listed under *Databases*).
3. Click **Create Database**.
   - Database name: use something like `if0_43513417_Meow` (or your preferred name; if you
     already have one from your account, use that exact name).
   - MySQL user will be auto-created (`if0_43513417`).
4. Set a database password and click **Create**.
5. Wait until the status shows **Active / Ready**.

> PHP on InfinityFree **cannot run `CREATE DATABASE`** — the database must exist before
> the installer can create tables inside it. The included `install.php` respects this.

## 2. Import the database

1. In the InfinityFree control panel, open **phpMyAdmin** (via *MySQL Databases* → *phpMyAdmin*
   or the *Databases* section).
2. Select the **newly created database** from the left sidebar (`if0_43513417_Meow`).
3. Click **Import**.
4. Choose the file **`database/nivaya.sql`** from the project ZIP (or upload it first via the
   file manager / FTP).
5. Click **Go**. Import may take up to a few minutes.
6. After import, verify you see these tables:
   `admin`, `orders`, `product_views`, `products`, `users`.

> If the import times out, re-run it — the file is small and idempotent (uses `CREATE TABLE IF NOT EXISTS` semantics via plain `CREATE TABLE` + fresh DB).

## 3. Configure database credentials

Edit **`common/database.php`** in the project folder and set the four constants to the values
shown in your InfinityFree control panel (or the ones already filled in for this account):

```php
define('DB_HOST', 'sql203.infinityfree.com');
define('DB_USER', 'if0_43513417');
define('DB_PASS', '5IiSjcF1uf');
define('DB_NAME', 'if0_43513417_Meow');
define('DB_PORT', 3306);
```

- `DB_HOST` must be the MySQL hostname from the control panel — **not** `localhost`.
- `DB_PORT` stays `3306`.

> ⚠️ Never commit real passwords anywhere else; `common/database.php` is the single source of truth.

## 4. Upload the project to htdocs

### Option A — via InfinityFree Upload (recommended)
1. In the control panel, open **“File Manager”** or **“Upload Files”**.
2. Upload `nivaya-infinityfree.zip` (or the extracted folder) so that it lands in:
   `htdocs/` (or `htdocs/public_html/`).
3. The site should end up at, for example:
   - `htdocs/nivaya/` (if you uploaded the `nivaya/` folder itself), **or**
   - `htdocs/` (if you uploaded the files directly).

### Option B — via FTP
1. Connect an FTP client (FileZilla) using your InfinityFree credentials.
2. Upload the project into `htdocs/`.
3. Set `htdocs/` permissions to **755**, and `htdocs/<project>/uploads/` to **755**.

## 5. Remove the installer

Once the site is verified live:

1. Delete **`install.php`** from the public root (recommended), or rename it to
   `install-disabled.php` so it can never be re-run.
2. Keep `database/nivaya.sql` on your local machine / repo — you may need it again.

## 6. Live checks

| Check | URL |
|---|---|
| Storefront | `https://<your-infinityfree-subdomain>.infinityfreeapp.com/nivaya/` |
| Login | `https://<your-infinityfree-subdomain>.infinityfreeapp.com/nivaya/login.php` |
| Admin | `https://<your-infinityfree-subdomain>.infinityfreeapp.com/nivaya/admin/login.php` |

## 7. Post-launch tasks (you)

1. **Change the default admin passwords** via *Admin → Settings* (two-password system).
2. **Add your real products** via *Admin → Add Product* (image upload works there).
3. **Place a small test order** to confirm checkout flow end-to-end.
4. **Point your custom domain** (if you have one) in the InfinityFree control panel.

---

## FAQ / troubleshooting

- **500 errors after upload:** Make sure there is no `common/db.local.php` in the ZIP (it is excluded).
- **`Options` / `php_value` / `php_flag` in .htaccess causes 500:** the shipped `.htaccess` files
  are already free of those directives (InfinityFree forbids them).
- **`install.php` says “Database connected” fails:** re-check credentials in `common/database.php`
  and that the DB is **Active** in the control panel.
- **Redirect loop after install:** after a successful install, `install.php` redirects to
  `login.php` — make sure you deleted it afterwards.
- **Currency shows `৳`:** all storefront + admin + JS formatting use BDT.
