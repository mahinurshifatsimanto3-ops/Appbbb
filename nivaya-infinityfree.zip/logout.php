<?php
declare(strict_types=1);
require_once __DIR__ . '/common/config.php';

unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['after_login']);
session_regenerate_id(true);
flash('success', 'You have been signed out. See you soon.');
redirect('login.php');
