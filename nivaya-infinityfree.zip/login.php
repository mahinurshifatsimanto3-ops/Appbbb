<?php
declare(strict_types=1);
require_once __DIR__ . '/common/config.php';

if (!empty($_SESSION['user_id'])) {
    redirect('index.php');
}

$mode = ($_GET['mode'] ?? '') === 'register' ? 'register' : 'login';
$errors = [];
$old = [
    'real_name' => '',
    'address'   => '',
    'mobile'    => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $formAction = $_POST['action'] ?? 'login';

    if ($formAction === 'login') {
        $mode = 'login';
        $mobile = trim((string) ($_POST['mobile'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        $old['mobile'] = $mobile;

        if ($mobile === '' || $password === '') {
            $errors[] = 'Enter your mobile number and password.';
        } else {
            $stmt = $conn->prepare('SELECT id, real_name, password FROM users WHERE mobile = ? LIMIT 1');
            $stmt->bind_param('s', $mobile);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($user && password_verify($password, (string) $user['password'])) {
                session_regenerate_id(true);
                $_SESSION['user_id'] = (int) $user['id'];
                $_SESSION['user_name'] = (string) $user['real_name'];

                $target = $_SESSION['after_login'] ?? null;
                unset($_SESSION['after_login']);
                if (is_string($target) && str_starts_with($target, '/') && !str_starts_with($target, '//')) {
                    redirect($target);
                }
                redirect('index.php');
            }
            $errors[] = 'Mobile number or password is incorrect.';
        }
    } else {
        $mode = 'register';
        $old['real_name'] = trim((string) ($_POST['real_name'] ?? ''));
        $old['address']   = trim((string) ($_POST['address'] ?? ''));
        $old['mobile']    = trim((string) ($_POST['mobile'] ?? ''));
        $password         = (string) ($_POST['password'] ?? '');

        if (mb_strlen($old['real_name']) < 2 || mb_strlen($old['real_name']) > 100) {
            $errors[] = 'Please enter your full name (2–100 characters).';
        }
        if (mb_strlen($old['address']) < 10 || mb_strlen($old['address']) > 500) {
            $errors[] = 'Please enter a complete delivery address (10–500 characters).';
        }
        if (!preg_match('/^[0-9+\-\s]{7,20}$/', $old['mobile'])) {
            $errors[] = 'Please enter a valid mobile number (7–20 digits).';
        }
        if (strlen($password) < 6) {
            $errors[] = 'Password must be at least 6 characters long.';
        }

        if (!$errors) {
            $stmt = $conn->prepare('SELECT id FROM users WHERE mobile = ? LIMIT 1');
            $stmt->bind_param('s', $old['mobile']);
            $stmt->execute();
            $exists = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($exists) {
                $errors[] = 'This mobile number is already registered. Try signing in instead.';
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                try {
                    $stmt = $conn->prepare('INSERT INTO users (real_name, address, mobile, password) VALUES (?, ?, ?, ?)');
                    $stmt->bind_param('ssss', $old['real_name'], $old['address'], $old['mobile'], $hash);
                    $stmt->execute();
                    $stmt->close();
                    flash('success', 'Your NIVAYA account is ready. Sign in to start shopping.');
                    redirect('login.php');
                } catch (mysqli_sql_exception $e) {
                    error_log('Registration failed: ' . $e->getMessage());
                    $errors[] = 'We could not create your account. Please try again.';
                }
            }
        }
    }
}

$flashSuccess = flash('success');
$flashError   = flash('error');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="theme-color" content="#0b0a09">
    <title><?= $mode === 'register' ? 'Create account' : 'Sign in' ?> · NIVAYA</title>
    <link rel="icon" href="assets/img/favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="assets/css/poppins.css">
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <meta name="robots" content="noindex,nofollow">
</head>
<body class="min-h-screen bg-[#0b0a09] antialiased">

<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('selectstart', e => e.preventDefault());
document.addEventListener('dragstart', e => e.preventDefault());
document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && ['I','J','C'].includes(e.key.toUpperCase())) e.preventDefault();
    if (e.key === 'F12') e.preventDefault();
});
document.addEventListener('touchstart', e => { if (e.touches.length > 1) e.preventDefault(); }, {passive:false});
</script>

<div class="relative grid min-h-screen lg:grid-cols-[1.05fr_1fr]">

    <!-- Brand / editorial side -->
    <aside class="relative hidden overflow-hidden border-r border-white/[0.06] bg-[#0e0c0a] lg:flex lg:flex-col">
        <div class="pointer-events-none absolute -left-32 top-1/3 h-[560px] w-[560px] rounded-full bg-amber-500/[0.06] blur-[120px]"></div>
        <div class="relative z-10 flex items-center justify-between px-12 pt-11">
            <a href="login.php" class="flex items-center gap-3">
                <span class="grid h-10 w-10 place-items-center rounded-xl border border-amber-400/25 bg-amber-400/[0.06] text-amber-300">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M12 2.8 19 9l-7 12.2L5 9l7-6.2Z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>
                        <path d="M5 9h14M9.2 9 12 21.2 14.8 9M9.2 9 12 2.8 14.8 9" stroke="currentColor" stroke-width=".8" stroke-linejoin="round" opacity=".7"/>
                    </svg>
                </span>
                <span class="text-[16px] font-semibold tracking-[0.34em] text-white">NIVAYA</span>
            </a>
            <span class="text-[9px] font-medium uppercase tracking-[0.25em] text-white/25">Est. 2024</span>
        </div>

        <div class="relative z-10 my-auto px-12 py-10 xl:px-16">
            <p class="eyebrow">The fine jewellery edit</p>
            <h1 class="mt-5 max-w-[480px] text-[42px] font-light leading-[1.12] tracking-[-0.03em] text-white xl:text-[52px]">
                A little gold<br>goes a <span class="gold-text font-normal">long way.</span>
            </h1>
            <p class="mt-5 max-w-[410px] text-[13px] leading-relaxed text-white/40">
                Thoughtfully designed rings, necklaces and keepsakes — made for everyday moments and the ones you'll never forget.
            </p>

            <div class="relative mt-9 max-w-[470px] overflow-hidden rounded-[26px] border border-white/[0.08] bg-[#12100d] shadow-[0_40px_100px_-40px_rgba(0,0,0,.9)]">
                <img src="assets/img/brand-hero.svg" alt="NIVAYA fine jewellery emblem" class="aspect-[16/10] w-full object-cover">
                <div class="absolute inset-x-0 bottom-0 flex items-end justify-between bg-gradient-to-t from-black/90 via-black/30 to-transparent p-5">
                    <div>
                        <p class="text-[9px] font-medium uppercase tracking-[0.22em] text-amber-300/80">The NIVAYA house</p>
                        <p class="mt-1 text-[13px] font-medium text-white">Fine jewellery, thoughtfully made</p>
                    </div>
                    <span class="grid h-8 w-8 place-items-center rounded-full border border-amber-400/30 bg-amber-400/10 text-amber-200"><i class="fa-solid fa-gem text-[11px]"></i></span>
                </div>
            </div>

            <div class="mt-9 flex max-w-[470px] items-center gap-4 border-t border-white/[0.06] pt-6">
                <span class="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-amber-400/20 bg-amber-400/[0.06] text-amber-300/80"><i class="fa-solid fa-hand-sparkles text-[13px]"></i></span>
                <p class="text-[10.5px] leading-relaxed text-white/35">Every piece is hand-finished and inspected before it ships, then delivered in a keepsake box.</p>
            </div>
        </div>

        <div class="relative z-10 flex items-center gap-6 border-t border-white/[0.05] px-12 py-5 text-[9.5px] uppercase tracking-[0.16em] text-white/25">
            <span><i class="fa-solid fa-shield-halved mr-1.5 text-amber-400/50"></i>Insured delivery</span>
            <span><i class="fa-solid fa-rotate-left mr-1.5 text-amber-400/50"></i>7-day exchange</span>
            <span><i class="fa-solid fa-wallet mr-1.5 text-amber-400/50"></i>Cash on delivery</span>
        </div>
    </aside>

    <!-- Form side -->
    <section class="relative flex min-h-screen flex-col">
        <div class="flex items-center justify-between px-5 pt-7 sm:px-8 lg:hidden">
            <a href="login.php" class="flex items-center gap-2.5">
                <span class="grid h-9 w-9 place-items-center rounded-xl border border-amber-400/25 bg-amber-400/[0.06] text-amber-300">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M12 2.8 19 9l-7 12.2L5 9l7-6.2Z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>
                        <path d="M5 9h14M9.2 9 12 21.2 14.8 9" stroke="currentColor" stroke-width=".8" stroke-linejoin="round" opacity=".7"/>
                    </svg>
                </span>
                <span class="text-[15px] font-semibold tracking-[0.3em] text-white">NIVAYA</span>
            </a>
            <span class="text-[9px] uppercase tracking-[0.2em] text-white/25">Jewellery &amp; Accessories</span>
        </div>

        <div class="flex flex-1 items-center justify-center px-5 py-9 sm:px-8 lg:px-12">
            <div class="w-full max-w-[420px] animate-fade-up">

                <div class="mb-8">
                    <div class="mb-4 flex h-11 w-11 items-center justify-center rounded-2xl border border-amber-400/20 bg-gradient-to-br from-amber-400/15 to-transparent text-amber-300">
                        <i class="fa-solid <?= $mode === 'register' ? 'fa-user-plus' : 'fa-arrow-right-to-bracket' ?> text-[15px]"></i>
                    </div>
                    <p class="eyebrow"><?= $mode === 'register' ? 'Join the house' : 'Welcome back' ?></p>
                    <h2 class="mt-2.5 text-[27px] font-medium tracking-[-0.025em] text-white sm:text-[30px]">
                        <?= $mode === 'register' ? 'Create your account' : 'Sign in to NIVAYA' ?>
                    </h2>
                    <p class="mt-2 text-[12px] leading-relaxed text-white/35">
                        <?= $mode === 'register'
                            ? 'A few details — then your edit of fine pieces is waiting.'
                            : 'Your saved pieces, orders and delivery details in one place.' ?>
                    </p>
                </div>

                <?php if ($flashSuccess): ?>
                    <div class="alert-in mb-5 flex items-start gap-3 rounded-2xl border border-emerald-400/20 bg-emerald-400/[0.07] px-4 py-3.5 text-[12.5px] text-emerald-200" role="status">
                        <i class="fa-solid fa-circle-check mt-0.5 text-emerald-400"></i>
                        <p class="flex-1 leading-relaxed"><?= e($flashSuccess) ?></p>
                    </div>
                <?php endif; ?>
                <?php if ($flashError): ?>
                    <div class="alert-in mb-5 flex items-start gap-3 rounded-2xl border border-rose-400/20 bg-rose-400/[0.07] px-4 py-3.5 text-[12.5px] text-rose-200" role="alert">
                        <i class="fa-solid fa-circle-exclamation mt-0.5 text-rose-400"></i>
                        <p class="flex-1 leading-relaxed"><?= e($flashError) ?></p>
                    </div>
                <?php endif; ?>
                <?php if ($errors): ?>
                    <div class="alert-in mb-5 rounded-2xl border border-rose-400/20 bg-rose-400/[0.06] px-4 py-3.5" role="alert">
                        <div class="flex items-start gap-3 text-[12.5px] text-rose-200">
                            <i class="fa-solid fa-circle-exclamation mt-0.5 text-rose-400"></i>
                            <div class="flex-1">
                                <p class="font-medium">Please check the following</p>
                                <ul class="mt-1.5 list-disc space-y-1 pl-4 text-[12px] leading-relaxed text-rose-200/75">
                                    <?php foreach ($errors as $error): ?>
                                        <li><?= e($error) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($mode === 'login'): ?>
                    <form method="post" action="login.php" class="space-y-4" data-lock>
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="login">
                        <div>
                            <label for="mobile" class="label-text">Mobile number</label>
                            <div class="relative">
                                <span class="pointer-events-none absolute inset-y-0 left-0 flex w-11 items-center justify-center text-white/25"><i class="fa-solid fa-mobile-screen-button text-[12px]"></i></span>
                                <input id="mobile" name="mobile" type="tel" inputmode="tel" autocomplete="tel" maxlength="20" required value="<?= e($old['mobile']) ?>" placeholder="98765 43210" class="input-field pl-11">
                            </div>
                        </div>
                        <div>
                            <div class="mb-1.5 flex items-center justify-between">
                                <label for="password" class="label-text mb-0">Password</label>
                                <span class="text-[9.5px] text-white/20">Minimum 6 characters</span>
                            </div>
                            <div class="relative">
                                <span class="pointer-events-none absolute inset-y-0 left-0 flex w-11 items-center justify-center text-white/25"><i class="fa-solid fa-lock text-[12px]"></i></span>
                                <input id="password" name="password" type="password" autocomplete="current-password" required placeholder="Enter your password" class="input-field px-11">
                                <button type="button" class="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-white/25 transition hover:text-amber-300" data-toggle-password="password" aria-label="Show password">
                                    <i class="fa-regular fa-eye text-[12px]"></i>
                                </button>
                            </div>
                        </div>
                        <button type="submit" class="btn-gold mt-2 w-full py-3.5">
                            <span data-btn-label>Sign in</span>
                            <i class="fa-solid fa-arrow-right text-[11px]"></i>
                        </button>
                    </form>

                    <p class="mt-6 text-center text-[12px] text-white/35">
                        New here?
                        <a href="login.php?mode=register" class="ml-1 font-medium text-amber-300 underline decoration-amber-400/30 underline-offset-4 transition hover:text-amber-200">Create an account</a>
                    </p>
                <?php else: ?>
                    <form method="post" action="login.php?mode=register" class="space-y-3.5" data-lock>
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="register">
                        <div>
                            <label for="real_name" class="label-text">Full name</label>
                            <div class="relative">
                                <span class="pointer-events-none absolute inset-y-0 left-0 flex w-11 items-center justify-center text-white/25"><i class="fa-regular fa-user text-[12px]"></i></span>
                                <input id="real_name" name="real_name" type="text" autocomplete="name" maxlength="100" required value="<?= e($old['real_name']) ?>" placeholder="Your full name" class="input-field pl-11">
                            </div>
                        </div>
                        <div>
                            <label for="address" class="label-text">Delivery address</label>
                            <textarea id="address" name="address" rows="2" maxlength="500" required placeholder="House / street / city / PIN code" class="input-field resize-none leading-relaxed"><?= e($old['address']) ?></textarea>
                        </div>
                        <div>
                            <label for="mobile" class="label-text">Mobile number</label>
                            <div class="relative">
                                <span class="pointer-events-none absolute inset-y-0 left-0 flex w-11 items-center justify-center text-white/25"><i class="fa-solid fa-mobile-screen-button text-[12px]"></i></span>
                                <input id="mobile" name="mobile" type="tel" inputmode="tel" autocomplete="tel" maxlength="20" required value="<?= e($old['mobile']) ?>" placeholder="98765 43210" class="input-field pl-11">
                            </div>
                        </div>
                        <div>
                            <label for="password" class="label-text">Create password</label>
                            <div class="relative">
                                <span class="pointer-events-none absolute inset-y-0 left-0 flex w-11 items-center justify-center text-white/25"><i class="fa-solid fa-lock text-[12px]"></i></span>
                                <input id="password" name="password" type="password" autocomplete="new-password" minlength="6" required placeholder="At least 6 characters" class="input-field px-11">
                                <button type="button" class="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-white/25 transition hover:text-amber-300" data-toggle-password="password" aria-label="Show password">
                                    <i class="fa-regular fa-eye text-[12px]"></i>
                                </button>
                            </div>
                        </div>
                        <p class="text-[10px] leading-relaxed text-white/20">By creating an account you agree to receive order updates on your mobile number.</p>
                        <button type="submit" class="btn-gold mt-2 w-full py-3.5">
                            <span data-btn-label>Create account</span>
                            <i class="fa-solid fa-arrow-right text-[11px]"></i>
                        </button>
                    </form>

                    <p class="mt-6 text-center text-[12px] text-white/35">
                        Already have an account?
                        <a href="login.php" class="ml-1 font-medium text-amber-300 underline decoration-amber-400/30 underline-offset-4 transition hover:text-amber-200">Sign in</a>
                    </p>
                <?php endif; ?>

                <div class="mt-9 flex items-center justify-center gap-5 border-t border-white/[0.06] pt-5 text-[9px] uppercase tracking-[0.16em] text-white/20 lg:hidden">
                    <span><i class="fa-solid fa-shield-halved mr-1 text-amber-400/40"></i>Insured</span>
                    <span><i class="fa-solid fa-rotate-left mr-1 text-amber-400/40"></i>7-day exchange</span>
                    <span><i class="fa-solid fa-wallet mr-1 text-amber-400/40"></i>COD</span>
                </div>

                <p class="mt-8 text-center text-[9.5px] tracking-wide text-white/15">
                    © <?= date('Y') ?> NIVAYA · <a href="admin/login.php" class="transition hover:text-white/30">Staff access</a>
                </p>
            </div>
        </div>
    </section>
</div>

<script>
document.querySelectorAll('[data-toggle-password]').forEach(function (btn) {
    btn.addEventListener('click', function () {
        var input = document.getElementById(btn.dataset.togglePassword);
        if (!input) return;
        var show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        var icon = btn.querySelector('i');
        if (icon) icon.className = show ? 'fa-regular fa-eye-slash text-[12px]' : 'fa-regular fa-eye text-[12px]';
        btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    });
});
document.querySelectorAll('form[data-lock]').forEach(function (form) {
    form.addEventListener('submit', function () {
        var btn = form.querySelector('button[type="submit"]');
        if (!btn) return;
        setTimeout(function () {
            btn.disabled = true;
            btn.classList.add('opacity-70');
            var label = btn.querySelector('[data-btn-label]');
            if (label) label.textContent = 'Please wait…';
        }, 10);
    });
});
</script>
</body>
</html>
