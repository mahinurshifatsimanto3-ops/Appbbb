<?php
declare(strict_types=1);
require_once __DIR__ . '/common/config.php';
require_user();

$user = current_user($conn);
if (!$user) {
    unset($_SESSION['user_id'], $_SESSION['user_name']);
    redirect('login.php');
}
$_SESSION['user_name'] = $user['real_name'];
$userId = (int) $user['id'];

$errors = [];
$old = [
    'real_name' => (string) $user['real_name'],
    'address'   => (string) $user['address'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $old['real_name'] = trim((string) ($_POST['real_name'] ?? ''));
    $old['address']   = trim((string) ($_POST['address'] ?? ''));

    if (mb_strlen($old['real_name']) < 2 || mb_strlen($old['real_name']) > 100) {
        $errors[] = 'Please enter your full name (2–100 characters).';
    }
    if (mb_strlen($old['address']) < 10 || mb_strlen($old['address']) > 500) {
        $errors[] = 'Please enter a complete delivery address (10–500 characters).';
    }

    if (!$errors) {
        $stmt = $conn->prepare('UPDATE users SET real_name = ?, address = ? WHERE id = ?');
        $stmt->bind_param('ssi', $old['real_name'], $old['address'], $userId);
        $stmt->execute();
        $stmt->close();
        $_SESSION['user_name'] = $old['real_name'];
        flash('success', 'Your details have been updated.');
        redirect('profile.php');
    }
}

$stmt = $conn->prepare('SELECT status, COUNT(*) AS total FROM orders WHERE user_id = ? GROUP BY status');
$stmt->bind_param('i', $userId);
$stmt->execute();
$statusCounts = [];
$orderTotal = 0;
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $statusCounts[$row['status']] = (int) $row['total'];
    $orderTotal += (int) $row['total'];
}
$stmt->close();
$inProgress = ($statusCounts['pending'] ?? 0) + ($statusCounts['confirmed'] ?? 0);
$delivered = $statusCounts['delivered'] ?? 0;

$stmt = $conn->prepare(
    'SELECT o.*, p.name AS product_name, p.image AS product_image
     FROM orders o LEFT JOIN products p ON p.id = o.product_id
     WHERE o.user_id = ? ORDER BY o.created_at DESC, o.id DESC LIMIT 3'
);
$stmt->bind_param('i', $userId);
$stmt->execute();
$recentOrders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$page_title = 'My Profile · NIVAYA';
$active_nav = 'profile';
$initial = initials((string) $user['real_name']);
?>
<?php include __DIR__ . '/common/header.php'; ?>

<div class="mb-6">
    <p class="eyebrow">Your account</p>
    <h1 class="mt-2 text-[27px] font-normal tracking-[-0.03em] text-white sm:text-[32px]">Profile</h1>
    <p class="mt-1.5 text-[11.5px] text-white/35">The details we use to get your jewellery safely to you.</p>
</div>

<?php if ($errors): ?>
    <div class="alert-in mb-5 rounded-2xl border border-rose-400/20 bg-rose-400/[0.06] px-4 py-3.5" role="alert">
        <div class="flex items-start gap-3 text-[12.5px] text-rose-200">
            <i class="fa-solid fa-circle-exclamation mt-0.5 text-rose-400"></i>
            <ul class="list-disc space-y-1 pl-4 leading-relaxed text-rose-200/75">
                <?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?>
            </ul>
        </div>
    </div>
<?php endif; ?>

<div class="grid gap-5 lg:grid-cols-[.85fr_1.15fr] lg:gap-6">
    <!-- Identity card -->
    <aside class="space-y-4">
        <div class="relative overflow-hidden rounded-2xl border border-white/[0.08] bg-[#12110f]">
            <div class="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-amber-500/[0.07] blur-3xl"></div>
            <div class="relative p-5 sm:p-6">
                <div class="flex items-center gap-4">
                    <span class="grid h-16 w-16 place-items-center rounded-2xl border border-amber-300/30 bg-gradient-to-br from-amber-300 to-amber-600 text-[20px] font-semibold text-[#1b1407] shadow-[0_12px_30px_-10px_rgba(245,158,11,.4)]"><?= e($initial) ?></span>
                    <div class="min-w-0">
                        <h2 class="truncate text-[17px] font-medium text-white"><?= e($user['real_name']) ?></h2>
                        <p class="mt-1 text-[11px] text-white/35"><?= e($user['mobile']) ?></p>
                        <span class="mt-2 inline-flex items-center gap-1.5 rounded-full border border-amber-400/20 bg-amber-400/[0.06] px-2.5 py-1 text-[8px] font-medium uppercase tracking-[0.14em] text-amber-300/80"><i class="fa-solid fa-gem text-[6px]"></i>NIVAYA member</span>
                    </div>
                </div>

                <div class="mt-5 grid grid-cols-3 gap-2 border-t border-white/[0.07] pt-5">
                    <div class="text-center">
                        <p class="text-[18px] font-semibold text-white"><?= $orderTotal ?></p>
                        <p class="mt-0.5 text-[8px] uppercase tracking-[0.1em] text-white/25">Orders</p>
                    </div>
                    <div class="border-x border-white/[0.06] text-center">
                        <p class="text-[18px] font-semibold text-amber-300"><?= $inProgress ?></p>
                        <p class="mt-0.5 text-[8px] uppercase tracking-[0.1em] text-white/25">In progress</p>
                    </div>
                    <div class="text-center">
                        <p class="text-[18px] font-semibold text-emerald-300"><?= $delivered ?></p>
                        <p class="mt-0.5 text-[8px] uppercase tracking-[0.1em] text-white/25">Delivered</p>
                    </div>
                </div>

                <p class="mt-4 flex items-center justify-center gap-1.5 text-[8.5px] uppercase tracking-[0.14em] text-white/20">
                    <i class="fa-regular fa-calendar text-[8px]"></i>Member since <?= e(format_date($user['created_at'], 'M Y')) ?>
                </p>
            </div>
        </div>

        <!-- Recent orders -->
        <div class="rounded-2xl border border-white/[0.07] bg-[#12110f] p-4 sm:p-5">
            <div class="flex items-center justify-between">
                <p class="text-[9px] font-semibold uppercase tracking-[0.18em] text-white/30">Recent orders</p>
                <a href="order_history.php" class="text-[9.5px] text-amber-300/70 transition hover:text-amber-200">View all</a>
            </div>
            <?php if (!$recentOrders): ?>
                <div class="mt-4 flex flex-col items-center rounded-xl border border-dashed border-white/[0.08] px-4 py-7 text-center">
                    <i class="fa-solid fa-bag-shopping text-[16px] text-white/15"></i>
                    <p class="mt-2.5 text-[10.5px] text-white/30">No orders yet. Your first piece is waiting.</p>
                    <a href="index.php#collection" class="mt-3 text-[10px] text-amber-300/80 underline decoration-amber-400/25 underline-offset-4">Browse collection</a>
                </div>
            <?php else: ?>
                <div class="mt-3 space-y-2">
                    <?php foreach ($recentOrders as $order): ?>
                        <?php $meta = status_meta((string) $order['status']); ?>
                        <a href="order_history.php?view=<?= (int) $order['id'] ?>" class="flex items-center gap-3 rounded-xl border border-white/[0.05] bg-white/[0.015] p-2.5 transition hover:border-amber-400/20 hover:bg-white/[0.03]">
                            <img src="<?= e(upload_url($order['product_image'])) ?>" alt="<?= e($order['product_name'] ?? '') ?>" class="h-10 w-10 rounded-lg object-cover" data-fallback="assets/img/placeholder.svg">
                            <div class="min-w-0 flex-1">
                                <p class="truncate text-[11px] font-medium text-white/75"><?= e($order['product_name'] ?? 'Unavailable piece') ?></p>
                                <p class="mt-0.5 text-[8.5px] text-white/25">#NV<?= str_pad((string) $order['id'], 5, '0', STR_PAD_LEFT) ?> · <?= e(format_date($order['created_at'], 'j M')) ?></p>
                            </div>
                            <span class="badge-soft <?= e($meta['class']) ?> !px-2 !py-0.5 !text-[7px]"><?= e($meta['label']) ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <a href="logout.php" class="flex items-center justify-between rounded-2xl border border-rose-400/10 bg-rose-400/[0.03] px-4 py-3.5 text-[11px] text-rose-300/70 transition hover:border-rose-400/25 hover:bg-rose-400/[0.06]">
            <span class="flex items-center gap-2.5"><i class="fa-solid fa-arrow-right-from-bracket text-[11px]"></i>Sign out of NIVAYA</span>
            <i class="fa-solid fa-chevron-right text-[8px] opacity-50"></i>
        </a>
    </aside>

    <!-- Details form -->
    <section class="rounded-2xl border border-white/[0.08] bg-[#12110f]">
        <div class="border-b border-white/[0.06] px-5 py-4">
            <h2 class="text-[13px] font-medium text-white">Personal details</h2>
            <p class="mt-1 text-[10px] text-white/25">Used for orders and delivery. Your mobile number is your sign-in ID.</p>
        </div>
        <form method="post" action="profile.php" class="space-y-5 p-5" data-lock>
            <?= csrf_field() ?>
            <div class="grid gap-4 sm:grid-cols-2">
                <div>
                    <label for="real_name" class="label-text">Full name</label>
                    <input id="real_name" name="real_name" type="text" maxlength="100" required value="<?= e($old['real_name']) ?>" class="input-field">
                </div>
                <div>
                    <label class="label-text">Mobile number</label>
                    <div class="relative">
                        <input type="tel" value="<?= e($user['mobile']) ?>" readonly class="input-field cursor-default bg-white/[0.02] pr-10 text-white/50">
                        <i class="fa-solid fa-lock pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-[9px] text-white/20"></i>
                    </div>
                    <p class="mt-1.5 text-[8.5px] text-white/20">Contact the store to change your mobile number.</p>
                </div>
            </div>
            <div>
                <label for="address" class="label-text">Default delivery address</label>
                <textarea id="address" name="address" rows="4" maxlength="500" required class="input-field resize-none leading-relaxed"><?= e($old['address']) ?></textarea>
                <p class="mt-1.5 text-[9px] text-white/20">This will be pre-filled at checkout. You can still edit it for each order.</p>
            </div>
            <div class="flex flex-col gap-2.5 border-t border-white/[0.06] pt-5 sm:flex-row sm:items-center sm:justify-between">
                <p class="flex items-center gap-2 text-[9px] text-white/20"><i class="fa-solid fa-lock text-[8px] text-emerald-400/50"></i>Your details are stored securely.</p>
                <button type="submit" class="btn-gold sm:w-auto" data-btn-label>Save changes</button>
            </div>
        </form>

        <div class="border-t border-white/[0.06] px-5 py-4">
            <p class="text-[9px] font-semibold uppercase tracking-[0.18em] text-white/25">Need help?</p>
            <div class="mt-3 grid gap-2 sm:grid-cols-2">
                <a href="order_history.php" class="flex items-center gap-3 rounded-xl border border-white/[0.06] bg-white/[0.015] px-3 py-2.5 text-[10.5px] text-white/45 transition hover:border-amber-400/20 hover:text-white/70">
                    <i class="fa-solid fa-box text-[11px] text-amber-400/50"></i>Track my orders
                </a>
                <a href="index.php#collection" class="flex items-center gap-3 rounded-xl border border-white/[0.06] bg-white/[0.015] px-3 py-2.5 text-[10.5px] text-white/45 transition hover:border-amber-400/20 hover:text-white/70">
                    <i class="fa-solid fa-gem text-[11px] text-amber-400/50"></i>Explore new pieces
                </a>
            </div>
        </div>
    </section>
</div>

<?php include __DIR__ . '/common/bottom.php'; ?>
