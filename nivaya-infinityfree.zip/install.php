<?php
declare(strict_types=1);
define('NIVAYA_SKIP_DB', true);
require_once __DIR__ . '/common/config.php';

$errors = [];
$steps = [];
$alreadyInstalled = false;
$adminSeeded = false;
$tablesReady = false;
$adminCredentials = [
    'username' => 'admin',
    'password1' => 'admin123',
    'password2' => 'nivaya@2024',
];

try {
    // Connect straight to the database. On InfinityFree the database must already
    // exist (created in the control panel) — PHP is not allowed to CREATE DATABASE.
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, (int) DB_PORT);
    $conn->set_charset('utf8mb4');
    $steps[] = ['Database connected', DB_NAME . ' is reachable.', true];

    /* Is the store already installed? (admin table exists and has an account) */
    $adminCount = 0;
    $hasAdminTable = false;
    $tableCheck = $conn->query("SHOW TABLES LIKE 'admin'");
    if ($tableCheck && $tableCheck->num_rows > 0) {
        $hasAdminTable = true;
        $adminCount = (int) $conn->query('SELECT COUNT(*) AS c FROM admin')->fetch_assoc()['c'];
    }

    if ($hasAdminTable && $adminCount > 0) {
        $alreadyInstalled = true;
    } else {
        /* 1. Tables */
        $conn->query("CREATE TABLE IF NOT EXISTS users (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            real_name VARCHAR(100) NOT NULL,
            address TEXT NOT NULL,
            mobile VARCHAR(20) NOT NULL,
            password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_users_mobile (mobile)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS admin (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            username VARCHAR(50) NOT NULL,
            password1 VARCHAR(255) NOT NULL,
            password2 VARCHAR(255) NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_admin_username (username)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS products (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(150) NOT NULL,
            category VARCHAR(100) NOT NULL,
            original_price DECIMAL(10,2) NOT NULL,
            discount_percent TINYINT UNSIGNED NOT NULL DEFAULT 0,
            discounted_price DECIMAL(10,2) NOT NULL,
            description TEXT NOT NULL,
            contact_number VARCHAR(20) NOT NULL,
            image VARCHAR(255) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_products_category (category),
            KEY idx_products_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS orders (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            product_id INT UNSIGNED NULL,
            customer_name VARCHAR(100) NOT NULL,
            mobile VARCHAR(20) NOT NULL,
            delivery_address TEXT NOT NULL,
            order_note TEXT NULL,
            quantity INT UNSIGNED NOT NULL DEFAULT 1,
            unit_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            status ENUM('pending','confirmed','delivered','cancelled') NOT NULL DEFAULT 'pending',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_orders_user (user_id),
            KEY idx_orders_status (status),
            KEY idx_orders_created (created_at),
            CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
            CONSTRAINT fk_orders_product FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS product_views (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            product_id INT UNSIGNED NOT NULL,
            viewed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_views_product (product_id),
            CONSTRAINT fk_views_product FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $tablesReady = true;
        $steps[] = ['All tables ready', 'users, admin, products, orders & product_views.', true];

        /* 2. Default admin (required system account) */
        $adminCount = (int) $conn->query('SELECT COUNT(*) AS c FROM admin')->fetch_assoc()['c'];
        if ($adminCount === 0) {
            $hash1 = password_hash($adminCredentials['password1'], PASSWORD_BCRYPT);
            $hash2 = password_hash($adminCredentials['password2'], PASSWORD_BCRYPT);
            $username = $adminCredentials['username'];
            $stmt = $conn->prepare('INSERT INTO admin (username, password1, password2) VALUES (?, ?, ?)');
            $stmt->bind_param('sss', $username, $hash1, $hash2);
            $stmt->execute();
            $stmt->close();
            $adminSeeded = true;
            $steps[] = ['Admin account created', 'Two-password admin access is active.', true];
        } else {
            $steps[] = ['Admin account retained', 'An existing admin account was found.', true];
        }

        /* 3. Uploads folder */
        if (!is_dir(UPLOADS_DIR)) {
            @mkdir(UPLOADS_DIR, 0755, true);
        }
        @chmod(UPLOADS_DIR, 0755);
        if (is_dir(UPLOADS_DIR)) {
            if (!is_file(UPLOADS_DIR . '/.htaccess')) {
                @file_put_contents(
                    UPLOADS_DIR . '/.htaccess',
                    "<FilesMatch \"\\.(php|phtml|phar|php3|php4|php5|php7|phps)$\">\n    <IfModule mod_authz_core.c>\n        Require all denied\n    </IfModule>\n    <IfModule !mod_authz_core.c>\n        Order allow,deny\n        Deny from all\n    </IfModule>\n</FilesMatch>\n"
                );
            }
            if (!is_file(UPLOADS_DIR . '/index.html')) {
                @file_put_contents(UPLOADS_DIR . '/index.html', '');
            }
            $steps[] = ['Uploads folder ready', is_writable(UPLOADS_DIR) ? 'Writable and protected.' : 'Present, but not writable — check permissions.', is_writable(UPLOADS_DIR)];
            if (!is_writable(UPLOADS_DIR)) {
                $errors[] = 'The uploads folder is not writable. Make sure the uploads directory permissions allow writing (755).';
            }
        } else {
            $errors[] = 'Could not create the uploads folder. Create a folder named "uploads" in the NIVAYA root and make it writable.';
        }
    }
} catch (Throwable $e) {
    error_log('NIVAYA install failed: ' . $e->getMessage());
    $errors[] = 'Setup stopped: ' . $e->getMessage();
}

$showSuccess = !$alreadyInstalled && !$errors && $tablesReady;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="theme-color" content="#0b0a09">
    <title>Install · NIVAYA</title>
    <link rel="icon" href="assets/img/favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="assets/css/poppins.css">
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <meta name="robots" content="noindex,nofollow">
    <?php if ($showSuccess): ?>
        <meta http-equiv="refresh" content="5;url=login.php">
    <?php endif; ?>
</head>
<body class="min-h-screen bg-[#0b0a09] antialiased">
<div class="mx-auto flex min-h-screen w-full max-w-3xl flex-col items-center justify-center px-4 py-10 sm:px-6">
    <div class="mb-7 flex items-center gap-3">
        <span class="grid h-11 w-11 place-items-center rounded-2xl border border-amber-400/25 bg-gradient-to-br from-amber-300/15 to-transparent text-amber-300">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M12 2.8 19 9l-7 12.2L5 9l7-6.2Z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>
                <path d="M5 9h14M9.2 9 12 21.2 14.8 9" stroke="currentColor" stroke-width=".8" stroke-linejoin="round" opacity=".7"/>
            </svg>
        </span>
        <div>
            <p class="text-[16px] font-semibold tracking-[0.32em] text-white">NIVAYA</p>
            <p class="mt-1 text-[8.5px] uppercase tracking-[0.22em] text-white/25">One-time installation</p>
        </div>
    </div>

    <?php if ($alreadyInstalled): ?>
        <div class="w-full overflow-hidden rounded-[26px] border border-white/[0.08] bg-[#12110f]">
            <div class="border-b border-white/[0.06] px-6 py-8 text-center sm:px-10">
                <span class="mx-auto grid h-14 w-14 place-items-center rounded-full border border-white/10 bg-white/[0.03] text-white/40"><i class="fa-solid fa-lock text-lg"></i></span>
                <h1 class="mt-5 text-[22px] font-medium text-white sm:text-[25px]">NIVAYA is already installed</h1>
                <p class="mx-auto mt-2 max-w-[420px] text-[12px] leading-relaxed text-white/35">A complete setup already exists in <span class="text-white/60"><?= e(DB_NAME) ?></span>. To protect your store, the installer will not run again.</p>
            </div>
            <div class="p-6 sm:p-8">
                <div class="rounded-xl border border-amber-400/15 bg-amber-400/[0.04] px-4 py-3.5 text-[10.5px] leading-relaxed text-amber-200/70">
                    <i class="fa-solid fa-shield-halved mr-1.5"></i>For security, delete or rename <span class="font-medium text-amber-200">install.php</span> now that setup is complete.
                </div>
                <div class="mt-5 grid gap-2.5 sm:grid-cols-2">
                    <a href="login.php" class="btn-gold py-3.5"><i class="fa-solid fa-store text-[10px]"></i>Open storefront</a>
                    <a href="admin/login.php" class="btn-outline py-3.5"><i class="fa-solid fa-gauge-high text-[10px]"></i>Admin panel</a>
                </div>
                <p class="mt-5 text-center text-[9.5px] text-white/20">Need a full reset? Empty the tables in phpMyAdmin, then revisit this page.</p>
            </div>
        </div>

    <?php elseif ($errors): ?>
        <div class="w-full overflow-hidden rounded-[26px] border border-rose-400/20 bg-[#12110f]">
            <div class="border-b border-white/[0.06] px-6 py-8 text-center sm:px-10">
                <span class="mx-auto grid h-14 w-14 place-items-center rounded-full border border-rose-400/20 bg-rose-400/[0.06] text-rose-300"><i class="fa-solid fa-triangle-exclamation text-lg"></i></span>
                <h1 class="mt-5 text-[22px] font-medium text-white sm:text-[25px]">Setup needs attention</h1>
                <p class="mx-auto mt-2 max-w-[430px] text-[12px] leading-relaxed text-white/35">The installer could not finish. Fix the items below and refresh this page — your existing data will not be touched.</p>
            </div>
            <div class="p-6 sm:p-8">
                <div class="rounded-xl border border-rose-400/15 bg-rose-400/[0.04] p-4">
                    <ul class="list-disc space-y-1.5 pl-4 text-[11.5px] leading-relaxed text-rose-200/75">
                        <?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?>
                    </ul>
                </div>
                <?php if ($steps): ?>
                    <div class="mt-5 space-y-2">
                        <?php foreach ($steps as $step): ?>
                            <div class="flex items-center gap-2.5 text-[10.5px] text-white/40"><i class="fa-solid fa-circle-check text-[10px] text-emerald-400/60"></i><?= e($step[0]) ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <div class="mt-6 rounded-xl border border-white/[0.06] bg-white/[0.015] px-4 py-3.5 text-[10px] leading-relaxed text-white/30">
                    <p class="font-medium text-white/50">Check before retrying</p>
                    <ul class="mt-1.5 list-disc space-y-1 pl-4">
                        <li>The database was created in your hosting control panel (InfinityFree → MySQL Databases).</li>
                        <li>Credentials in <span class="text-amber-200/60">common/database.php</span> match the panel exactly (host, user, password, database name).</li>
                        <li>On InfinityFree the MySQL host is <span class="text-white/50">sqlXXX.infinityfree.com</span>, not "localhost".</li>
                    </ul>
                </div>
                <a href="install.php" class="btn-gold mt-5 w-full py-3.5"><i class="fa-solid fa-rotate-right text-[10px]"></i>Try installation again</a>
            </div>
        </div>

    <?php else: ?>
        <div class="w-full overflow-hidden rounded-[26px] border border-white/[0.08] bg-[#12110f]">
            <div class="relative border-b border-white/[0.06] px-6 py-8 text-center sm:px-10">
                <div class="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(245,158,11,.09),transparent_65%)]"></div>
                <div class="relative">
                    <span class="mx-auto grid h-14 w-14 place-items-center rounded-full border border-emerald-400/25 bg-emerald-400/[0.08] text-emerald-300"><i class="fa-solid fa-check text-lg"></i></span>
                    <p class="eyebrow mt-5">Installation complete</p>
                    <h1 class="mt-2.5 text-[24px] font-medium tracking-[-0.025em] text-white sm:text-[28px]">Your store is ready to shine.</h1>
                    <p class="mx-auto mt-2 max-w-[420px] text-[12px] leading-relaxed text-white/35">The database tables and admin access are set up. Save the credentials below, then sign in and add your products.</p>
                </div>
            </div>

            <div class="p-6 sm:p-8">
                <div class="space-y-2">
                    <?php foreach ($steps as $step): ?>
                        <div class="flex items-start gap-2.5 rounded-lg border border-white/[0.04] bg-white/[0.012] px-3 py-2.5">
                            <i class="fa-solid fa-circle-check mt-0.5 text-[9px] <?= !empty($step[2]) ? 'text-emerald-400' : 'text-amber-400' ?>"></i>
                            <div>
                                <p class="text-[10.5px] font-medium text-white/65"><?= e($step[0]) ?></p>
                                <p class="mt-0.5 text-[9px] text-white/25"><?= e($step[1]) ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <?php if ($adminSeeded): ?>
                    <div class="mt-6 rounded-2xl border border-amber-400/20 bg-amber-400/[0.04] p-4 sm:p-5">
                        <div class="flex items-center gap-2">
                            <i class="fa-solid fa-key text-[11px] text-amber-300"></i>
                            <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-amber-300/80">Admin credentials</p>
                        </div>
                        <div class="mt-3 grid gap-2 text-[11px] sm:grid-cols-2">
                            <div class="rounded-lg bg-black/25 px-3 py-2.5">
                                <p class="text-[8px] uppercase tracking-[0.14em] text-white/25">Username</p>
                                <p class="mt-1 font-mono text-[12px] text-white/80">admin</p>
                            </div>
                            <div class="rounded-lg bg-black/25 px-3 py-2.5">
                                <p class="text-[8px] uppercase tracking-[0.14em] text-white/25">Password 1</p>
                                <p class="mt-1 font-mono text-[12px] text-white/80">admin123</p>
                            </div>
                            <div class="rounded-lg bg-black/25 px-3 py-2.5">
                                <p class="text-[8px] uppercase tracking-[0.14em] text-white/25">Password 2</p>
                                <p class="mt-1 font-mono text-[12px] text-white/80">nivaya@2024</p>
                            </div>
                            <div class="rounded-lg bg-black/25 px-3 py-2.5">
                                <p class="text-[8px] uppercase tracking-[0.14em] text-white/25">Admin panel</p>
                                <a href="admin/login.php" class="mt-1 block text-[11px] text-amber-300/80 hover:text-amber-200">/admin/login.php</a>
                            </div>
                        </div>
                        <p class="mt-3 flex items-start gap-1.5 text-[8.5px] leading-relaxed text-amber-200/40"><i class="fa-solid fa-triangle-exclamation mt-0.5 text-[8px]"></i>Both passwords are required at sign-in. Change them in Admin → Settings, and delete install.php after setup.</p>
                    </div>
                <?php else: ?>
                    <div class="mt-6 rounded-xl border border-white/[0.06] bg-white/[0.015] px-4 py-3.5 text-[10px] leading-relaxed text-white/35">
                        <i class="fa-solid fa-circle-info mr-1 text-sky-400/60"></i>An existing admin account was kept. Use your previously configured credentials to sign in.
                    </div>
                <?php endif; ?>

                <div class="mt-6 flex flex-col gap-2.5 sm:flex-row">
                    <a href="login.php" class="btn-gold flex-1 py-3.5"><i class="fa-solid fa-store text-[10px]"></i>Open customer store</a>
                    <a href="admin/login.php" class="btn-outline flex-1 py-3.5"><i class="fa-solid fa-gauge-high text-[10px]"></i>Open admin panel</a>
                </div>

                <div class="mt-5 flex items-center justify-center gap-2 text-[9.5px] text-white/25">
                    <i class="fa-solid fa-clock text-[8px]"></i>
                    <span>Taking you to the sign-in page in <span id="countdown" class="font-medium text-amber-300/70">5</span> seconds…</span>
                </div>

                <div class="mt-6 border-t border-white/[0.06] pt-4 text-center text-[8.5px] leading-relaxed text-white/15">
                    Your catalogue starts empty — add your first piece from Admin → Add product. Keep <span class="text-white/25">install.php</span> out of reach now that setup is done.
                </div>
            </div>
        </div>
    <?php endif; ?>

    <p class="mt-6 text-center text-[8.5px] uppercase tracking-[0.18em] text-white/12">NIVAYA · Jewellery &amp; Accessories</p>
</div>

<?php if ($showSuccess): ?>
<script>
(function () {
    var seconds = 5;
    var el = document.getElementById('countdown');
    var timer = setInterval(function () {
        seconds -= 1;
        if (el) el.textContent = String(Math.max(0, seconds));
        if (seconds <= 0) {
            clearInterval(timer);
            window.location.href = 'login.php';
        }
    }, 1000);
})();
</script>
<?php endif; ?>
</body>
</html>
